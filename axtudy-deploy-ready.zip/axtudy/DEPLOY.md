# Deploying AXTUDY — a real, shareable link

The app is a zero-dependency Node app (Node 22.5+ for `node:sqlite`).
`Dockerfile` and `render.yaml` are included, so most hosts need **no build config**.

---

## Fastest path: Render (works entirely from an iPhone browser)

1. **Put the code in a Git repo**
   - Create a repo on github.com (mobile web works fine).
   - Upload the contents of this folder (GitHub's "upload files" accepts the ZIP contents).
2. Go to **render.com** → sign in with GitHub.
3. **New → Blueprint** → pick the repo → **Apply**.
   Render reads `render.yaml` and builds the Docker image automatically.
4. In a few minutes you get a stable URL like:
   `https://axtudy.onrender.com`
   That is your **official shareable link**.
5. Optional: **Settings → Custom Domain** to use `axtudy.app` or similar.

**Then share it:** send `https://axtudy.onrender.com` to anyone. They open it in
Safari → Share → **Add to Home Screen** and it runs fullscreen like an app.

---

## Free-tier reality check

| Concern | Detail |
|---|---|
| Sleep | Render's free web service sleeps after ~15 min idle. First hit takes ~30 s to wake. |
| Data | Free plan disk is **ephemeral** — SQLite data resets on deploy/restart. |
| Fix | Upgrade to `starter` and uncomment the `disk:` block in `render.yaml` (1 GB is plenty). |
| Bandwidth | Fine for a class-sized user base; upgrade later if it grows. |

---

## Other hosts

**Railway** — `New Project → Deploy from GitHub repo`. Add a Volume mounted at
`/data` so the database persists. Set `APP_SECRET` and `DATA_DIR=/data`.

**Fly.io** — needs the CLI:
```bash
fly launch --dockerfile Dockerfile
fly volumes create axtudy_data --size 1
fly secrets set APP_SECRET="$(openssl rand -hex 32)" DATA_DIR=/data
fly deploy
```

**Any VPS with Docker**
```bash
docker build -t axtudy .
docker run -d --name axtudy -p 3000:3000 \
  -v axtudy-data:/data \
  -e APP_SECRET="$(openssl rand -hex 32)" \
  -e NODE_ENV=production \
  axtudy
```
Put Caddy or Nginx in front for TLS (so cookies become `Secure`).

---

## Environment variables

| Variable | Needed for | Notes |
|---|---|---|
| `APP_SECRET` | Signing sessions | **Set this.** 32+ random hex chars. |
| `DATA_DIR` | Database + uploads | Use a mounted volume path (`/data`). |
| `NODE_ENV=production` | Secure cookies | Also hides dev-only helpers. |
| `DEV_SHOW_RESET_LINK=false` | Turns off dev reset links in API responses | **Required in production.** |
| `OPENAI_API_KEY` / `GEMINI_API_KEY` | Real AI + image OCR | Without them the offline engine still works. |
| `RESEND_API_KEY` | Real password-reset email | Otherwise reset links are returned in the API only. |
| `PAYMONGO_SECRET_KEY` / `PAYMONGO_WEBHOOK_SECRET` | Real ₱49 payments | Without them checkout is simulated. Needs an HTTPS webhook to `/api/webhooks/paymongo`. |

---

## Production checklist

- [ ] Strong `APP_SECRET` (do not reuse the preview value)
- [ ] `DEV_SHOW_RESET_LINK=false`
- [ ] Persistent volume mounted at `DATA_DIR`
- [ ] TLS in front of the app
- [ ] Back up `axtudy.db` regularly (`sqlite3 axtudy.db ".backup out.db"`)
- [ ] AI + payment keys added if you want those live
