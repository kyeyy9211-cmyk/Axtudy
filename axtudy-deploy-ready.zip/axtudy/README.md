# AXTUDY

**A mobile-first student productivity + AI study app.**
Zero npm dependencies — runs on Node's built-ins only (HTTP server, SQLite, crypto).

---

## 1. Run it (30 seconds)

```bash
cd axtudy
node server.js          # that's it — no npm install needed
```

Open **http://localhost:3000**

**Demo login:** `demo@axtudy.app` / `axtudy123`
(also printed in the terminal on startup, along with a ready-made class schedule,
assignments, an overdue quiz, an exam, and a study material you can run the AI on)

Requirements: **Node.js 22.5+** (uses `node:sqlite`).
Optional: `poppler-utils` (`pdftotext`) for PDF text and `unzip` for PPTX/DOCX reading.

```bash
npm start        # same as node server.js
npm run dev      # auto-restart on file changes
npm run seed     # reload the demo student's data (or use the Profile button)
```

---

## 2. What's inside

```
axtudy/
├── server.js             HTTP server, static files, demo bootstrap
├── .env.example          all optional credentials documented
├── src/
│   ├── config.js         env loading, plan limits, pricing
│   ├── db.js             SQLite schema (+ demo data seeder)
│   ├── auth.js           scrypt passwords, sessions, password reset
│   ├── api.js            every REST endpoint (all user-scoped)
│   ├── extract.js        PDF / PPTX / DOCX / XLSX / image text extraction
│   ├── ai.js             AI engine: OpenAI · Gemini · offline study engine
│   └── billing.js        AXTUDY PRO subscription + PayMongo + quotas
├── public/
│   ├── index.html        app shell
│   ├── app.css           design system (mobile-first)
│   ├── core.js           API client, toasts, modals, formatters
│   ├── app.js            router + bottom navigation
│   └── views/            auth · home · study · tasks · classes · profile · billing
└── data/                 created on first run → SQLite DB + uploaded files
```

---

## 3. Feature checklist

| Area | What works |
|---|---|
| **Auth** | Sign up, login, logout, forgot password, reset password (token, 24h), change password |
| **Profile** | Name, school, course, year level, avatar colour, email change |
| **Home** | Greeting, today's classes, due today, overdue count, upcoming assignments, upcoming exams, quick actions, semester stats |
| **Study** | Upload PDF/PPTX/DOCX/XLSX/TXT/MD/images or paste notes · Summarize · Reviewer · MCQ quiz · True/False · Flashcards · Explain simply · Ask questions about the material |
| **Tasks** | Add / edit / delete, title, subject, description, due date+time, priority, type (assignment/exam/quiz/project), reminders, check off, tabs Today / Upcoming / Overdue / Completed |
| **Classes** | Add / edit / delete, subject name + code, instructor, room, day, start/end time, colour, week overview |
| **Billing** | ₱49/month PRO with a 3-day free trial, price + terms shown before subscribing, cancel/resume, usage meters, quota enforcement |
| **Privacy** | Every row is scoped by `user_id`; students can only ever read or write their own data |

---

## 4. AI: it works with or without keys

AXTUDY has **two interchangeable engines** behind one interface:

**1. Offline engine (default — no credentials needed).**
Real, deterministic study tooling built from *your* text: frequency-ranked
extractive summaries, key-term extraction with definitions, cloze-style MCQ
generation, true/false construction, flashcard decks, jargon simplification and
keyword-overlap retrieval for the Q&A box. Results are labelled **"Local engine"**.

**2. Provider engine (add a key to `.env`).**
```env
AI_PROVIDER=auto          # auto | openai | gemini | none
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
# or
GEMINI_API_KEY=AIza...
GEMINI_MODEL=gemini-2.0-flash
```
`auto` prefers OpenAI, then Gemini, then falls back offline. If a provider call
fails, AXTUDY silently falls back to the offline engine and tells you it did —
the student never sees a dead button. **Keys are read server-side only and are
never sent to the browser.**

Gemini additionally unlocks **image OCR** (transcribe a photo of your notes).

> Where to put credentials: copy `.env.example` → `.env` and fill in the keys.
> Nothing else in the code needs editing.

---

## 5. Payments (AXTUDY PRO)

Plan terms (configurable in `.env`): **₱49/month**, **3-day free trial**, cancel
anytime. The price and trial terms are displayed before any commitment.

**Without keys** the app uses a built-in **simulated checkout** that activates PRO
instantly so you can test the whole flow: Start trial → quota lifts → Cancel →
access continues to period end → Dev reset button on the Profile screen.

**With PayMongo keys** (`.env`):
```env
PAYMONGO_SECRET_KEY=sk_test_...
PAYMONGO_PUBLIC_KEY=pk_test_...
PAYMONGO_WEBHOOK_SECRET=whsk_...
PAYMONGO_SUCCESS_URL=https://yourdomain.com/?billing=success
PAYMONGO_CANCEL_URL=https://yourdomain.com/?billing=cancel
```
Point a PayMongo webhook at `https://yourdomain.com/api/webhooks/paymongo`
(events: `checkout_session.payment.paid`, `payment.failed`,
`subscription.cancelled`). Signatures are verified with HMAC-SHA256.

**Free vs Pro quotas** (`src/config.js → LIMITS`):

| | Free | AXTUDY PRO |
|---|---|---|
| Uploads / month | 3 | unlimited |
| AI generations / month | 10 | unlimited |
| Questions / month | 5 | unlimited |
| Quiz questions per run | 5 | 25 |
| Flashcards per run | 12 | 60 |
| Max file size | 8 MB | 25 MB |
| Materials stored | 10 | unlimited |

Quotas are enforced **server-side** on every request. When a limit is hit the API
returns HTTP 402 with upgrade metadata and the app opens the PRO sheet — no
silent failures.

---

## 6. Testing it in 3 minutes

1. `node server.js` → open http://localhost:3000
2. Sign in with the demo account.
3. **Home** — check today's classes, "Due today" and overdue items. Tap a task → edit → save.
4. **Tasks** → *New* → add "Physics problem set", due tomorrow, high priority, reminder. Toggle it complete, then switch to the Completed tab.
5. **Classes** → *New* → add a subject, or tap an existing one to edit/delete.
6. **Study** → open **"Linked Lists — CS 201 notes"**:
   * *Summarize* → summary + key points
   * *MCQ Quiz* → answer, Submit → score + explanations, Retake
   * *Flashcards* → tap to flip, Shuffle
   * *True / False* → Check answers
   * *Ask about this material* → "What is the Big-O of insertion at the head?"
   * *Add* → **Paste notes** or upload a PDF/PPTX/image
7. **Profile** → edit your details, then **Upgrade to PRO** → *Start 3-day free trial*. Watch the quota meters reset. *Cancel* and confirm access continues, then use *Dev: reset to Free* to test again.
8. **Fresh account test** — log out, sign up as a new student: you get an empty workspace (private per user) and the Free limits apply.

### API smoke test
```bash
curl -s localhost:3000/api/health | head -c 400
curl -s -X POST localhost:3000/api/auth/login \
  -H 'content-type: application/json' \
  -d '{"email":"demo@axtudy.app","password":"axtudy123"}' -c /tmp/c.txt
curl -s localhost:3000/api/dashboard -b /tmp/c.txt | head -c 400
```

---

## 7. Deploying

Any host that runs Node 22.5+ with a persistent disk works (Render, Railway,
Fly.io, a VPS, Docker).

```bash
NODE_ENV=production \
APP_SECRET="$(openssl rand -hex 32)" \
DEV_SHOW_RESET_LINK=false \
DATA_DIR=/var/lib/axtudy \
node server.js
```

**Production checklist**
- [ ] Set a strong `APP_SECRET`
- [ ] Set `DEV_SHOW_RESET_LINK=false` and add `RESEND_API_KEY` for real reset emails
- [ ] Mount a **persistent volume** for `DATA_DIR` (SQLite + uploads)
- [ ] Put a TLS reverse proxy (Caddy/Nginx) in front so cookies are `Secure`
- [ ] Add PayMongo keys + webhook
- [ ] Enable backups of `data/axtudy.db` (`sqlite3 axtudy.db ".backup out.db"`)

Dockerfile (works as-is):
```dockerfile
FROM node:22-alpine
RUN apk add --no-cache poppler-utils unzip
WORKDIR /app
COPY . .
ENV PORT=3000 NODE_ENV=production DATA_DIR=/data
VOLUME /data
EXPOSE 3000
CMD ["node","server.js"]
```

---

## 8. Notes & limitations

- **PDF/PPTX/DOCX/XLSX text** needs `pdftotext`/`unzip` on the host. Without them
  AXTUDY says so plainly instead of pretending. Pasting notes always works.
- **Images** need `GEMINI_API_KEY` for OCR; otherwise the file is stored and the
  UI explains what's missing.
- **Password reset email** is returned in the API response while
  `DEV_SHOW_RESET_LINK=true` so the flow is testable. Wire up Resend/SendGrid for real delivery.
- Times are rendered in the **browser's** timezone; "today" buckets are computed
  server-side in the server's timezone.
- Single-instance only (SQLite + local file storage). For horizontal scaling,
  move uploads to S3 and the DB to Postgres.
