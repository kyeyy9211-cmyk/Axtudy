# AXTUDY — web app folder

Served by `server.js`. Do not open these files directly — start the server from
the project root (`node server.js`) and visit http://localhost:3000
