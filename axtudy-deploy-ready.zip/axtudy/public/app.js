/**
 * AXTUDY — app shell: router, bottom navigation and bootstrap.
 */
import { api, el, icon, toast, store, $ } from './core.js';
import { renderAuth } from './views/auth.js';
import { renderHome } from './views/home.js';
import { renderStudy } from './views/study.js';
import { renderTasks } from './views/tasks.js';
import { renderClasses } from './views/classes.js';
import { renderProfile } from './views/profile.js';
import { handleLimitError } from './views/billing.js';

const NAV = [
  { key: 'home', label: 'Home', icon: 'home' },
  { key: 'study', label: 'Study', icon: 'study' },
  { key: 'tasks', label: 'Tasks', icon: 'tasks' },
  { key: 'classes', label: 'Classes', icon: 'classes' },
  { key: 'profile', label: 'Profile', icon: 'profile' },
];

let currentRoute = { name: 'home', param: '' };
let viewRoot = null;
let navRoot = null;
let badgeEl = null;

/* ───────────────────────── routing ───────────────────────── */

function parseHash() {
  const raw = (location.hash || '#/home').replace(/^#\/?/, '');
  const [name, ...rest] = raw.split('/');
  return { name: name || 'home', param: rest.join('/') };
}

async function navigate(name, param = '') {
  const hash = `#/${name}${param ? `/${param}` : ''}`;
  if (location.hash !== hash) {
    location.hash = hash;
    return; // hashchange handler will render
  }
  await render();
}

async function render() {
  currentRoute = parseHash();
  paintNav();
  if (!viewRoot) return;
  try {
    await renderView();
  } catch (err) {
    if (handleLimitError(err)) return;
    viewRoot.innerHTML = '';
    viewRoot.append(el('div', { class: 'empty' },
      el('div', { class: 'em', text: '⚠️' }),
      el('p', { text: err.message || 'Something went wrong.' }),
      el('button', { class: 'btn', text: 'Reload app', onclick: () => location.reload() })
    ));
  }
}

async function renderView() {
  const ctx = { navigate, refresh: () => render(), onLogout: boot };
  switch (currentRoute.name) {
    case 'study': return renderStudy(viewRoot, { ...ctx, materialId: currentRoute.param });
    case 'tasks': return renderTasks(viewRoot, ctx);
    case 'classes': {
      const r = await renderClasses(viewRoot, ctx);
      return r;
    }
    case 'profile': return renderProfile(viewRoot, ctx);
    case 'home':
    default: return renderHome(viewRoot, ctx);
  }
}

function paintNav() {
  if (!navRoot) return;
  [...navRoot.children].forEach((btn) => {
    btn.setAttribute('aria-current', btn.dataset.key === currentRoute.name ? 'page' : 'false');
  });
  if (badgeEl) {
    const sub = store.subscription;
    badgeEl.textContent = sub?.isPro ? 'PRO' : 'FREE';
    badgeEl.className = `plan-badge ${sub?.isPro ? 'pro' : ''}`;
  }
}

/* ───────────────────────── app shell ───────────────────────── */

function renderApp() {
  const root = $('#root');
  root.innerHTML = '';

  const app = el('div', { id: 'app' });

  badgeEl = el('span', { class: `plan-badge ${store.subscription?.isPro ? 'pro' : ''}`, text: store.subscription?.isPro ? 'PRO' : 'FREE' });

  const bar = el('header', { class: 'appbar' },
    el('div', { class: 'appbar-inner' },
      el('div', { class: 'brand' },
        el('div', { class: 'logo', text: 'A' }),
        el('span', { text: 'AXTUDY' })
      ),
      el('div', { class: 'grow' }),
      badgeEl,
      el('button', {
        class: 'btn icon', 'aria-label': 'Account', html: icon('user'),
        onclick: () => navigate('profile'),
      })
    )
  );

  viewRoot = el('main', { id: 'view' });

  navRoot = el('nav', { class: 'bottomnav', 'aria-label': 'Main navigation' },
    el('div', { class: 'bottomnav-inner' },
      NAV.map((n) => el('button', {
        class: 'navbtn', 'data-key': n.key, 'aria-current': 'false',
        html: `${icon(n.icon)}<span>${n.label}</span>`,
        onclick: () => navigate(n.key),
      }))
    )
  );

  app.append(bar, viewRoot, navRoot);
  root.append(app);
  paintNav();
}

/* ───────────────────────── bootstrap ───────────────────────── */

async function loadSession() {
  try {
    const res = await api.get('/api/auth/me');
    return res;
  } catch {
    return { user: null };
  }
}

async function handleBillingRedirect() {
  const params = new URLSearchParams(location.search);
  const billing = params.get('billing');
  if (!billing) return;
  history.replaceState(null, '', location.pathname + location.hash);
  if (billing === 'cancel') { toast('Checkout canceled — you are still on your current plan.', 'warn'); return; }
  if (billing === 'success') {
    try {
      const res = await api.post('/api/billing/confirm', { reference: params.get('ref') || '' });
      store.subscription = res.subscription;
      toast(res.message || 'AXTUDY PRO activated!', 'ok');
    } catch (err) {
      toast(err.message, 'err');
    }
  }
}

async function boot() {
  const resetToken = new URLSearchParams(location.search).get('reset') || '';
  const session = await loadSession();

  if (!session.user) {
    store.user = null;
    store.subscription = null;
    renderAuth($('#root'), {
      resetToken,
      onAuthed: (res) => {
        store.user = res.user;
        store.subscription = res.subscription;
        if (!location.hash) location.hash = '#/home';
        renderApp();
        render();
      },
    });
    return;
  }

  store.user = session.user;
  store.subscription = session.subscription;
  store.usage = session.usage;

  // warm the class list so sheets can offer a class picker everywhere
  try {
    const cls = await api.get('/api/classes');
    store.classes = cls.classes;
  } catch { /* non-fatal */ }

  await handleBillingRedirect();

  if (!location.hash) location.hash = '#/home';
  renderApp();
  await render();
}

window.addEventListener('hashchange', () => {
  if ($('#view')) render();
});

// Keep the header plan badge in sync when the subscription changes anywhere.
window.addEventListener('axtudy:shell', () => paintNav());

document.addEventListener('error', (e) => {
  console.error('[AXTUDY] UI error', e.error || e.message);
});

boot();
