/**
 * AXTUDY — API client, state, tiny helpers, and UI primitives.
 * No framework, no build step: the browser loads these as ES modules.
 */
export const store = {
  user: null,
  subscription: null,
  usage: null,
  aiEngine: null,
  classes: [],
  dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
};

export const DAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/**
 * Tell the app shell that shared state (plan, usage) changed so the header
 * badge and nav repaint without a full reload.
 */
export function notifyShell() {
  try { window.dispatchEvent(new Event('axtudy:shell')); } catch { /* non-fatal */ }
}

/* ───────────────────────── fetch wrapper ───────────────────────── */

export class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.status = status;
    this.data = data || {};
  }
  get isLimit() { return this.data.code === 'LIMIT_REACHED'; }
  get isUpgrade() { return Boolean(this.data.upgrade); }
  get isAuth() { return this.status === 401; }
}

async function request(method, path, { body, form } = {}) {
  const opts = { method, credentials: 'same-origin', headers: {} };
  if (form) {
    opts.body = form;
  } else if (body !== undefined) {
    opts.headers['content-type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(path, opts);
  } catch {
    throw new ApiError('You appear to be offline. Check your connection and try again.', 0);
  }
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text.slice(0, 200) }; }

  if (!res.ok || data.ok === false) {
    const message = data.error || `Request failed (${res.status})`;
    const err = new ApiError(message, res.status, data);
    if (err.isAuth && !/sign in/i.test(message)) err.message = 'Please sign in to continue.';
    throw err;
  }
  return data;
}

export const api = {
  get: (p) => request('GET', p),
  post: (p, body) => request('POST', p, { body }),
  patch: (p, body) => request('PATCH', p, { body }),
  del: (p) => request('DELETE', p),
  upload: (p, formData) => request('POST', p, { form: formData }),
};

/* ───────────────────────── tiny DOM helpers ───────────────────────── */

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k === 'text') node.textContent = v;
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else node.setAttribute(k, v === true ? '' : String(v));
  }
  for (const c of children.flat()) {
    if (c === null || c === undefined || c === false) continue;
    node.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return node;
}

/** Escape untrusted text before it goes into an innerHTML template. */
export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

export const icon = (name, cls = '') => {
  const paths = {
    home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9.5 21v-6h5v6"/>',
    study: '<path d="M12 3 2 8l10 5 10-5-10-5Z"/><path d="M6 10.5V16c0 1.7 2.7 3 6 3s6-1.3 6-3v-5.5"/>',
    tasks: '<path d="M9 5h11"/><path d="M9 12h11"/><path d="M9 19h11"/><path d="m3 5 1.6 1.6L7.5 3.7"/><path d="m3 12 1.6 1.6L7.5 10.7"/><path d="m3 19 1.6 1.6L7.5 17.7"/>',
    classes: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M3 11h18"/>',
    profile: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    sparkle: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6.3 6.3l2.8 2.8M14.9 14.9l2.8 2.8M17.7 6.3l-2.8 2.8M9.1 14.9l-2.8 2.8"/>',
    upload: '<path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>',
    file: '<path d="M14 2H7a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7Z"/><path d="M14 2v5h5"/>',
    quiz: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.4 2.3c-.7.3-1 .9-1 1.7"/><path d="M12 17h.01"/>',
    tf: '<path d="M4 7h16"/><path d="M7 7v10M4 17h6"/><circle cx="17" cy="15" r="3"/>',
    cards: '<rect x="3" y="6" width="13" height="14" rx="2.5"/><path d="M8 3h9a3 3 0 0 1 3 3v11"/>',
    bulb: '<path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2a6 6 0 0 0-3.5 10.9c.4.3.5.7.5 1.1v1h6v-1c0-.4.1-.8.5-1.1A6 6 0 0 0 12 2Z"/>',
    chat: '<path d="M20 14a3 3 0 0 1-3 3H9l-5 4V6a3 3 0 0 1 3-3h10a3 3 0 0 1 3 3Z"/>',
    trash: '<path d="M4 7h16"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/><path d="M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    close: '<path d="M18 6 6 18M6 6l12 12"/>',
    back: '<path d="m15 18-6-6 6-6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
    pin: '<path d="M12 21s7-5.4 7-11a7 7 0 1 0-14 0c0 5.6 7 11 7 11Z"/><circle cx="12" cy="10" r="2.6"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4.5 21c0-3.8 3.4-5.8 7.5-5.8s7.5 2 7.5 5.8"/>',
    school: '<path d="M3 9.5 12 4l9 5.5"/><path d="M5 10v9h14v-9"/><path d="M9 19v-5h6v5"/>',
    logout: '<path d="M9 21H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
    crown: '<path d="M3 7l4 3 5-6 5 6 4-3-2 12H5L3 7Z"/>',
    bell: '<path d="M6 9a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6Z"/><path d="M10.5 19a1.8 1.8 0 0 0 3 0"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    copy: '<rect x="9" y="9" width="12" height="12" rx="2.5"/><path d="M15 5.5A2.5 2.5 0 0 0 12.5 3h-6A3.5 3.5 0 0 0 3 6.5v6A2.5 2.5 0 0 0 5.5 15"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    book: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v18H6.5A2.5 2.5 0 0 0 4 22Z"/><path d="M4 17.5A2.5 2.5 0 0 1 6.5 15H20"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    shield: '<path d="M12 22s8-3.5 8-10V5.5L12 2 4 5.5V12c0 6.5 8 10 8 10Z"/>',
  };
  return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || ''}</svg>`;
};

/* ───────────────────────── formatting ───────────────────────── */

export function fmtDate(iso, { withTime = true, short = false } = {}) {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const datePart = d.toLocaleDateString(undefined, short
    ? { month: 'short', day: 'numeric' }
    : { weekday: 'short', month: 'short', day: 'numeric' });
  if (!withTime) return datePart;
  return `${datePart} · ${d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
}

export function fmtWhen(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const now = new Date();
  const d0 = new Date(now); d0.setHours(0, 0, 0, 0);
  const t0 = new Date(d); t0.setHours(0, 0, 0, 0);
  const days = Math.round((t0 - d0) / 86400000);
  const time = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  if (days === 0) return `Today · ${time}`;
  if (days === 1) return `Tomorrow · ${time}`;
  if (days === -1) return `Yesterday · ${time}`;
  if (days < 0) return `${Math.abs(days)} days ago`;
  if (days < 7) return `${d.toLocaleDateString(undefined, { weekday: 'short' })} · ${time}`;
  return `${d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} · ${time}`;
}

export function fmtTime(hhmm) {
  if (!hhmm) return '';
  const [h, m] = hhmm.split(':').map(Number);
  if (Number.isNaN(h)) return hhmm;
  const d = new Date(); d.setHours(h, m || 0, 0, 0);
  return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

export function fmtBytes(n) {
  if (!n) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB'];
  let i = 0; let v = n;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${u[i]}`;
}

export const peso = (n) => `₱${Number(n).toLocaleString('en-PH', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;

export const timeAgo = (iso) => {
  if (!iso) return '';
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
};

export const greeting = () => {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
};

/* ───────────────────────── toasts ───────────────────────── */

export function toast(message, type = 'info', ms = 3400) {
  const host = document.getElementById('toasts');
  if (!host) return;
  const node = el('div', { class: `toast ${type === 'info' ? '' : type}`, text: message });
  host.append(node);
  setTimeout(() => {
    node.style.transition = 'opacity .25s, transform .25s';
    node.style.opacity = '0';
    node.style.transform = 'translateY(-8px)';
    setTimeout(() => node.remove(), 260);
  }, ms);
}

/* ───────────────────────── modal sheet ───────────────────────── */

let openSheet = null;

export function closeSheet() {
  if (!openSheet) return;
  openSheet.overlay.remove();
  openSheet = null;
  document.body.style.overflow = '';
}

/**
 * openSheet({ title, body, actions, onMount, size })
 *  body: Node | string(HTML)
 *  actions: [{ label, variant, onClick, close }]
 */
export function sheet({ title, body, actions = [], onMount, dismissible = true }) {
  closeSheet();
  const bodyEl = el('div', { class: 'sheet-body' });
  if (typeof body === 'string') bodyEl.innerHTML = body;
  else if (body) bodyEl.append(body);

  const footEl = actions.length
    ? el('div', { class: 'sheet-foot' }, actions.map((a) =>
        el('button', {
          class: `btn ${a.variant || 'ghost'}`,
          text: a.label,
          onclick: async (e) => {
            const btn = e.currentTarget;
            try {
              const keep = a.onClick ? await a.onClick(btn) : false;
              if (a.close !== false && keep !== true) closeSheet();
            } catch (err) {
              toast(err.message || 'Something went wrong.', 'err');
            }
          },
        })
      ))
    : null;

  const panel = el('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true' },
    el('div', { class: 'grabber' }),
    el('div', { class: 'sheet-head' },
      el('h2', { text: title || '' }),
      el('button', { class: 'btn icon', html: icon('close'), 'aria-label': 'Close', onclick: () => closeSheet() })
    ),
    bodyEl,
    footEl
  );

  const overlay = el('div', {
    class: 'overlay',
    onclick: (e) => { if (dismissible && e.target === overlay) closeSheet(); },
  }, panel);

  document.body.append(overlay);
  document.body.style.overflow = 'hidden';
  openSheet = { overlay, panel, bodyEl };
  if (onMount) onMount(bodyEl, panel);
  const firstInput = panel.querySelector('input,select,textarea');
  if (firstInput && window.innerWidth > 640) firstInput.focus();
  return openSheet;
}

export function confirmDialog({ title, message, confirmLabel = 'Delete', danger = true }) {
  return new Promise((resolve) => {
    sheet({
      title,
      body: el('p', { class: 'muted', style: 'margin:0;font-size:14px;line-height:1.6', text: message }),
      actions: [
        { label: 'Cancel', variant: 'ghost', onClick: () => { resolve(false); } },
        { label: confirmLabel, variant: danger ? 'danger' : '', onClick: () => { resolve(true); } },
      ],
    });
  });
}

/* ───────────────────────── misc ───────────────────────── */

export const requireUpgrade = (err) => Boolean(err?.isUpgrade || err?.isLimit);

export function setBusy(btn, busy, label) {
  if (!btn) return;
  if (busy) {
    btn.dataset.label = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner"></span><span>${esc(label || 'Working…')}</span>`;
  } else {
    btn.disabled = false;
    if (btn.dataset.label) btn.innerHTML = btn.dataset.label;
  }
}

/** Convert a `datetime-local` value to an ISO string. */
export const localToIso = (v) => (v ? new Date(v).toISOString() : null);

/** Convert an ISO string to a `datetime-local` value (local time). */
export function isoToLocalInput(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function copyText(text) {
  if (navigator.clipboard?.writeText) {
    return navigator.clipboard.writeText(text).then(() => true).catch(() => false);
  }
  const ta = document.createElement('textarea');
  ta.value = text;
  document.body.append(ta);
  ta.select();
  const ok = document.execCommand?.('copy');
  ta.remove();
  return Promise.resolve(Boolean(ok));
}

export const debounce = (fn, ms = 300) => {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
};
