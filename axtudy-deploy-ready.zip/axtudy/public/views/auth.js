/**
 * AXTUDY — authentication screen (sign up / sign in / forgot / reset).
 */
import { api, el, esc, icon, toast, setBusy } from '../core.js';

const logo = () => el('div', { class: 'auth-logo' },
  el('div', { class: 'logo', style: 'width:38px;height:38px;border-radius:12px;background:var(--brand);display:grid;place-items:center;color:#fff;font-weight:800;font-size:19px;box-shadow:0 6px 16px rgba(79,70,229,.32)', text: 'A' }),
  el('div', {},
    el('div', { style: 'font-weight:800;font-size:19px;letter-spacing:-.4px', text: 'AXTUDY' }),
    el('div', { class: 'tiny muted', text: 'Study smarter, not longer' })
  )
);

function field(label, input, hint) {
  return el('div', { class: 'field' },
    el('label', { text: label }),
    input,
    hint ? el('div', { class: 'hint', text: hint }) : null
  );
}

const input = (attrs) => el('input', { ...attrs });

export function renderAuth(root, { onAuthed, resetToken = '' }) {
  root.innerHTML = '';
  const wrap = el('div', { id: 'auth' });
  const top = el('div', { class: 'auth-top' });
  wrap.append(top);
  root.append(wrap);

  if (resetToken) return renderReset(top, resetToken, onAuthed);

  let mode = 'signin';

  function paint() {
    top.innerHTML = '';
    const card = el('div', { class: 'auth-card' });

    const seg = el('div', { class: 'seg', role: 'tablist' },
      el('button', { role: 'tab', 'aria-selected': String(mode === 'signin'), text: 'Sign in', onclick: () => { mode = 'signin'; paint(); } }),
      el('button', { role: 'tab', 'aria-selected': String(mode === 'signup'), text: 'Create account', onclick: () => { mode = 'signup'; paint(); } })
    );
    card.append(seg);

    if (mode === 'signin') card.append(signinForm(onAuthed));
    else card.append(signupForm(onAuthed, (email) => {
      mode = 'signin';
      paint();
      const em = top.querySelector('input[type="email"]');
      if (em && email) em.value = email;
    }));

    top.append(
      logo(),
      el('h1', { class: 'auth-title', text: mode === 'signin' ? 'Welcome back 👋' : 'Create your account' }),
      el('p', { class: 'auth-sub', text: mode === 'signin' ? 'Sign in to see your classes, tasks and study materials.' : 'Free to start — no card needed. Upgrade anytime.' }),
      card
    );

    if (mode === 'signin') {
      top.append(el('div', { class: 'demo-chip' },
        el('strong', { text: 'Try the demo account → ' }),
        el('span', { class: 'mono', text: 'demo@axtudy.app / axtudy123' }),
        el('button', {
          class: 'btn xs soft', style: 'margin-left:8px', text: 'Fill in',
          onclick: () => {
            top.querySelector('input[type="email"]').value = 'demo@axtudy.app';
            top.querySelector('input[type="password"]').value = 'axtudy123';
          },
        })
      ));
    }

    top.append(el('div', { class: 'auth-foot', text: 'Your data stays private to your account.' }));
  }

  paint();
}

function signinForm(onAuthed) {
  const email = input({ type: 'email', placeholder: 'you@school.edu', autocomplete: 'email', required: true });
  const password = input({ type: 'password', placeholder: 'Your password', autocomplete: 'current-password', required: true });
  const submit = el('button', { class: 'btn block', type: 'submit' }, 'Sign in');

  const form = el('form', { onsubmit: async (e) => {
    e.preventDefault();
    setBusy(submit, true, 'Signing in…');
    try {
      const res = await api.post('/api/auth/login', { email: email.value, password: password.value });
      toast(`Welcome back, ${res.user.name.split(' ')[0]}!`, 'ok');
      onAuthed(res);
    } catch (err) {
      toast(err.message, 'err');
      setBusy(submit, false);
    }
  } },
    field('Email', email),
    field('Password', password),
    el('div', { class: 'row between', style: 'margin:-4px 0 14px' },
      el('span'),
      el('button', {
        class: 'link', type: 'button', text: 'Forgot password?',
        onclick: () => showForgot(document.querySelector('.auth-top'), onAuthed),
      })
    ),
    submit
  );
  return form;
}

function signupForm(onAuthed, gotoSignin) {
  const name = input({ placeholder: 'Juan Dela Cruz', autocomplete: 'name', required: true });
  const email = input({ type: 'email', placeholder: 'you@school.edu', autocomplete: 'email', required: true });
  const password = input({ type: 'password', placeholder: 'At least 8 characters', autocomplete: 'new-password', minlength: '8', required: true });
  const school = input({ placeholder: 'e.g. University of the Philippines' });
  const course = input({ placeholder: 'e.g. BS Computer Science' });
  const year = el('select', {},
    ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year', 'Graduate'].map((y) =>
      el('option', { value: y }, y))
  );
  const submit = el('button', { class: 'btn block', type: 'submit' }, 'Create my account');

  return el('form', { onsubmit: async (e) => {
    e.preventDefault();
    setBusy(submit, true, 'Creating account…');
    try {
      const res = await api.post('/api/auth/signup', {
        name: name.value,
        email: email.value,
        password: password.value,
        school: school.value,
        course: course.value,
        yearLevel: year.value,
      });
      toast(`Welcome to AXTUDY, ${res.user.name.split(' ')[0]}!`, 'ok');
      onAuthed(res);
    } catch (err) {
      toast(err.message, 'err');
      setBusy(submit, false);
    }
  } },
    field('Full name', name),
    field('Email', email),
    field('Password', password, 'Minimum 8 characters.'),
    field('School', school),
    el('div', { class: 'grid-2' },
      field('Course', course),
      field('Year level', year)
    ),
    submit,
    el('div', { class: 'auth-foot' },
      'By continuing you agree to AXTUDY PRO terms: ',
      el('span', { class: 'bold', text: '₱49/month after a 3-day free trial. Cancel anytime.' })
    )
  );
}

function showForgot(top, onAuthed) {
  top.innerHTML = '';
  const email = input({ type: 'email', placeholder: 'you@school.edu', required: true });
  const submit = el('button', { class: 'btn block', type: 'submit' }, 'Send reset link');
  const result = el('div', {});

  const form = el('form', { onsubmit: async (e) => {
    e.preventDefault();
    setBusy(submit, true, 'Sending…');
    try {
      const res = await api.post('/api/auth/forgot-password', { email: email.value });
      result.innerHTML = '';
      result.append(el('div', { class: 'demo-chip' },
        el('div', { class: 'bold', text: res.emailed ? 'Check your inbox' : 'Reset link generated' }),
        el('div', { style: 'margin-top:5px', text: res.message }),
        res.devResetLink
          ? el('div', { style: 'margin-top:9px' },
              el('div', { class: 'tiny muted', text: 'Dev mode (no email provider configured) — use this link:' }),
              el('a', { class: 'link', href: res.devResetLink, text: 'Open reset form' }))
          : null
      ));
      setBusy(submit, false);
      toast('Reset instructions ready.', 'ok');
    } catch (err) {
      toast(err.message, 'err');
      setBusy(submit, false);
    }
  } },
    field('Email', email),
    submit
  );

  top.append(
    logo(),
    el('h1', { class: 'auth-title', text: 'Reset password' }),
    el('p', { class: 'auth-sub', text: 'We will send you a secure link to set a new password.' }),
    el('div', { class: 'auth-card' }, form, result),
    el('div', { class: 'auth-foot' },
      el('button', { class: 'link', text: '← Back to sign in', onclick: () => renderAuth(document.getElementById('root'), { onAuthed }) })
    )
  );
  top.append(el('div', { class: 'auth-foot' }));
}

function renderReset(top, token, onAuthed) {
  const password = input({ type: 'password', placeholder: 'New password', minlength: '8', required: true });
  const confirm = input({ type: 'password', placeholder: 'Repeat new password', minlength: '8', required: true });
  const submit = el('button', { class: 'btn block', type: 'submit' }, 'Set new password');

  const form = el('form', { onsubmit: async (e) => {
    e.preventDefault();
    if (password.value !== confirm.value) return toast('Passwords do not match.', 'err');
    setBusy(submit, true, 'Saving…');
    try {
      await api.post('/api/auth/reset-password', { token, password: password.value });
      toast('Password updated. Please sign in.', 'ok');
      history.replaceState(null, '', location.pathname);
      renderAuth(document.getElementById('root'), { onAuthed });
    } catch (err) {
      toast(err.message, 'err');
      setBusy(submit, false);
    }
  } },
    field('New password', password, 'Minimum 8 characters.'),
    field('Confirm password', confirm),
    submit
  );

  top.append(
    logo(),
    el('h1', { class: 'auth-title', text: 'Choose a new password' }),
    el('p', { class: 'auth-sub', text: 'Your reset link is valid for 24 hours.' }),
    el('div', { class: 'auth-card' }, form)
  );
  top.append(el('div', { class: 'auth-foot' }));
}
