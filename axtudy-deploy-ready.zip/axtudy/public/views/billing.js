/**
 * AXTUDY — billing UI (AXTUDY PRO · ₱49/month · 3-day free trial).
 * Shows the price and trial terms before any commitment, then calls the
 * backend. Real payments go through PayMongo when keys are configured;
 * otherwise the backend runs a clearly-labelled simulated checkout.
 */
import { api, el, esc, icon, sheet, toast, setBusy, peso, fmtDate, store, notifyShell } from '../core.js';

const PRO_FEATURES = [
  'Unlimited AI summaries, reviewers, quizzes & flashcards',
  'Upload as many PDFs, slide decks and images as you need',
  'Ask unlimited questions about every material you upload',
  'Up to 25 quiz questions and 60 flashcards per generation',
  'Bigger uploads (25 MB per file vs 8 MB on Free)',
  'Priority AI processing',
];

export function proCard({ compact = false } = {}) {
  const sub = store.subscription || {};
  const price = sub.pricePhp ?? 49;
  const trialDays = sub.trialDays ?? 3;
  return el('div', { class: 'pro-card' },
    el('h2', {}, icon('crown', 'brand-crown'), 'AXTUDY PRO'),
    el('div', { class: 'pro-price' },
      el('span', { class: 'amt', text: peso(price) }),
      el('span', { class: 'per', text: '/ month' })
    ),
    el('div', { style: 'font-size:12.5px;font-weight:650;opacity:.95', text: `${trialDays}-day free trial — cancel anytime before it ends and pay nothing.` }),
    compact ? null : el('ul', { class: 'pro-feats' },
      PRO_FEATURES.map((f) => el('li', {}, icon('check'), el('span', { text: f })))
    ),
    el('div', { class: 'terms', text: `After the ${trialDays}-day trial: ${peso(price)} per month, billed monthly, cancel anytime. Prices in Philippine pesos and inclusive of applicable taxes.` })
  );
}

export function openUpgradeSheet({ reason = '', onDone } = {}) {
  const sub = store.subscription || {};
  const price = sub.pricePhp ?? 49;
  const trialDays = sub.trialDays ?? 3;
  const eligible = sub.trialEligible !== false;

  const body = el('div', { class: 'stack' },
    reason ? el('div', { class: 'card tight', style: 'border-color:var(--brand-300);background:var(--brand-tint)' },
      el('div', { class: 'row', style: 'gap:8px;align-items:flex-start' },
        icon('sparkle', 'brand-crown'),
        el('div', { style: 'font-size:13px;font-weight:650;color:var(--brand-700)', text: reason })
      )) : null,
    proCard(),
    el('div', { class: 'card tight' },
      el('div', { class: 'section-title', style: 'margin:0 0 8px', text: 'Before you subscribe' }),
      el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Trial length' }), el('span', { class: 'v', text: `${trialDays} days, free` })),
      el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Price after trial' }), el('span', { class: 'v', text: `${peso(price)} / month` })),
      el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Billing' }), el('span', { class: 'v', text: 'Monthly, auto-renews' })),
      el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Cancel' }), el('span', { class: 'v', text: 'Anytime, keeps access till period end' })),
      sub.providers?.simulated
        ? el('div', { class: 'tiny muted', style: 'margin-top:9px', text: 'Note: this build has no payment keys configured, so checkout is simulated and activates PRO instantly for testing. Add PayMongo keys in .env for real payments.' })
        : el('div', { class: 'tiny muted', style: 'margin-top:9px', text: 'You will be redirected to a secure PayMongo checkout (card, GCash, Maya, GrabPay).' })
    )
  );

  const actions = [];
  if (eligible || sub.isPro === false) {
    actions.push({
      label: `Start ${trialDays}-day free trial`,
      variant: '',
      onClick: async (btn) => {
        setBusy(btn, true, 'Starting trial…');
        try {
          const res = await api.post('/api/billing/trial', {});
          store.subscription = res.subscription;
          notifyShell();
          toast(res.message, 'ok');
          if (onDone) await onDone();
          return false;
        } catch (err) {
          setBusy(btn, false);
          toast(err.message, 'err');
          return true;
        }
      },
    });
  }
  actions.push({
    label: `Subscribe · ${peso(price)}/month`,
    variant: 'gold',
    onClick: async (btn) => {
      setBusy(btn, true, 'Starting checkout…');
      try {
        const res = await api.post('/api/billing/checkout', {});
        if (res.checkout?.mode === 'paymongo' && res.checkout.checkoutUrl) {
          toast('Redirecting to PayMongo…', 'info');
          window.location.href = res.checkout.checkoutUrl;
          return true;
        }
        store.subscription = res.subscription;
        notifyShell();
        toast(res.message || 'AXTUDY PRO activated.', 'ok');
        if (onDone) await onDone();
        return false;
      } catch (err) {
        setBusy(btn, false);
        toast(err.message, 'err');
        return true;
      }
    },
  });

  sheet({ title: 'Upgrade to AXTUDY PRO', body, actions });
}

/** Subscription status card used on the Profile screen. */
export function subscriptionCard({ onChange } = {}) {
  const sub = store.subscription || {};
  const usage = store.usage || {};
  const price = sub.pricePhp ?? 49;
  const trialDays = sub.trialDays ?? 3;

  const statusLabel = {
    none: 'Free plan',
    trialing: `Pro trial — ${sub.daysLeft} day${sub.daysLeft === 1 ? '' : 's'} left`,
    active: 'AXTUDY PRO — active',
    canceled: 'AXTUDY PRO — canceled, access until period end',
    past_due: 'PAYMENT FAILED — please update payment',
    expired: 'PRO expired — back on Free plan',
  }[sub.status] || 'Free plan';

  const card = el('div', { class: 'card' });
  card.append(
    el('div', { class: 'card-head' },
      el('h2', { text: 'Subscription' }),
      el('span', { class: `plan-badge ${sub.isPro ? 'pro' : ''}`, text: sub.isPro ? 'PRO' : 'FREE' })
    ),
    el('div', { class: 'row between', style: 'gap:10px;align-items:flex-start;margin-bottom:10px' },
      el('div', {},
        el('div', { style: 'font-weight:700;font-size:14px', text: statusLabel }),
        el('div', { class: 'small muted', text: sub.isTrialing
          ? `Trial ends ${fmtDate(sub.trialEndsAt, { withTime: false })} then ${peso(price)}/month`
          : sub.plan === 'pro'
            ? `Renews ${fmtDate(sub.currentPeriodEnd, { withTime: false })} · ${peso(price)}/month`
            : `AXTUDY PRO is ${peso(price)}/month with a ${trialDays}-day free trial.` })
      )
    )
  );

  // usage bars
  const limits = usage.limits || {};
  const used = usage.used || {};
  const rows = [
    ['AI results', used.aiGenerations, limits.aiGenerationsPerMonth],
    ['Uploads', used.uploads, limits.uploadsPerMonth],
    ['Questions', used.questions, limits.questionsPerMonth],
    ['Materials stored', used.materialsStored, limits.materialsStored],
  ];
  for (const [label, u, cap] of rows) {
    const pctVal = cap === null || cap === undefined ? 0 : Math.min(100, Math.round(((u || 0) / cap) * 100));
    card.append(el('div', { class: 'usage-row' },
      el('div', { class: 'lbl' },
        el('span', { text: label }),
        el('span', { class: 'muted', text: cap === null || cap === undefined ? `${u || 0} · unlimited` : `${u || 0} / ${cap}` })
      ),
      el('div', { class: 'bar-track' },
        el('div', { class: `bar-fill ${pctVal >= 100 ? 'full' : ''}`, style: `width:${cap === null || cap === undefined ? 6 : Math.max(3, pctVal)}%` })
      )
    ));
  }

  const btns = el('div', { class: 'btn-row', style: 'margin-top:14px' });
  if (!sub.isPro) {
    btns.append(el('button', {
      class: 'btn block', html: `${icon('crown')} <span>Upgrade to PRO</span>`,
      onclick: () => openUpgradeSheet({ onDone: onChange }),
    }));
  } else if (sub.status === 'canceled') {
    btns.append(
      el('button', { class: 'btn', text: 'Resume subscription', onclick: () => billingAction('resume', btn2 => btn2, onChange) }),
    );
  } else {
    btns.append(el('button', {
      class: 'btn danger', text: 'Cancel subscription',
      onclick: async (e) => {
        const btn = e.currentTarget;
        setBusy(btn, true, 'Canceling…');
        try {
          const res = await api.post('/api/billing/cancel', {});
          store.subscription = res.subscription;
          notifyShell();
          toast(res.message, 'warn');
          onChange?.();
        } catch (err) { toast(err.message, 'err'); setBusy(btn, false); }
      },
    }));
  }
  card.append(btns);

  if (sub.providers?.simulated) {
    card.append(el('button', {
      class: 'link tiny muted', style: 'margin-top:10px',
      text: 'Dev: reset to Free plan and re-test the trial',
      onclick: async (e) => {
        try {
          const res = await api.post('/api/billing/reset', {});
          store.subscription = res.subscription;
          notifyShell();
          toast(res.message, 'info');
          onChange?.();
        } catch (err) { toast(err.message, 'err'); }
      },
    }));
  }
  return card;
}

async function billingAction(action, _unused, onChange) {
  try {
    const res = await api.post(`/api/billing/${action}`, {});
    store.subscription = res.subscription;
    notifyShell();
    toast(res.message, 'ok');
    onChange?.();
  } catch (err) { toast(err.message, 'err'); }
}

/** Shown when the backend returns a 402 LIMIT_REACHED. */
export function handleLimitError(err) {
  if (!err?.isUpgrade && !err?.isLimit) return false;
  openUpgradeSheet({ reason: err.message, onDone: () => location.reload() });
  return true;
}
