/**
 * AXTUDY — Class / schedule manager.
 */
import {
  api, el, esc, icon, sheet, toast, store, confirmDialog, setBusy, closeSheet,
  fmtTime, DAY_SHORT,
} from '../core.js';

const COLORS = ['#4F46E5', '#0EA5E9', '#10B981', '#F59E0B', '#EC4899', '#8B5CF6', '#EF4444', '#14B8A6'];

export function openClassSheet({ klass = null, onSaved } = {}) {
  const editing = Boolean(klass);
  const c = klass || {};

  const subjectName = el('input', { placeholder: 'e.g. Data Structures & Algorithms', value: c.subjectName || '', required: true, maxlength: '120' });
  const subjectCode = el('input', { placeholder: 'e.g. CS 201', value: c.subjectCode || '', maxlength: '40' });
  const instructor = el('input', { placeholder: 'e.g. Prof. Dela Cruz', value: c.instructor || '', maxlength: '120' });
  const room = el('input', { placeholder: 'e.g. Lab 3B', value: c.room || '', maxlength: '80' });
  const day = el('select', {}, DAY_SHORT.map((d, i) =>
    el('option', { value: String(i), selected: (c.dayOfWeek ?? new Date().getDay()) === i }, ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][i])));
  const start = el('input', { type: 'time', value: c.startTime || '08:00', required: true });
  const end = el('input', { type: 'time', value: c.endTime || '09:30', required: true });
  let color = c.color || COLORS[Math.floor(Math.random() * COLORS.length)];

  const swatches = el('div', { class: 'row wrap', style: 'gap:8px' },
    COLORS.map((col) => el('button', {
      type: 'button', 'aria-label': `Colour ${col}`,
      style: `width:30px;height:30px;border-radius:10px;background:${col};border:2.5px solid ${col === color ? 'var(--ink)' : 'transparent'};cursor:pointer`,
      onclick: (e) => {
        color = col;
        [...swatches.children].forEach((b, i) => { b.style.borderColor = COLORS[i] === color ? 'var(--ink)' : 'transparent'; });
      },
    }))
  );

  const body = el('div', {},
    el('div', { class: 'field' }, el('label', { text: 'Subject name *' }), subjectName),
    el('div', { class: 'grid-2' },
      el('div', { class: 'field' }, el('label', { text: 'Subject code' }), subjectCode),
      el('div', { class: 'field' }, el('label', { text: 'Day' }), day)
    ),
    el('div', { class: 'grid-2' },
      el('div', { class: 'field' }, el('label', { text: 'Start time *' }), start),
      el('div', { class: 'field' }, el('label', { text: 'End time *' }), end)
    ),
    el('div', { class: 'field' }, el('label', { text: 'Instructor' }), instructor),
    el('div', { class: 'field' }, el('label', { text: 'Room' }), room),
    el('div', { class: 'field' }, el('label', { text: 'Colour' }), swatches)
  );

  const save = async (btn) => {
    const payload = {
      subjectName: subjectName.value.trim(),
      subjectCode: subjectCode.value.trim(),
      instructor: instructor.value.trim(),
      room: room.value.trim(),
      dayOfWeek: Number(day.value),
      startTime: start.value,
      endTime: end.value,
      color,
    };
    if (!payload.subjectName) { toast('Please enter the subject name.', 'err'); return true; }
    if (payload.endTime <= payload.startTime) { toast('End time must be after the start time.', 'err'); return true; }
    setBusy(btn, true, editing ? 'Saving…' : 'Adding…');
    try {
      if (editing) await api.patch(`/api/classes/${c.id}`, payload);
      else await api.post('/api/classes', payload);
      toast(editing ? 'Class updated.' : 'Class added.', 'ok');
      await onSaved?.();
      return false;
    } catch (err) {
      setBusy(btn, false);
      toast(err.message, 'err');
      return true;
    }
  };

  const actions = [{ label: editing ? 'Save changes' : 'Add class', variant: '', onClick: save }];
  if (editing) {
    actions.unshift({
      label: 'Delete', variant: 'danger', close: false,
      onClick: async () => {
        const yes = await confirmDialog({
          title: 'Delete class?',
          message: `"${c.subjectName}" will be removed from your schedule. Tasks linked to it are kept.`,
        });
        if (!yes) return true;
        try {
          await api.del(`/api/classes/${c.id}`);
          toast('Class deleted.', 'ok');
          closeSheet();
          await onSaved?.();
        } catch (err) { toast(err.message, 'err'); }
        return true;
      },
    });
  }

  sheet({ title: editing ? 'Edit class' : 'New class', body, actions });
}

export async function renderClasses(root, { navigate, refresh } = {}) {
  let data = null;

  async function load() {
    root.innerHTML = '';
    root.append(el('div', { class: 'loading' }, el('div', { class: 'spinner dark' }), el('div', { text: 'Loading schedule…' })));
    try {
      data = await api.get('/api/classes');
      store.classes = data.classes;
    } catch (err) {
      root.innerHTML = '';
      root.append(el('div', { class: 'empty' }, el('p', { text: err.message }),
        el('button', { class: 'btn', text: 'Retry', onclick: load })));
      return;
    }
    paint();
  }

  function paint() {
    root.innerHTML = '';
    const todayIndex = new Date().getDay();
    root.append(el('div', { class: 'page-head row between' },
      el('div', {},
        el('h1', { text: 'Classes' }),
        el('p', { text: `${data.classes.length} subject${data.classes.length === 1 ? '' : 's'} this semester` })
      ),
      el('button', {
        class: 'btn', html: `${icon('plus')}<span>New</span>`,
        onclick: () => openClassSheet({ onSaved: load }),
      })
    ));

    if (!data.classes.length) {
      root.append(el('div', { class: 'empty' },
        el('div', { class: 'em', text: '📚' }),
        el('p', { text: 'No classes yet. Add your subjects to see them on your dashboard.' }),
        el('button', { class: 'btn', text: 'Add my first class', onclick: () => openClassSheet({ onSaved: load }) })
      ));
      return;
    }

    const order = [...data.byDay.slice(todayIndex), ...data.byDay.slice(0, todayIndex)];
    for (const day of order) {
      if (!day.classes.length) continue;
      const isToday = day.dayOfWeek === todayIndex;
      root.append(el('div', { class: 'section-title row', style: 'gap:7px' },
        el('span', { text: isToday ? `Today · ${day.dayName}` : day.dayName }),
        isToday ? el('span', { class: 'tag done', text: 'TODAY' }) : null
      ));
      const list = el('div', { class: 'list' });
      for (const c of day.classes) {
        list.append(el('div', {
          class: 'item',
          onclick: () => openClassSheet({ klass: c, onSaved: load }),
        },
          el('div', { class: 'bar', style: `background:${c.color}` }),
          el('div', { class: 'body' },
            el('div', { class: 't', text: c.subjectName }),
            el('div', { class: 'row wrap', style: 'gap:8px;margin-top:4px' },
              el('span', { class: 'tiny muted', text: `${fmtTime(c.startTime)} – ${fmtTime(c.endTime)}` }),
              c.room ? el('span', { class: 'tiny muted', text: `· ${c.room}` }) : null,
              c.instructor ? el('span', { class: 'tiny muted', text: `· ${c.instructor}` }) : null
            )
          ),
          c.subjectCode ? el('span', { class: 'tag medium', text: c.subjectCode }) : null
        ));
      }
      root.append(list);
    }

    root.append(el('div', { class: 'section-title', text: 'Week overview' }));
    root.append(el('div', { class: 'card tight' },
      el('div', { class: 'stack', style: 'gap:8px' },
        data.byDay.slice(1).concat(data.byDay[0]).map((d) => el('div', { class: 'row between' },
          el('span', { class: 'small bold', style: 'min-width:46px', text: DAY_SHORT[d.dayOfWeek] }),
          el('div', { class: 'grow row wrap', style: 'gap:5px' },
            d.classes.length
              ? d.classes.slice(0, 4).map((c) => el('span', {
                  class: 'tag', style: `background:${c.color}22;color:${c.color}`,
                  text: c.subjectCode || c.subjectName.slice(0, 12),
                }))
              : el('span', { class: 'tiny muted', text: '—' })
          )
        ))
      )
    ));
  }

  await load();
}
