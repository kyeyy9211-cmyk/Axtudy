/**
 * AXTUDY — Home dashboard.
 */
import {
  api, el, esc, icon, toast, store, fmtWhen, fmtDate, fmtTime,
  greeting, setBusy,
} from '../core.js';
import { openAssignmentSheet } from './tasks.js';
import { openClassSheet } from './classes.js';
import { handleLimitError, openUpgradeSheet } from './billing.js';

const priorityTag = (a) => {
  if (a.type === 'exam') return el('span', { class: 'tag exam', text: 'EXAM' });
  if (a.priority === 'high') return el('span', { class: 'tag high', text: 'HIGH' });
  if (a.priority === 'low') return el('span', { class: 'tag low', text: 'LOW' });
  return el('span', { class: 'tag medium', text: 'MED' });
};

export function assignmentRow(a, { onToggle, onEdit } = {}) {
  const barColor = a.isOverdue ? 'var(--danger)'
    : a.type === 'exam' ? '#F59E0B'
    : a.priority === 'high' ? '#DC2626'
    : a.priority === 'low' ? 'var(--line-2)' : 'var(--brand)';

  const row = el('div', { class: `item ${a.status === 'completed' ? 'done' : ''}` },
    onToggle ? el('button', {
      class: `check ${a.status === 'completed' ? 'on' : ''}`,
      'aria-label': a.status === 'completed' ? 'Mark as pending' : 'Mark as completed',
      html: icon('check'),
      onclick: async (e) => {
        const btn = e.currentTarget;
        btn.disabled = true;
        try {
          const res = await api.post(`/api/assignments/${a.id}/toggle`, {});
          onToggle(res.assignment);
        } catch (err) {
          btn.disabled = false;
          toast(err.message, 'err');
        }
      },
    }) : null,
    el('div', { class: 'bar', style: `background:${barColor}` }),
    el('div', { class: 'body', onclick: onEdit ? () => onEdit(a) : null },
      el('div', { class: 't', text: a.title }),
      el('div', { class: 'row wrap', style: 'gap:6px;margin-top:5px' },
        priorityTag(a),
        a.subject ? el('span', { class: 'tiny muted', text: a.subject }) : null,
        el('span', { class: `tiny ${a.isOverdue ? 'bold' : 'muted'}`, style: a.isOverdue ? 'color:var(--danger)' : '', text: a.isOverdue ? `Overdue · ${fmtWhen(a.dueAt)}` : fmtWhen(a.dueAt) })
      )
    ),
    el('button', {
      class: 'btn icon', style: 'width:32px;height:32px;border-radius:10px', html: icon('edit'), 'aria-label': 'Edit',
      onclick: () => onEdit?.(a),
    })
  );
  return row;
}

export async function renderHome(root, { navigate, refresh }) {
  root.innerHTML = '';
  root.append(el('div', { class: 'loading' }, el('div', { class: 'spinner dark' }), el('div', { text: 'Loading your dashboard…' })));

  let data;
  try {
    data = await api.get('/api/dashboard');
  } catch (err) {
    root.innerHTML = '';
    root.append(el('div', { class: 'empty' },
      el('div', { class: 'em', text: '⚠️' }),
      el('p', { text: err.message }),
      el('button', { class: 'btn', text: 'Retry', onclick: () => renderHome(root, { navigate, refresh }) })
    ));
    return;
  }

  store.subscription = data.subscription;
  store.usage = data.usage;
  store.aiEngine = data.aiEngine;
  store.user = data.user;

  const { stats } = data;
  const firstName = (store.user?.name || 'Student').split(' ')[0];
  root.innerHTML = '';

  /* hero */
  root.append(el('div', { class: 'hero' },
    el('h1', { text: `${greeting()}, ${firstName} 👋` }),
    el('p', { text: `${data.today.dayName} · ${new Date(data.today.date).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}` }),
    el('div', { class: 'quick' },
      el('button', { html: `${icon('sparkle')}<span>Study Assistant</span>`, onclick: () => navigate('study') }),
      el('button', { html: `${icon('plus')}<span>Add Task</span>`, onclick: () => openAssignmentSheet({ classes: store.classes, onSaved: () => refresh() }) }),
      el('button', { html: `${icon('clock')}<span>My Classes</span>`, onclick: () => navigate('classes') })
    )
  ));

  /* stats */
  root.append(el('div', { class: 'stats mb' },
    el('div', { class: 'stat' }, el('div', { class: 'n', text: String(stats.dueToday) }), el('div', { class: 'l', text: 'Due today' })),
    el('div', { class: `stat ${stats.overdue ? 'warn' : ''}` }, el('div', { class: 'n', text: String(stats.overdue) }), el('div', { class: 'l', text: 'Overdue' })),
    el('div', { class: 'stat ok' }, el('div', { class: 'n', text: String(data.todayClasses.length) }), el('div', { class: 'l', text: 'Classes today' }))
  ));

  /* free-plan nudge */
  if (!data.subscription.isPro) {
    const u = data.usage;
    const aiLeft = Math.max(0, (u.limits.aiGenerationsPerMonth ?? 0) - (u.used.aiGenerations || 0));
    root.append(el('div', { class: 'card tight mb', style: 'border-color:var(--brand-300);background:linear-gradient(135deg,#EEF2FF,#F5F3FF)' },
      el('div', { class: 'row between', style: 'gap:10px' },
        el('div', { class: 'grow' },
          el('div', { style: 'font-weight:750;font-size:13.5px', text: `You are on the Free plan · ${aiLeft} AI result${aiLeft === 1 ? '' : 's'} left this month` }),
          el('div', { class: 'small muted', text: `Unlock unlimited with AXTUDY PRO — ₱${data.subscription.pricePhp}/month after a ${data.subscription.trialDays}-day free trial.` })
        ),
        el('button', { class: 'btn sm gold', text: 'Upgrade', onclick: () => openUpgradeSheet({ onDone: refresh }) })
      )
    ));
  }

  /* today's classes */
  const todaySection = el('div', { class: 'section' },
    el('div', { class: 'section-title', text: "Today's classes" })
  );
  if (data.todayClasses.length) {
    for (const c of data.todayClasses) {
      todaySection.append(el('div', { class: 'item' },
        el('div', { class: 'bar', style: `background:${c.color}` }),
        el('div', { class: 'body' },
          el('div', { class: 't', text: c.subjectName }),
          el('div', { class: 'row wrap', style: 'gap:8px;margin-top:4px' },
            el('span', { class: 'tiny muted', text: `${fmtTime(c.startTime)} – ${fmtTime(c.endTime)}` }),
            c.room ? el('span', { class: 'tiny muted', text: `· ${c.room}` }) : null,
            c.instructor ? el('span', { class: 'tiny muted', text: `· ${c.instructor}` }) : null
          )
        ),
        c.subjectCode ? el('span', { class: 'tag medium', text: c.subjectCode }) : null
      ));
    }
  } else {
    todaySection.append(el('div', { class: 'empty' },
      el('div', { class: 'em', text: '🎉' }),
      el('p', { text: 'No classes today. Enjoy the free time!' }),
      el('button', { class: 'btn sm soft', text: 'Add a class', onclick: () => openClassSheet({ onSaved: refresh }) })
    ));
  }
  root.append(todaySection);

  /* today's due work */
  if (data.dueToday.length) {
    const s = el('div', { class: 'section' }, el('div', { class: 'section-title', text: 'Due today' }));
    for (const a of data.dueToday) {
      s.append(assignmentRow(a, {
        onToggle: () => refresh(),
        onEdit: (item) => openAssignmentSheet({ assignment: item, classes: store.classes, onSaved: refresh }),
      }));
    }
    root.append(s);
  }

  /* upcoming assignments */
  const up = el('div', { class: 'section' },
    el('div', { class: 'row between' },
      el('div', { class: 'section-title', text: 'Upcoming assignments' }),
      el('button', { class: 'link', text: 'See all →', onclick: () => navigate('tasks') })
    )
  );
  if (data.upcomingAssignments.length) {
    for (const a of data.upcomingAssignments) {
      up.append(assignmentRow(a, {
        onToggle: () => refresh(),
        onEdit: (item) => openAssignmentSheet({ assignment: item, classes: store.classes, onSaved: refresh }),
      }));
    }
  } else {
    up.append(el('div', { class: 'empty' }, el('p', { text: 'Nothing coming up in the next 7 days.' })));
  }
  root.append(up);

  /* upcoming exams */
  const ex = el('div', { class: 'section' },
    el('div', { class: 'section-title', text: 'Upcoming exams' })
  );
  if (data.upcomingExams.length) {
    for (const a of data.upcomingExams) {
      ex.append(el('div', { class: 'item' },
        el('div', { class: 'bar', style: 'background:#F59E0B' }),
        el('div', { class: 'body' },
          el('div', { class: 't', text: a.title }),
          el('div', { class: 'row wrap', style: 'gap:6px;margin-top:5px' },
            el('span', { class: 'tag exam', text: 'EXAM' }),
            el('span', { class: 'tiny muted', text: `${fmtDate(a.dueAt)} · in ${Math.max(0, a.daysUntilDue)} day${a.daysUntilDue === 1 ? '' : 's'}` })
          )
        ),
        el('button', { class: 'btn xs soft', text: 'Study', onclick: () => navigate('study') })
      ));
    }
  } else {
    ex.append(el('div', { class: 'empty' }, el('p', { text: 'No exams scheduled. Add one from Tasks.' })));
  }
  root.append(ex);

  /* progress + engine footer */
  root.append(el('div', { class: 'card' },
    el('div', { class: 'card-head' }, el('h2', { text: 'This semester' })),
    el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Completed tasks' }), el('span', { class: 'v', text: String(stats.completed) })),
    el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Pending tasks' }), el('span', { class: 'v', text: String(stats.pendingAssignments) })),
    el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Study materials' }), el('span', { class: 'v', text: String(stats.materials) })),
    el('div', { class: 'kv' }, el('span', { class: 'k', text: 'AI results generated' }), el('span', { class: 'v', text: String(stats.aiOutputs) })),
    el('div', { class: 'kv' }, el('span', { class: 'k', text: 'AI engine' }), el('span', { class: 'v', text: data.aiEngine.label }))
  ));
}
