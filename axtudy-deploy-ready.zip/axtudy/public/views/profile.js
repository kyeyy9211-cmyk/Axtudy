/**
 * AXTUDY — Student profile, account settings and subscription management.
 */
import {
  api, el, esc, icon, toast, store, setBusy, sheet, confirmDialog, fmtDate,
} from '../core.js';
import { subscriptionCard, openUpgradeSheet } from './billing.js';

export async function renderProfile(root, { navigate, refresh, onLogout } = {}) {
  root.innerHTML = '';
  root.append(el('div', { class: 'loading' }, el('div', { class: 'spinner dark' }), el('div', { text: 'Loading your profile…' })));

  let data;
  try {
    data = await api.get('/api/auth/me');
  } catch (err) {
    root.innerHTML = '';
    root.append(el('div', { class: 'empty' }, el('p', { text: err.message }),
      el('button', { class: 'btn', text: 'Retry', onclick: () => renderProfile(root, { navigate, refresh, onLogout }) })));
    return;
  }
  store.user = data.user;
  store.subscription = data.subscription;
  store.usage = data.usage;

  const rerender = () => renderProfile(root, { navigate, refresh, onLogout });
  const u = data.user;
  const sub = data.subscription;

  root.innerHTML = '';

  /* identity */
  root.append(el('div', { class: 'card mb' },
    el('div', { class: 'row', style: 'gap:14px' },
      el('div', { class: 'avatar', style: `background:${u.avatarColor}` , text: (u.name || 'S').trim().charAt(0).toUpperCase() }),
      el('div', { class: 'grow' },
        el('div', { style: 'font-size:18px;font-weight:800;letter-spacing:-.4px', text: u.name || 'Student' }),
        el('div', { class: 'small muted truncate', text: u.email }),
        el('div', { class: 'row wrap', style: 'gap:6px;margin-top:7px' },
          el('span', { class: `plan-badge ${sub.isPro ? 'pro' : ''}`, text: sub.isPro ? 'AXTUDY PRO' : 'FREE PLAN' }),
          u.yearLevel ? el('span', { class: 'tag low', text: u.yearLevel }) : null
        )
      ),
      el('button', {
        class: 'btn icon', html: icon('edit'), 'aria-label': 'Edit profile',
        onclick: () => openProfileSheet(u, rerender),
      })
    ),
    el('div', { class: 'mt' },
      el('div', { class: 'kv' }, el('span', { class: 'k', text: 'School' }), el('span', { class: 'v', text: u.school || '—' })),
      el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Course' }), el('span', { class: 'v', text: u.course || '—' })),
      el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Year level' }), el('span', { class: 'v', text: u.yearLevel || '—' })),
      el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Member since' }), el('span', { class: 'v', text: fmtDate(u.createdAt, { withTime: false }) }))
    )
  ));

  /* subscription */
  root.append(subscriptionCard({ onChange: rerender }));

  /* security */
  root.append(el('div', { class: 'section-title', text: 'Security' }));
  root.append(el('div', { class: 'card' },
    el('div', { class: 'row between' },
      el('div', {},
        el('div', { class: 'bold', style: 'font-size:13.5px', text: 'Password' }),
        el('div', { class: 'small muted', text: 'Use at least 8 characters.' })
      ),
      el('button', { class: 'btn ghost sm', text: 'Change', onclick: () => openPasswordSheet() })
    )
  ));

  /* app info */
  const engine = store.aiEngine || { label: 'Local engine' };
  root.append(el('div', { class: 'section-title', text: 'About AXTUDY' }));
  root.append(el('div', { class: 'card' },
    el('div', { class: 'kv' }, el('span', { class: 'k', text: 'AI engine' }), el('span', { class: 'v', text: engine.label || '—' })),
    el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Plan price' }), el('span', { class: 'v', text: `₱${sub.pricePhp}/month` })),
    el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Free trial' }), el('span', { class: 'v', text: `${sub.trialDays} days` })),
    el('div', { class: 'kv' }, el('span', { class: 'k', text: 'Payments' }), el('span', { class: 'v', text: sub.providers?.simulated ? 'Simulated (dev)' : 'PayMongo' })),
    el('button', {
      class: 'btn ghost block', style: 'margin-top:12px',
      html: `${icon('refresh')}<span>Reload demo data</span>`,
      onclick: async (e) => {
        const btn = e.currentTarget;
        const yes = await confirmDialog({
          title: 'Reload demo data?',
          message: 'This replaces your classes, tasks and materials with the AXTUDY demo set.',
          confirmLabel: 'Reload',
          danger: false,
        });
        if (!yes) return;
        setBusy(btn, true, 'Reloading…');
        try {
          await api.post('/api/demo/reseed', {});
          toast('Demo data reloaded.', 'ok');
          refresh?.();
        } catch (err) {
          setBusy(btn, false);
          toast(err.message, 'err');
        }
      },
    })
  ));

  /* logout */
  root.append(el('div', { class: 'mt' },
    el('button', {
      class: 'btn danger block',
      html: `${icon('logout')}<span>Log out</span>`,
      onclick: async () => {
        try { await api.post('/api/auth/logout', {}); } catch { /* ignore */ }
        onLogout?.();
      },
    })
  ));

  root.append(el('div', { class: 'auth-foot', text: 'AXTUDY v1.0 · Built for Filipino college students 🇵🇭' }));
}

function openProfileSheet(u, onSaved) {
  const name = el('input', { value: u.name || '', maxlength: '80', required: true });
  const email = el('input', { type: 'email', value: u.email || '', required: true });
  const school = el('input', { value: u.school || '', maxlength: '120' });
  const course = el('input', { value: u.course || '', maxlength: '120' });
  const year = el('select', {}, ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year', 'Graduate']
    .map((y) => el('option', { value: y, selected: (u.yearLevel || '') === y }, y)));
  const color = el('input', { type: 'color', value: u.avatarColor || '#4F46E5', style: 'height:44px;padding:4px' });

  const body = el('div', {},
    el('div', { class: 'field' }, el('label', { text: 'Full name' }), name),
    el('div', { class: 'field' }, el('label', { text: 'Email' }), email),
    el('div', { class: 'field' }, el('label', { text: 'School' }), school),
    el('div', { class: 'grid-2' },
      el('div', { class: 'field' }, el('label', { text: 'Course' }), course),
      el('div', { class: 'field' }, el('label', { text: 'Year level' }), year)
    ),
    el('div', { class: 'field' }, el('label', { text: 'Avatar colour' }), color)
  );

  sheet({
    title: 'Edit profile',
    body,
    actions: [{
      label: 'Save profile', variant: '',
      onClick: async (btn) => {
        setBusy(btn, true, 'Saving…');
        try {
          await api.patch('/api/auth/profile', {
            name: name.value.trim(),
            email: email.value.trim(),
            school: school.value.trim(),
            course: course.value.trim(),
            yearLevel: year.value,
            avatarColor: color.value,
          });
          toast('Profile saved.', 'ok');
          await onSaved?.();
          return false;
        } catch (err) {
          setBusy(btn, false);
          toast(err.message, 'err');
          return true;
        }
      },
    }],
  });
}

function openPasswordSheet() {
  const current = el('input', { type: 'password', placeholder: 'Current password', required: true });
  const next = el('input', { type: 'password', placeholder: 'New password (min 8 chars)', minlength: '8', required: true });
  const confirm = el('input', { type: 'password', placeholder: 'Repeat new password', minlength: '8', required: true });

  const body = el('div', {},
    el('div', { class: 'field' }, el('label', { text: 'Current password' }), current),
    el('div', { class: 'field' }, el('label', { text: 'New password' }), next),
    el('div', { class: 'field' }, el('label', { text: 'Confirm new password' }), confirm),
    el('div', { class: 'tiny muted', text: 'Changing your password signs you out on other devices.' })
  );

  sheet({
    title: 'Change password',
    body,
    actions: [{
      label: 'Update password', variant: '',
      onClick: async (btn) => {
        if (next.value !== confirm.value) { toast('New passwords do not match.', 'err'); return true; }
        setBusy(btn, true, 'Updating…');
        try {
          await api.post('/api/auth/change-password', {
            currentPassword: current.value,
            newPassword: next.value,
          });
          toast('Password updated.', 'ok');
          return false;
        } catch (err) {
          setBusy(btn, false);
          toast(err.message, 'err');
          return true;
        }
      },
    }],
  });
}
