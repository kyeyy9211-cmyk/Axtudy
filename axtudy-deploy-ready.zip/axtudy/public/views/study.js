/**
 * AXTUDY — AI Study Assistant.
 * Upload materials, generate reviewers/quizzes/flashcards, and ask questions.
 */
import {
  api, el, esc, icon, sheet, toast, store, confirmDialog, setBusy, closeSheet,
  fmtBytes, timeAgo, fmtDate, copyText, ApiError,
} from '../core.js';
import { handleLimitError, openUpgradeSheet } from './billing.js';

const TASKS = [
  { key: 'summarize', name: 'Summarize', desc: 'Short summary + key points', icon: 'file' },
  { key: 'reviewer', name: 'Reviewer', desc: 'Full revision sheet', icon: 'book' },
  { key: 'quiz', name: 'MCQ Quiz', desc: 'Multiple-choice questions', icon: 'quiz' },
  { key: 'truefalse', name: 'True / False', desc: 'Test your recall', icon: 'tf' },
  { key: 'flashcards', name: 'Flashcards', desc: 'Flip-and-learn cards', icon: 'cards' },
  { key: 'explain', name: 'Explain Simply', desc: 'Break down hard topics', icon: 'bulb' },
];

/* ───────────────────────── upload sheet ───────────────────────── */

export function openUploadSheet({ classes = [], onSaved } = {}) {
  let mode = 'file';
  let file = null;

  const drop = el('div', { class: 'file-drop', onclick: () => fileInput.click() },
    el('div', { html: icon('upload', 'brand-crown'), style: 'display:flex;justify-content:center;margin-bottom:7px' }),
    el('div', { class: 'bold', style: 'font-size:13.5px', text: 'Tap to choose a file' }),
    el('div', { class: 'tiny muted', style: 'margin-top:4px', text: 'PDF · PPTX · DOCX · XLSX · TXT · MD · images' })
  );
  const fileInput = el('input', { type: 'file', class: 'hidden', accept: '.pdf,.pptx,.docx,.xlsx,.txt,.md,.csv,.json,.png,.jpg,.jpeg,.webp,.gif,.bmp', onchange: (e) => {
    file = e.target.files?.[0] || null;
    drop.classList.toggle('has-file', Boolean(file));
    drop.innerHTML = '';
    drop.append(
      el('div', { class: 'bold', style: 'font-size:13.5px', text: file ? file.name : 'Tap to choose a file' }),
      el('div', { class: 'tiny muted', style: 'margin-top:3px', text: file ? fmtBytes(file.size) : 'PDF · PPTX · DOCX · XLSX · TXT · MD · images' })
    );
    if (file && !title.value.trim()) title.value = file.name.replace(/\.[^.]+$/, '');
  } });

  const title = el('input', { placeholder: 'e.g. Midterm reviewer — Chapter 5', maxlength: '160' });
  const classSelect = el('select', {},
    el('option', { value: '' }, '— No class —'),
    classes.map((c) => el('option', { value: c.id }, `${c.subjectCode ? `${c.subjectCode} · ` : ''}${c.subjectName}`))
  );
  const notes = el('textarea', { placeholder: 'Paste your notes, a chapter summary, or a transcript here…', maxlength: '400000', style: 'min-height:160px' });

  const filePane = el('div', {}, drop, fileInput,
    el('div', { class: 'field', style: 'margin-top:12px' }, el('label', { text: 'Title' }), title));
  const notePane = el('div', { class: 'hidden' },
    el('div', { class: 'field' }, el('label', { text: 'Title' }), title.cloneNode(false)),
    el('div', { class: 'field' }, el('label', { text: 'Your notes' }), notes));
  // keep a single title input inside the active pane
  const noteTitle = notePane.querySelector('input');

  const seg = el('div', { class: 'seg' },
    el('button', { type: 'button', 'aria-selected': 'true', text: 'Upload file', onclick: (e) => setMode('file', e.currentTarget) }),
    el('button', { type: 'button', 'aria-selected': 'false', text: 'Paste notes', onclick: (e) => setMode('note', e.currentTarget) })
  );

  function setMode(m, btn) {
    mode = m;
    [...seg.children].forEach((b) => b.setAttribute('aria-selected', String(b === btn)));
    filePane.classList.toggle('hidden', m !== 'file');
    notePane.classList.toggle('hidden', m !== 'note');
  }

  const body = el('div', {}, seg, filePane, notePane,
    el('div', { class: 'field', style: 'margin-top:4px' }, el('label', { text: 'Link to a class' }), classSelect),
    el('div', { class: 'tiny muted', text: 'Everything runs server-side. Your file and notes stay private to your account.' })
  );

  const save = async (btn) => {
    setBusy(btn, true, mode === 'file' ? 'Uploading…' : 'Saving…');
    try {
      if (mode === 'note') {
        const t = noteTitle.value.trim() || 'Pasted notes';
        if (notes.value.trim().length < 20) {
          setBusy(btn, false);
          toast('Paste at least a few sentences.', 'err');
          return true;
        }
        await api.post('/api/materials', { title: t, text: notes.value, classId: classSelect.value || null });
      } else {
        if (!file) { setBusy(btn, false); toast('Choose a file first.', 'err'); return true; }
        const fd = new FormData();
        fd.append('file', file);
        fd.append('title', title.value.trim() || file.name);
        fd.append('classId', classSelect.value || '');
        await api.upload('/api/materials', fd);
      }
      toast('Material added to your Study Assistant.', 'ok');
      await onSaved?.();
      return false;
    } catch (err) {
      setBusy(btn, false);
      if (handleLimitError(err)) return false;
      toast(err.message, 'err');
      return true;
    }
  };

  sheet({ title: 'Add study material', body, actions: [{ label: 'Add material', variant: '', onClick: save }] });
}

/* ───────────────────────── study list ───────────────────────── */

export async function renderStudy(root, { navigate, refresh, materialId = '' } = {}) {
  if (materialId) return renderMaterial(root, { navigate, refresh, materialId });

  root.innerHTML = '';
  root.append(el('div', { class: 'loading' }, el('div', { class: 'spinner dark' }), el('div', { text: 'Loading your study library…' })));

  let data;
  let recent;
  try {
    [data, recent] = await Promise.all([
      api.get('/api/materials'),
      api.get('/api/ai/outputs'),
    ]);
  } catch (err) {
    root.innerHTML = '';
    root.append(el('div', { class: 'empty' }, el('p', { text: err.message }),
      el('button', { class: 'btn', text: 'Retry', onclick: () => renderStudy(root, { navigate, refresh }) })));
    return;
  }

  root.innerHTML = '';
  const engine = store.aiEngine || { label: 'AXTUDY Local Study Engine (offline)', online: false };

  root.append(el('div', { class: 'page-head row between' },
    el('div', {},
      el('h1', { text: 'Study Assistant' }),
      el('p', { text: 'Upload once, then summarize, quiz and review.' })
    ),
    el('button', {
      class: 'btn', html: `${icon('plus')}<span>Add</span>`,
      onclick: () => openUploadSheet({ classes: store.classes, onSaved: () => renderStudy(root, { navigate, refresh }) }),
    })
  ));

  root.append(el('div', { class: 'row wrap mb', style: 'gap:7px' },
    el('span', { class: 'engine-pill' },
      el('span', { class: `dot ${engine.online ? '' : 'off'}` }),
      el('span', { text: engine.label })
    ),
    el('span', { class: 'engine-pill', text: `${data.materials.length} material${data.materials.length === 1 ? '' : 's'}` })
  ));

  /* materials */
  root.append(el('div', { class: 'section-title', text: 'Your materials' }));
  if (!data.materials.length) {
    root.append(el('div', { class: 'empty' },
      el('div', { class: 'em', text: '📄' }),
      el('p', { text: 'No materials yet. Upload a PDF, slide deck, image or paste your notes to get started.' }),
      el('button', {
        class: 'btn', text: 'Upload my first material',
        onclick: () => openUploadSheet({ classes: store.classes, onSaved: () => renderStudy(root, { navigate, refresh }) }),
      })
    ));
  } else {
    const list = el('div', { class: 'list' });
    for (const m of data.materials) {
      const iconName = m.kind === 'pdf' ? 'file' : m.kind === 'image' ? 'eye' : m.kind === 'notes' ? 'book' : 'file';
      list.append(el('div', {
        class: 'item', onclick: () => navigate('study', m.id),
      },
        el('div', { class: 'bar', style: 'background:var(--brand)' }),
        el('div', { class: 'body' },
          el('div', { class: 't', text: m.title }),
          el('div', { class: 'row wrap', style: 'gap:7px;margin-top:4px' },
            el('span', { class: 'tag medium', text: m.kind.toUpperCase() }),
            el('span', { class: 'tiny muted', text: m.hasText ? `${m.charCount.toLocaleString()} chars` : 'no text read' }),
            m.sizeBytes ? el('span', { class: 'tiny muted', text: `· ${fmtBytes(m.sizeBytes)}` }) : null,
            el('span', { class: 'tiny muted', text: `· ${timeAgo(m.createdAt)}` })
          )
        ),
        el('button', { class: 'btn icon', html: icon('sparkle'), 'aria-label': 'Open', style: 'width:32px;height:32px;border-radius:10px' })
      ));
    }
    root.append(list);
  }

  /* recent AI results */
  if (recent.outputs.length) {
    root.append(el('div', { class: 'section-title', text: 'Recent AI results' }));
    const list = el('div', { class: 'list' });
    for (const o of recent.outputs.slice(0, 6)) {
      list.append(el('div', {
        class: 'item',
        onclick: () => o.materialId ? navigate('study', o.materialId) : null,
      },
        el('div', { class: 'bar', style: 'background:var(--brand-300)' }),
        el('div', { class: 'body' },
          el('div', { class: 't', text: o.title || o.kind }),
          el('div', { class: 'row wrap', style: 'gap:7px;margin-top:4px' },
            el('span', { class: 'tag low', text: o.kind.toUpperCase() }),
            el('span', { class: 'tiny muted', text: timeAgo(o.createdAt) })
          )
        )
      ));
    }
    root.append(list);
  }

  /* extraction capabilities note */
  const cap = data.capabilities || {};
  if (cap.images === 'none' || cap.pdf === 'none') {
    root.append(el('div', { class: 'card tight mt' },
      el('div', { class: 'small muted' },
        el('strong', { text: 'Reading limits on this server: ' }),
        `PDF ${cap.pdf === 'none' ? 'unsupported' : 'supported'}, Office files ${cap.office === 'none' ? 'unsupported' : 'supported'}, image OCR ${cap.images === 'none' ? 'needs GEMINI_API_KEY' : 'enabled'}.`
      )
    ));
  }
}

/* ───────────────────────── material detail ───────────────────────── */

let activeCount = 8;

async function renderMaterial(root, { navigate, refresh, materialId }) {
  root.innerHTML = '';
  root.append(el('div', { class: 'loading' }, el('div', { class: 'spinner dark' }), el('div', { text: 'Opening material…' })));

  let data;
  try {
    data = await api.get(`/api/materials/${materialId}`);
  } catch (err) {
    root.innerHTML = '';
    root.append(el('div', { class: 'empty' }, el('p', { text: err.message }),
      el('button', { class: 'btn', text: '← Back to Study', onclick: () => navigate('study') })));
    return;
  }

  const { material } = data;
  root.innerHTML = '';

  root.append(el('div', { class: 'row between mb' },
    el('button', { class: 'btn ghost sm', html: `${icon('back')}<span>Back</span>`, onclick: () => navigate('study') }),
    el('div', { class: 'row', style: 'gap:6px' },
      el('button', {
        class: 'btn icon', html: icon('trash'), 'aria-label': 'Delete material',
        onclick: async () => {
          const yes = await confirmDialog({
            title: 'Delete material?',
            message: `"${material.title}" and all AI results for it will be deleted.`,
          });
          if (!yes) return;
          try {
            await api.del(`/api/materials/${material.id}`);
            toast('Material deleted.', 'ok');
            navigate('study');
          } catch (err) { toast(err.message, 'err'); }
        },
      }),
      el('button', { class: 'btn icon', html: icon('refresh'), 'aria-label': 'Ask about this', onclick: () => askAbout(material) })
    )
  ));

  root.append(el('div', { class: 'card mb' },
    el('div', { class: 'row between', style: 'gap:10px;align-items:flex-start' },
      el('div', { class: 'grow' },
        el('h1', { style: 'font-size:19px;font-weight:800;margin:0;letter-spacing:-.4px', text: material.title }),
        el('div', { class: 'row wrap', style: 'gap:7px;margin-top:6px' },
          el('span', { class: 'tag medium', text: material.kind.toUpperCase() }),
          el('span', { class: 'tiny muted', text: material.filename || 'pasted notes' }),
          el('span', { class: 'tiny muted', text: `· ${fmtDate(material.createdAt, { withTime: false })}` })
        )
      )
    ),
    material.hasText
      ? el('div', { class: 'source', style: 'margin-top:12px', text: (material.textContent || '').slice(0, 260) + ((material.textContent || '').length > 260 ? '…' : '') })
      : el('div', { class: 'source', style: 'margin-top:12px;border-left:3px solid var(--danger)', text: material.kind === 'image'
          ? 'This image has no readable text yet. Tap "Read image with AI" below.'
          : 'No readable text was found in this file. Try pasting the notes as text instead.' }),
    (!material.hasText && material.kind === 'image')
      ? el('button', {
          class: 'btn soft block', style: 'margin-top:10px',
          html: `${icon('eye')}<span>Read image with AI</span>`,
          onclick: async (e) => {
            const btn = e.currentTarget;
            setBusy(btn, true, 'Reading image…');
            try {
              const res = await api.post(`/api/materials/${material.id}/vision`, {});
              toast(res.message, res.material.hasText ? 'ok' : 'warn');
              renderMaterial(root, { navigate, refresh, materialId });
            } catch (err) {
              setBusy(btn, false);
              if (handleLimitError(err)) return;
              toast(err.message, 'err');
            }
          },
        })
      : null
  ));

  /* AI action grid */
  root.append(el('div', { class: 'section-title', text: 'Generate study aids' }));
  const grid = el('div', { class: 'ai-actions mb' });
  for (const t of TASKS) {
    grid.append(el('button', {
      class: 'ai-btn',
      onclick: () => runTask(t.key, material, root, { navigate, refresh, materialId }),
    },
      el('div', { html: icon(t.icon) }),
      el('div', { class: 'n', text: t.name }),
      el('div', { class: 'd', text: t.desc })
    ));
  }
  grid.append(el('button', {
    class: 'ai-btn wide',
    onclick: () => askAbout(material),
  },
    el('div', { html: icon('chat') }),
    el('div', { class: 'n', text: 'Ask about this material' }),
    el('div', { class: 'd', text: 'Ask any question — answers come only from what you uploaded.' })
  ));
  root.append(grid);

  /* outputs */
  const outputsHost = el('div', {});
  root.append(el('div', { class: 'section-title', text: `Saved results (${data.outputs.length})` }), outputsHost);

  const paintOutputs = () => {
    outputsHost.innerHTML = '';
    if (!data.outputs.length) {
      outputsHost.append(el('div', { class: 'empty' },
        el('p', { text: 'No results yet. Pick any tool above to generate one.' })));
      return;
    }
    for (const o of data.outputs) outputsHost.append(renderOutput(o, () => {
      data.outputs = data.outputs.filter((x) => x.id !== o.id);
      paintOutputs();
    }));
  };
  paintOutputs();

  async function reloadOutputs() {
    const fresh = await api.get(`/api/materials/${materialId}`);
    data.outputs = fresh.outputs;
    paintOutputs();
  }
  root.__reloadOutputs = reloadOutputs;
}

async function runTask(task, material, root, ctx) {
  const isQuiz = task === 'quiz';
  const isCards = task === 'flashcards';
  const isTF = task === 'truefalse';
  const needsCount = isQuiz || isCards || isTF;

  const body = el('div', {});
  let count = isQuiz || isTF ? 8 : 12;

  if (needsCount) {
    const max = isQuiz || isTF ? (store.usage?.limits?.quizQuestions ?? 10) : (store.usage?.limits?.flashcards ?? 20);
    const range = el('input', { type: 'range', min: '3', max: String(Math.max(3, max)), value: String(Math.min(count, max)) });
    const out = el('div', { class: 'bold', text: String(Math.min(count, max)) });
    range.addEventListener('input', () => { count = Number(range.value); out.textContent = range.value; });
    body.append(
      el('div', { class: 'field' },
        el('label', { text: 'How many items?' }),
        el('div', { class: 'row between' }, range, out)
      ),
      el('div', { class: 'tiny muted', text: `Your plan allows up to ${max} items per generation.` })
    );
  }

  if (task === 'explain') {
    const topic = el('input', { placeholder: 'Which topic should I explain? e.g. memory layout of arrays' });
    body.append(el('div', { class: 'field' }, el('label', { text: 'Topic' }), topic),
      el('div', { class: 'tiny muted', text: 'Leave blank to explain the whole material.' }));
    body.__topic = topic;
  }

  const loading = el('div', { class: 'hidden' },
    el('div', { class: 'spinner dark', style: 'margin:0 auto' }),
    el('div', { class: 'small muted center', style: 'margin-top:9px', text: 'Reading your material and generating…' })
  );
  body.append(loading);

  sheet({
    title: TASK_NAMES[task] || 'Generating',
    body,
    dismissible: false,
    actions: [
      { label: 'Cancel', variant: 'ghost' },
      {
        label: 'Generate',
        variant: '',
        close: false,
        onClick: async (btn) => {
          setBusy(btn, true, 'Generating…');
          loading.classList.remove('hidden');
          try {
            await api.post(`/api/ai/${task}`, {
              materialId: material.id,
              count,
              topic: body.__topic?.value || '',
            });
            closeSheet();
            toast('Generated! Scroll down to see it.', 'ok');
            await root.__reloadOutputs?.();
            if (ctx.refresh) ctx.refresh();
          } catch (err) {
            setBusy(btn, false);
            loading.classList.add('hidden');
            if (handleLimitError(err)) { closeSheet(); return false; }
            toast(err.message, 'err');
            return true;
          }
          return true;
        },
      },
    ],
  });
}

const TASK_NAMES = {
  summarize: 'Summary', reviewer: 'Reviewer', quiz: 'Multiple-choice quiz',
  truefalse: 'True or false', flashcards: 'Flashcards', explain: 'Simple explanation', ask: 'Ask about material',
};

/* ───────────────────────── ask ───────────────────────── */

function askAbout(material) {
  const chatHost = el('div', { class: 'chat' });
  const input = el('input', { placeholder: 'e.g. What is the Big-O of insertion at the tail?', maxlength: '500' });
  const send = el('button', { class: 'btn', html: icon('chat'), 'aria-label': 'Send' });

  const history = [];
  const addBubble = (role, text) => {
    const b = el('div', { class: `bubble ${role}`, text });
    chatHost.append(b);
    chatHost.scrollTop = chatHost.scrollHeight;
    return b;
  };
  addBubble('assistant', `Ask me anything about "${material.title}". I will answer only from your uploaded material.`);

  const body = el('div', {},
    el('div', { class: 'card tight', style: 'padding:0;border:0;box-shadow:none' }, chatHost),
    el('div', { class: 'row', style: 'margin-top:10px' }, input, send),
    el('div', { class: 'tiny muted', style: 'margin-top:7px', text: 'Answers are grounded in your material. Low confidence means the material may not cover it.' })
  );

  async function ask() {
    const q = input.value.trim();
    if (!q) return;
    input.value = '';
    addBubble('user', q);
    const thinking = addBubble('assistant', 'Thinking…');
    send.disabled = true;
    try {
      const res = await api.post('/api/ai/ask', { materialId: material.id, question: q });
      thinking.remove();
      addBubble('assistant', res.output.payload.answer || 'No answer generated.');
      for (const s of (res.output.payload.sources || []).slice(0, 3)) {
        chatHost.append(el('div', { class: 'source' },
          el('div', { class: 'bold tiny', text: s.title || 'Passage' }),
          el('div', { text: s.snippet || '' })
        ));
      }
      if (res.output.payload.confidence) {
        chatHost.append(el('div', { class: 'tiny muted', text: `Confidence: ${res.output.payload.confidence}` }));
      }
      chatHost.scrollTop = chatHost.scrollHeight;
    } catch (err) {
      thinking.remove();
      if (handleLimitError(err)) { closeSheet(); return; }
      toast(err.message, 'err');
    } finally {
      send.disabled = false;
    }
  }

  send.addEventListener('click', ask);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') ask(); });
  sheet({ title: 'Ask about this material', body, onMount: () => setTimeout(() => input.focus(), 120) });
}

/* ───────────────────────── output renderers ───────────────────────── */

function renderOutput(o, onDelete) {
  const p = o.payload || {};
  const card = el('div', { class: 'output mb' });
  const meta = o.engine === 'offline' ? 'Local engine' : o.engine;

  card.append(el('div', { class: 'output-head' },
    el('div', {},
      el('div', { style: 'font-weight:700;font-size:13.5px', text: TASK_NAMES[o.kind] || o.kind }),
      el('div', { class: 'tiny muted', text: `${meta} · ${timeAgo(o.createdAt)}` })
    ),
    el('div', { class: 'row', style: 'gap:5px' },
      el('button', {
        class: 'btn xs ghost', html: icon('copy'), 'aria-label': 'Copy',
        onclick: async () => {
          const ok = await copyText(outputToText(o));
          toast(ok ? 'Copied to clipboard.' : 'Could not copy.', ok ? 'ok' : 'err');
        },
      }),
      el('button', {
        class: 'btn xs danger', html: icon('trash'), 'aria-label': 'Delete',
        onclick: async () => {
          try {
            await api.del(`/api/ai/outputs/${o.id}`);
            toast('Result deleted.', 'ok');
            onDelete?.();
          } catch (err) { toast(err.message, 'err'); }
        },
      })
    )
  ));

  const bodyHost = el('div', { class: 'output-body' });
  card.append(bodyHost);

  switch (o.kind) {
    case 'summarize': bodyHost.append(summaryView(p)); break;
    case 'reviewer': bodyHost.append(reviewerView(p)); break;
    case 'quiz': bodyHost.append(quizRunner(p)); break;
    case 'truefalse': bodyHost.append(tfRunner(p)); break;
    case 'flashcards': bodyHost.append(flashcardDeck(p)); break;
    case 'explain': bodyHost.append(explainView(p)); break;
    case 'ask': {
      bodyHost.append(el('div', { class: 'bubble assistant', style: 'max-width:100%', text: p.answer || '' }));
      for (const s of p.sources || []) {
        bodyHost.append(el('div', { class: 'source' }, el('div', { class: 'bold tiny', text: s.title }), el('div', { text: s.snippet })));
      }
      break;
    }
    default: bodyHost.append(el('pre', { class: 'small mono', text: JSON.stringify(p, null, 2) }));
  }
  return card;
}

function summaryView(p) {
  const host = el('div', {});
  host.append(el('div', { style: 'font-size:14px;line-height:1.65;margin-bottom:12px', text: p.summary || '' }));
  if (p.bullets?.length) {
    host.append(el('div', { class: 'section-title', style: 'margin-top:6px', text: 'Key points' }));
    host.append(el('ul', { class: 'bullets' }, p.bullets.map((b) => el('li', { text: b }))));
  }
  if (p.keyTerms?.length) {
    host.append(el('div', { class: 'section-title', text: 'Key terms' }));
    host.append(el('div', { class: 'pill-row' }, p.keyTerms.map((t) =>
      el('span', { class: 'tag medium', text: typeof t === 'string' ? t : (t.term || '') }))));
  }
  return host;
}

function reviewerView(p) {
  const host = el('div', {});
  if (p.overview) {
    host.append(el('div', { class: 'source', text: p.overview }));
  }
  if (p.keyTerms?.length) {
    host.append(el('div', { class: 'section-title', text: 'Key terms' }));
    const wrap = el('div', {});
    for (const k of p.keyTerms) {
      wrap.append(el('div', { class: 'term-row' },
        el('div', { class: 'k', text: typeof k === 'string' ? k : k.term }),
        el('div', { class: 'v', text: typeof k === 'string' ? '' : k.definition })
      ));
    }
    host.append(wrap);
  }
  if (p.keyPoints?.length) {
    host.append(el('div', { class: 'section-title', text: 'Key points' }));
    host.append(el('ul', { class: 'bullets' }, p.keyPoints.map((b) => el('li', { text: b }))));
  }
  if (p.tips?.length) {
    host.append(el('div', { class: 'section-title', text: 'Study tips' }));
    host.append(el('ul', { class: 'bullets' }, p.tips.map((b) => el('li', { text: b }))));
  }
  return host;
}

function explainView(p) {
  const host = el('div', {});
  if (p.topic) host.append(el('div', { class: 'tag medium mb', text: String(p.topic).slice(0, 60) }));
  host.append(el('div', { style: 'font-size:14px;line-height:1.65', text: p.explanation || '' }));
  if (p.keyPoints?.length) {
    host.append(el('div', { class: 'section-title', text: 'In detail' }));
    host.append(el('ul', { class: 'bullets' }, p.keyPoints.map((b) => el('li', { text: b }))));
  }
  if (p.simpleTerms?.length) {
    host.append(el('div', { class: 'section-title', text: 'Jargon decoded' }));
    const wrap = el('div', {});
    for (const t of p.simpleTerms) {
      wrap.append(el('div', { class: 'term-row' },
        el('div', { class: 'k', text: t.term }),
        el('div', { class: 'v', text: t.simple })
      ));
    }
    host.append(wrap);
  }
  return host;
}

function quizRunner(p) {
  const host = el('div', {});
  const qs = p.questions || [];
  if (!qs.length) {
    host.append(el('div', { class: 'empty' }, el('p', { text: p.note || 'No questions could be generated from this material.' })));
    return host;
  }
  const state = { answers: new Array(qs.length).fill(null), submitted: false };
  const scoreHost = el('div', {});
  const listHost = el('div', {});

  const paint = () => {
    listHost.innerHTML = '';
    qs.forEach((q, qi) => {
      const qc = el('div', { class: 'q-card' },
        el('div', { class: 'q-num', text: `QUESTION ${qi + 1} OF ${qs.length}` }),
        el('div', { class: 'q-text', text: q.question })
      );
      (q.options || []).forEach((opt, oi) => {
        const isPicked = state.answers[qi] === oi;
        const isRight = oi === q.answerIndex;
        let cls = 'opt';
        if (state.submitted) {
          if (isRight) cls += ' correct';
          else if (isPicked) cls += ' wrong';
        } else if (isPicked) cls += ' sel';
        qc.append(el('button', {
          class: cls, disabled: state.submitted,
          onclick: () => { state.answers[qi] = oi; paint(); },
        },
          el('span', { class: 'k', text: String.fromCharCode(65 + oi) }),
          el('span', { class: 'grow', text: opt })
        ));
      });
      if (state.submitted) {
        qc.append(el('div', { class: 'explain', text: q.explanation || (state.answers[qi] === q.answerIndex ? 'Correct!' : 'Review this one.') }));
      }
      listHost.append(qc);
    });
  };

  const paintScore = () => {
    scoreHost.innerHTML = '';
    if (!state.submitted) {
      const answered = state.answers.filter((a) => a !== null).length;
      scoreHost.append(
        el('div', { class: 'progress' }, el('div', { style: `width:${(answered / qs.length) * 100}%` })),
        el('div', { class: 'row between', style: 'margin-top:9px' },
          el('div', { class: 'small muted', text: `${answered} of ${qs.length} answered` }),
          el('button', {
            class: 'btn sm', text: 'Submit answers',
            onclick: () => {
              if (state.answers.some((a) => a === null)) return toast('Answer every question first.', 'warn');
              state.submitted = true;
              const score = qs.filter((q, i) => state.answers[i] === q.answerIndex).length;
              toast(`You scored ${score}/${qs.length} (${Math.round((score / qs.length) * 100)}%)`, score / qs.length >= 0.7 ? 'ok' : 'warn');
              paint(); paintScore();
            },
          })
        )
      );
    } else {
      const score = qs.filter((q, i) => state.answers[i] === q.answerIndex).length;
      const pct = Math.round((score / qs.length) * 100);
      scoreHost.append(el('div', { class: 'card tight', style: 'margin-bottom:12px' },
        el('div', { class: 'row between' },
          el('div', {},
            el('div', { class: 'bold', style: 'font-size:16px', text: `${score} / ${qs.length} correct` }),
            el('div', { class: 'small muted', text: pct >= 70 ? 'Great work — you are ready.' : 'Review the explanations below, then retake.' })
          ),
          el('span', { class: `tag ${pct >= 70 ? 'done' : 'high'}`, text: `${pct}%` })
        ),
        el('div', { class: 'btn-row', style: 'margin-top:11px' },
          el('button', { class: 'btn ghost sm', text: 'Retake', onclick: () => {
            state.submitted = false; state.answers.fill(null); paint(); paintScore();
          } })
        )
      ));
    }
  };

  paintScore(); paint();
  host.append(scoreHost, listHost);
  return host;
}

function tfRunner(p) {
  const host = el('div', {});
  const qs = p.questions || [];
  if (!qs.length) {
    host.append(el('div', { class: 'empty' }, el('p', { text: p.note || 'No statements could be generated.' })));
    return host;
  }
  const answers = new Array(qs.length).fill(null);
  const scored = { done: false };

  const render = () => {
    host.innerHTML = '';
    let correct = 0;
    qs.forEach((q, i) => {
      const picked = answers[i];
      if (scored.done && picked === q.answer) correct++;
      const card = el('div', { class: 'q-card' },
        el('div', { class: 'q-num', text: `STATEMENT ${i + 1}` }),
        el('div', { class: 'q-text', text: q.statement })
      );
      for (const [val, label] of [[true, 'True'], [false, 'False']]) {
        let cls = 'opt';
        if (scored.done) {
          if (val === q.answer) cls += ' correct';
          else if (val === picked) cls += ' wrong';
        } else if (picked === val) cls += ' sel';
        card.append(el('button', {
          class: cls, disabled: scored.done,
          onclick: () => { answers[i] = val; render(); },
        }, el('span', { class: 'k', text: val ? 'T' : 'F' }), el('span', { text: label })));
      }
      if (scored.done) card.append(el('div', { class: 'explain', text: q.explanation || '' }));
      host.append(card);
    });

    if (!scored.done) {
      host.append(el('button', {
        class: 'btn block', text: 'Check answers',
        onclick: () => {
          if (answers.some((a) => a === null)) return toast('Answer every statement first.', 'warn');
          scored.done = true; render();
        },
      }));
    } else {
      host.prepend(el('div', { class: 'card tight', style: 'margin-bottom:12px' },
        el('div', { class: 'bold', text: `${correct} / ${qs.length} correct` }),
        el('div', { class: 'small muted', text: 'Green = correct answer.' })
      ));
    }
  };
  render();
  return host;
}

function flashcardDeck(p) {
  const host = el('div', {});
  const cards = p.cards || [];
  if (!cards.length) {
    host.append(el('div', { class: 'empty' }, el('p', { text: p.note || 'Not enough definable terms for flashcards.' })));
    return host;
  }
  let i = 0;
  let flipped = false;

  const stage = el('div', {});
  const render = () => {
    stage.innerHTML = '';
    const c = cards[i];
    stage.append(
      el('div', { class: `flash ${flipped ? 'flipped' : ''}`, onclick: () => { flipped = !flipped; render(); } },
        el('div', { class: 'flash-inner' },
          el('div', { class: 'flash-face' },
            el('div', { class: 'lbl', text: 'TERM' }),
            el('div', { class: 'txt', text: c.front })
          ),
          el('div', { class: 'flash-face back' },
            el('div', { class: 'lbl', text: 'DEFINITION' }),
            el('div', { class: 'txt', text: c.back })
          )
        )
      ),
      el('div', { class: 'row between' },
        el('button', { class: 'btn ghost sm', html: `${icon('back')}<span>Prev</span>`, disabled: i === 0, onclick: () => { i = Math.max(0, i - 1); flipped = false; render(); } }),
        el('div', { class: 'small muted', text: `${i + 1} / ${cards.length}` }),
        el('button', { class: 'btn ghost sm', html: `<span>Next</span>${icon('back', 'flip-x')}`, disabled: i === cards.length - 1, onclick: () => { i = Math.min(cards.length - 1, i + 1); flipped = false; render(); } })
      ),
      el('div', { class: 'row', style: 'gap:8px;margin-top:9px' },
        el('button', { class: 'btn soft sm', text: 'Shuffle', onclick: () => { cards.sort(() => Math.random() - 0.5); i = 0; flipped = false; render(); } }),
        el('button', { class: 'btn ghost sm', text: 'Back to first', onclick: () => { i = 0; flipped = false; render(); } })
      ),
      el('div', { class: 'tiny muted', style: 'text-align:center;margin-top:9px', text: 'Tap the card to flip it.' })
    );
  };
  render();
  host.append(stage);
  return host;
}

function outputToText(o) {
  const p = o.payload || {};
  const lines = [TASK_NAMES[o.kind] || o.kind, ''];
  if (p.summary) lines.push(p.summary, '');
  if (p.overview) lines.push(p.overview, '');
  if (p.explanation) lines.push(p.explanation, '');
  if (p.answer) lines.push(p.answer, '');
  for (const b of p.bullets || []) lines.push(`• ${b}`);
  for (const b of p.keyPoints || []) lines.push(`• ${b}`);
  for (const k of p.keyTerms || []) lines.push(`${typeof k === 'string' ? k : k.term} — ${typeof k === 'string' ? '' : k.definition}`);
  for (const t of p.simpleTerms || []) lines.push(`${t.term} — ${t.simple}`);
  (p.questions || []).forEach((q, i) => {
    lines.push('', `${i + 1}. ${q.question || q.statement}`);
    (q.options || []).forEach((o2, oi) => lines.push(`   ${String.fromCharCode(65 + oi)}. ${o2}${oi === q.answerIndex ? '  (correct)' : ''}`));
    if (q.answer === true || q.answer === false) lines.push(`   Answer: ${q.answer ? 'True' : 'False'}`);
  });
  (p.cards || []).forEach((c, i) => lines.push(`${i + 1}. ${c.front} — ${c.back}`));
  return lines.join('\n');
}
