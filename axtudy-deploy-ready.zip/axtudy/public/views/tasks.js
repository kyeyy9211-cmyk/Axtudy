/**
 * AXTUDY — Assignment & deadline tracker.
 */
import {
  api, el, esc, icon, sheet, toast, store, confirmDialog, setBusy,
  fmtWhen, isoToLocalInput, localToIso, closeSheet,
} from '../core.js';
import { assignmentRow } from './home.js';
import { handleLimitError } from './billing.js';

const TABS = [
  { key: 'today', label: 'Today' },
  { key: 'upcoming', label: 'Upcoming' },
  { key: 'overdue', label: 'Overdue' },
  { key: 'completed', label: 'Completed' },
];

const TYPE_OPTIONS = [
  { value: 'assignment', label: 'Assignment' },
  { value: 'exam', label: 'Exam' },
  { value: 'quiz', label: 'Quiz' },
  { value: 'project', label: 'Project' },
  { value: 'activity', label: 'Activity' },
];

const PRIORITY_OPTIONS = [
  { value: 'low', label: 'Low priority' },
  { value: 'medium', label: 'Medium priority' },
  { value: 'high', label: 'High priority' },
];

/* ───────────────────────── add / edit sheet ───────────────────────── */

export function openAssignmentSheet({ assignment = null, classes = [], onSaved, presetDue = '' } = {}) {
  const editing = Boolean(assignment);
  const a = assignment || {};

  const title = el('input', { placeholder: 'e.g. Chapter 4 problem set', value: a.title || '', required: true, maxlength: '160' });
  const classSelect = el('select', {},
    el('option', { value: '' }, '— No class —'),
    classes.map((c) => el('option', { value: c.id, selected: a.classId === c.id }, `${c.subjectCode ? `${c.subjectCode} · ` : ''}${c.subjectName}`))
  );
  const subject = el('input', { placeholder: 'e.g. CS 201', value: a.subject || '', maxlength: '120' });
  const type = el('select', {}, TYPE_OPTIONS.map((t) => el('option', { value: t.value, selected: (a.type || 'assignment') === t.value }, t.label)));
  const priority = el('select', {}, PRIORITY_OPTIONS.map((p) => el('option', { value: p.value, selected: (a.priority || 'medium') === p.value }, p.label)));
  const due = el('input', { type: 'datetime-local', value: a.dueAt ? isoToLocalInput(a.dueAt) : presetDue, required: true });
  const reminder = el('input', { type: 'datetime-local', value: a.reminderAt ? isoToLocalInput(a.reminderAt) : '' });
  const description = el('textarea', { placeholder: 'Instructions, notes, what to submit…', maxlength: '4000' });
  description.value = a.description || '';

  // Auto-fill subject from the class dropdown
  classSelect.addEventListener('change', () => {
    const c = classes.find((x) => x.id === classSelect.value);
    if (c && !subject.value.trim()) subject.value = c.subjectCode || c.subjectName;
  });

  // Default: today 23:59
  if (!due.value) {
    const d = new Date();
    d.setHours(23, 59, 0, 0);
    due.value = isoToLocalInput(d.toISOString());
  }

  const body = el('div', {},
    el('div', { class: 'field' }, el('label', { text: 'Title *' }), title),
    el('div', { class: 'field' }, el('label', { text: 'Class' }), classSelect),
    el('div', { class: 'grid-2' },
      el('div', { class: 'field' }, el('label', { text: 'Subject' }), subject),
      el('div', { class: 'field' }, el('label', { text: 'Type' }), type)
    ),
    el('div', { class: 'field' }, el('label', { text: 'Due date & time *' }), due),
    el('div', { class: 'grid-2' },
      el('div', { class: 'field' }, el('label', { text: 'Priority' }), priority),
      el('div', { class: 'field' }, el('label', { text: 'Reminder' }), reminder)
    ),
    el('div', { class: 'field' }, el('label', { text: 'Description' }), description),
    el('div', { class: 'tiny muted', text: reminder.value ? '' : 'Tip: set a reminder so AXTUDY highlights it on your dashboard.' })
  );

  const save = async (btn) => {
    const payload = {
      title: title.value.trim(),
      classId: classSelect.value || null,
      subject: subject.value.trim(),
      type: type.value,
      priority: priority.value,
      dueAt: localToIso(due.value),
      reminderAt: localToIso(reminder.value),
      description: description.value.trim(),
    };
    if (!payload.title) { toast('Please enter a title.', 'err'); return true; }
    if (!payload.dueAt) { toast('Please choose a due date and time.', 'err'); return true; }
    setBusy(btn, true, editing ? 'Saving…' : 'Adding…');
    try {
      if (editing) await api.patch(`/api/assignments/${a.id}`, payload);
      else await api.post('/api/assignments', payload);
      toast(editing ? 'Task updated.' : 'Task added.', 'ok');
      await onSaved?.();
      return false;
    } catch (err) {
      setBusy(btn, false);
      toast(err.message, 'err');
      return true;
    }
  };

  const actions = [{ label: editing ? 'Save changes' : 'Add task', variant: '', onClick: save }];
  if (editing) {
    actions.unshift({
      label: 'Delete',
      variant: 'danger',
      close: false,
      onClick: async () => {
        const yes = await confirmDialog({
          title: 'Delete task?',
          message: `"${a.title}" will be permanently removed.`,
        });
        if (!yes) return true;
        try {
          await api.del(`/api/assignments/${a.id}`);
          toast('Task deleted.', 'ok');
          closeSheet();
          await onSaved?.();
        } catch (err) { toast(err.message, 'err'); }
        return true;
      },
    });
  }

  sheet({ title: editing ? 'Edit task' : 'New task', body, actions });
}

/* ───────────────────────── tasks screen ───────────────────────── */

export async function renderTasks(root, { navigate, refresh } = {}) {
  let active = sessionStorage.getItem('axtudy.tasks.tab') || 'today';
  let data = null;

  async function load() {
    root.innerHTML = '';
    root.append(el('div', { class: 'loading' }, el('div', { class: 'spinner dark' }), el('div', { text: 'Loading tasks…' })));
    try {
      data = await api.get(`/api/assignments?view=${encodeURIComponent(active)}`);
    } catch (err) {
      root.innerHTML = '';
      root.append(el('div', { class: 'empty' }, el('p', { text: err.message }),
        el('button', { class: 'btn', text: 'Retry', onclick: load })));
      return;
    }
    paint();
  }

  function paint() {
    root.innerHTML = '';
    root.append(el('div', { class: 'page-head row between' },
      el('div', {},
        el('h1', { text: 'Tasks' }),
        el('p', { text: `${data.counts.upcoming ?? 0} upcoming · ${data.counts.overdue ?? 0} overdue` })
      ),
      el('button', {
        class: 'btn', html: `${icon('plus')}<span>New</span>`,
        onclick: () => openAssignmentSheet({ classes: store.classes, onSaved: load }),
      })
    ));

    const chips = el('div', { class: 'chips' });
    for (const t of TABS) {
      chips.append(el('button', {
        class: 'chip', 'aria-selected': String(active === t.key),
        html: `${esc(t.label)}<span class="cnt">${data.counts[t.key] ?? 0}</span>`,
        onclick: () => { active = t.key; sessionStorage.setItem('axtudy.tasks.tab', t.key); load(); },
      }));
    }
    root.append(chips);

    const list = el('div', { class: 'list' });
    if (!data.assignments.length) {
      const messages = {
        today: ['🌤️', 'Nothing is due today. Great time to get ahead!'],
        upcoming: ['📅', 'No upcoming tasks. Add one to stay on track.'],
        overdue: ['✅', 'Nothing overdue — you are all caught up!'],
        completed: ['🏁', 'No completed tasks yet. Tick one off to see it here.'],
      }[active] || ['📋', 'No tasks here.'];
      list.append(el('div', { class: 'empty' },
        el('div', { class: 'em', text: messages[0] }),
        el('p', { text: messages[1] }),
        el('button', {
          class: 'btn soft', text: 'Add a task',
          onclick: () => openAssignmentSheet({ classes: store.classes, onSaved: load }),
        })
      ));
    } else {
      for (const a of data.assignments) {
        const row = assignmentRow(a, {
          onToggle: () => load(),
          onEdit: (item) => openAssignmentSheet({ assignment: item, classes: store.classes, onSaved: load }),
        });
        list.append(row);
      }
    }
    root.append(list);

    if (active === 'overdue' && data.assignments.length) {
      root.append(el('div', { class: 'section-title', text: 'Tip' }));
      root.append(el('div', { class: 'card tight' },
        el('div', { class: 'small muted', text: 'Tap any task to reschedule the due date, raise its priority, or add a reminder.' })));
    }
  }

  await load();
}
