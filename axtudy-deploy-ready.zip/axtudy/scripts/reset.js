#!/usr/bin/env node
/**
 * Delete the local database and every uploaded file.
 *   node scripts/reset.js --yes
 *
 * Keeps the data directory itself; only removes the DB and uploads.
 */
import fs from 'node:fs';
import path from 'node:path';
import { config } from '../src/config.js';

if (!process.argv.includes('--yes')) {
  console.log('This deletes:');
  console.log(`  • ${config.DB_FILE} (and its -wal/-shm files)`);
  console.log(`  • every file in ${config.UPLOAD_DIR}`);
  console.log('\nRe-run with --yes to confirm:  node scripts/reset.js --yes');
  process.exit(0);
}

const removed = [];
for (const suffix of ['', '-wal', '-shm']) {
  const f = config.DB_FILE + suffix;
  try {
    if (fs.existsSync(f)) { fs.rmSync(f); removed.push(path.basename(f)); }
  } catch (err) {
    console.error(`Could not remove ${f}: ${err.message}`);
  }
}
try {
  if (fs.existsSync(config.UPLOAD_DIR)) {
    for (const entry of fs.readdirSync(config.UPLOAD_DIR)) {
      fs.rmSync(path.join(config.UPLOAD_DIR, entry), { force: true });
    }
    removed.push('uploads/*');
  }
} catch (err) {
  console.error(`Could not clear uploads: ${err.message}`);
}

console.log(removed.length ? `Removed: ${removed.join(', ')}` : 'Nothing to remove.');
console.log('Start the server again to create a fresh database.');
