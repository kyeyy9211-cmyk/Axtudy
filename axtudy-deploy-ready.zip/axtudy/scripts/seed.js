#!/usr/bin/env node
/**
 * Reload the demo student's classes, assignments and study material.
 *   node scripts/seed.js
 */
import { seedDemoData, one, run, closeDb } from '../src/db.js';
import { createUser } from '../src/auth.js';
import { DEMO_EMAIL, DEMO_PASSWORD } from '../src/config.js';

let user = one('SELECT * FROM users WHERE email = ?', DEMO_EMAIL);
if (!user) {
  const created = createUser({
    email: DEMO_EMAIL,
    password: DEMO_PASSWORD,
    name: 'Alex Reyes',
    school: 'University of the Philippines',
    course: 'BS Computer Science',
    yearLevel: '2nd Year',
  });
  run('UPDATE users SET is_demo = 1 WHERE id = ?', created.id);
  user = one('SELECT * FROM users WHERE id = ?', created.id);
  console.log(`Created demo student ${DEMO_EMAIL} / ${DEMO_PASSWORD}`);
}

const result = seedDemoData(user.id, { reset: true });
console.log(result.seeded
  ? `Demo data reloaded for ${DEMO_EMAIL}.`
  : 'Nothing to do.');
closeDb();
