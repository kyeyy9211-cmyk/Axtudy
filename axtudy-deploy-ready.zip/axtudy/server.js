/**
 * AXTUDY — server entry point.
 *  • serves the mobile-first SPA from /public
 *  • serves the JSON API from /src/api.js
 *  • seeds a demo account on first boot so the app is testable instantly
 *
 * Run:  node server.js        (zero npm dependencies)
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config, LIMITS, DEMO_EMAIL, DEMO_PASSWORD } from './src/config.js';
import { handleApi } from './src/api.js';
import { seedDemoData, one, run, closeDb } from './src/db.js';
import { createUser } from './src/auth.js';
import { engineInfo } from './src/ai.js';
import { extractionCapabilities } from './src/extract.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, 'public');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
};

/* ───────────────────────── static files ───────────────────────── */

function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname);
  if (rel === '/' || rel === '') rel = '/index.html';

  const target = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!target.startsWith(PUBLIC_DIR)) {
    res.writeHead(403).end('Forbidden');
    return;
  }

  fs.stat(target, (err, stat) => {
    if (err || !stat.isFile()) {
      // SPA fallback — unknown non-API path returns the app shell.
      const shell = path.join(PUBLIC_DIR, 'index.html');
      fs.readFile(shell, (e2, buf) => {
        if (e2) return res.writeHead(404).end('Not found');
        res.writeHead(200, { 'content-type': MIME['.html'], 'cache-control': 'no-cache' }).end(buf);
      });
      return;
    }
    const ext = path.extname(target).toLowerCase();
    const etag = `W/"${stat.size}-${stat.mtimeMs}"`;
    if (req.headers['if-none-match'] === etag) return res.writeHead(304).end();
    res.writeHead(200, {
      'content-type': MIME[ext] || 'application/octet-stream',
      'content-length': stat.size,
      etag,
      'cache-control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
    });
    fs.createReadStream(target).pipe(res);
  });
}

/* ───────────────────────── server ───────────────────────── */

const server = http.createServer(async (req, res) => {
  const started = Date.now();
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  // Basic hardening
  res.setHeader('x-content-type-options', 'nosniff');
  res.setHeader('referrer-policy', 'same-origin');
  res.setHeader('x-frame-options', 'SAMEORIGIN');

  // Optional CORS (only when explicitly configured)
  if (config.CORS_ORIGINS.length) {
    const origin = req.headers.origin;
    if (origin && config.CORS_ORIGINS.includes(origin)) {
      res.setHeader('access-control-allow-origin', origin);
      res.setHeader('access-control-allow-credentials', 'true');
      res.setHeader('access-control-allow-headers', 'content-type, authorization');
      res.setHeader('access-control-allow-methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
    }
    if (req.method === 'OPTIONS') return res.writeHead(204).end();
  }

  try {
    if (url.pathname.startsWith('/api/')) {
      await handleApi(req, res, url);
    } else {
      serveStatic(req, res, url);
    }
  } catch (err) {
    console.error('[AXTUDY] Unhandled error:', err);
    if (!res.headersSent) {
      res.writeHead(500, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'Internal server error.' }));
    }
  }

  if (process.env.AXTUDY_LOG !== 'off') {
    const ms = Date.now() - started;
    console.log(`${req.method.padEnd(6)} ${url.pathname}${url.search} → ${res.statusCode} (${ms}ms)`);
  }
});

/* ───────────────────────── demo account bootstrap ───────────────────────── */

function bootstrapDemoAccount() {
  let user = one('SELECT * FROM users WHERE email = ?', DEMO_EMAIL);
  if (!user) {
    try {
      const created = createUser({
        email: DEMO_EMAIL,
        password: DEMO_PASSWORD,
        name: 'Alex Reyes',
        school: 'University of the Philippines',
        course: 'BS Computer Science',
        yearLevel: '2nd Year',
      });
      run('UPDATE users SET is_demo = 1 WHERE id = ?', created.id);
      user = one('SELECT * FROM users WHERE id = ?', created.id);
      console.log(`  ✓ Demo student created: ${DEMO_EMAIL} / ${DEMO_PASSWORD}`);
    } catch (err) {
      console.error('  ✗ Could not create the demo student:', err.message);
      return null;
    }
  }
  const result = seedDemoData(user.id);
  if (result.seeded) console.log('  ✓ Demo classes, assignments and notes loaded');
  return user;
}

process.on('SIGINT', () => {
  console.log('\nShutting down AXTUDY…');
  closeDb();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1200);
});

server.listen(config.PORT, config.HOST, () => {
  const ai = engineInfo();
  const ex = extractionCapabilities();
  console.log('');
  console.log('  █████╗ ██╗  ██╗████████╗██╗   ██╗██████╗ ██╗   ██╗');
  console.log('  ██╔══██╗╚██╗██╔╝╚══██╔══╝██║   ██║██╔══██╗╚██╗ ██╔╝');
  console.log('  ███████║ ╚███╔╝    ██║   ██║   ██║██║  ██║ ╚████╔╝ ');
  console.log('  ██╔══██║ ██╔██╗    ██║   ██║   ██║██║  ██║  ╚██╔╝  ');
  console.log('  ██║  ██║██╔╝ ██╗   ██║   ╚██████╔╝██████╔╝   ██║   ');
  console.log('  ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═════╝    ╚═╝   ');
  console.log('');
  console.log(`  AXTUDY is running → http://localhost:${config.PORT}`);
  console.log(`  Data directory    → ${config.DATA_DIR}`);
  console.log(`  AI engine         → ${ai.label}`);
  console.log(`  PDF text          → ${ex.pdf === 'none' ? 'unavailable (install poppler-utils)' : ex.pdf}`);
  console.log(`  Office files      → ${ex.office === 'none' ? 'unavailable (install unzip)' : ex.office}`);
  console.log(`  Image OCR         → ${ex.images === 'none' ? 'add GEMINI_API_KEY to enable' : ex.images}`);
  console.log(`  Payments          → ${config.billing.paymongoSecret ? 'PayMongo (live keys)' : 'simulated checkout (add PayMongo keys for real payments)'}`);
  console.log('');
  console.log(`  Demo login        → ${DEMO_EMAIL} / ${DEMO_PASSWORD}`);
  console.log(`  Free plan limits  → ${LIMITS.free.uploadsPerMonth} uploads, ${LIMITS.free.aiGenerationsPerMonth} AI results / month`);
  console.log(`  Pro plan          → ₱${config.billing.pricePhp}/month, ${config.billing.trialDays}-day free trial`);
  console.log('');
  bootstrapDemoAccount();
});

export { server };
