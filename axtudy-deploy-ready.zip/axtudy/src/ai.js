/**
 * AXTUDY — AI study engine.
 *
 * Two modes, same interface:
 *  1. Provider mode  — OpenAI-compatible API or Google Gemini (keys via .env)
 *  2. Offline mode   — a real local study engine built on the student's own
 *                      text (extractive summarisation, term extraction,
 *                      cloze-style quizzes, flashcards, T/F generation).
 *
 * Provider mode never receives an API key from the browser: all calls are
 * made server-side in this module.
 */
import { config } from './config.js';

/* ───────────────────────── engine selection ───────────────────────── */

export function activeEngine() {
  const p = config.ai.provider;
  if (p === 'none') return 'offline';
  if (p === 'openai' && config.ai.openaiKey) return 'openai';
  if (p === 'gemini' && config.ai.geminiKey) return 'gemini';
  if (p === 'auto' || p === 'openai' || p === 'gemini') {
    if (config.ai.openaiKey) return 'openai';
    if (config.ai.geminiKey) return 'gemini';
  }
  return 'offline';
}

export function engineInfo() {
  const engine = activeEngine();
  const names = {
    openai: `OpenAI · ${config.ai.openaiModel}`,
    gemini: `Google Gemini · ${config.ai.geminiModel}`,
    offline: 'AXTUDY Local Study Engine (offline)',
  };
  return {
    engine,
    label: names[engine],
    online: engine !== 'offline',
    vision: Boolean(config.ai.geminiKey),
  };
}

/* ───────────────────────── provider transport ───────────────────────── */

async function callOpenAI(system, user, { temperature = 0.3, json = true } = {}) {
  const res = await fetch(`${config.ai.openaiBase}/chat/completions`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${config.ai.openaiKey}`,
    },
    body: JSON.stringify({
      model: config.ai.openaiModel,
      temperature,
      ...(json ? { response_format: { type: 'json_object' } } : {}),
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
    }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error?.message || `OpenAI request failed (${res.status})`);
  return data?.choices?.[0]?.message?.content || '';
}

async function callGemini(system, user, { temperature = 0.3, json = true } = {}) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${config.ai.geminiModel}:generateContent?key=${config.ai.geminiKey}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: 'user', parts: [{ text: user }] }],
      generationConfig: {
        temperature,
        ...(json ? { responseMimeType: 'application/json' } : {}),
      },
    }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error?.message || `Gemini request failed (${res.status})`);
  return (data?.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('\n');
}

export async function callModel(system, user, opts = {}) {
  const engine = activeEngine();
  if (engine === 'openai') return callOpenAI(system, user, opts);
  if (engine === 'gemini') return callGemini(system, user, opts);
  throw new Error('offline');
}

function parseJsonLoose(raw) {
  if (!raw) throw new Error('Empty model response');
  let s = String(raw).trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  try { return JSON.parse(s); } catch { /* keep going */ }
  const start = s.search(/[[{]/);
  if (start === -1) throw new Error('No JSON found in model response');
  const openChar = s[start];
  const closeChar = openChar === '{' ? '}' : ']';
  let depth = 0;
  for (let i = start; i < s.length; i++) {
    if (s[i] === openChar) depth++;
    else if (s[i] === closeChar) {
      depth--;
      if (depth === 0) return JSON.parse(s.slice(start, i + 1));
    }
  }
  throw new Error('Unterminated JSON in model response');
}

/* ───────────────────────── text analysis helpers ───────────────────────── */

const STOPWORDS = new Set(`a about above after again against all am an and any are aren't as at be because been before being below between both but by can cannot could couldn't did didn't do does doesn't doing don't down during each few for from further had hadn't has hasn't have haven't having he her here hers herself him himself his how i if in into is isn't it its itself let's me more most mustn't my myself no nor not of off on once only or other ought our ours ourselves out over own same shan't she should shouldn't so some such than that the their theirs them themselves then there these they this those through to too under until up very was wasn't we were weren't what when where which while who whom why with won't would wouldn't you your yours yourself yourselves also may many using used use one two three first second however thus therefore within without e.g i.e etc`
  .split(/\s+/));

const SENTENCE_WORDS = /\b(?:is|are|was|were|be|been|being|has|have|had|does|do|did|can|could|will|would|should|may|might|must|the|of|in|to|with|which|that|and|or|when|where|because|as|for|by|from|than|into|over|under|so|if|it|its|this|these|those|their|there|they|a|an)\b/i;

/** Drop a leading title/heading line so it never becomes a quiz item. */
export function stripTitle(text) {
  const lines = String(text || '').split('\n');
  for (let i = 0; i < Math.min(3, lines.length); i++) {
    const t = lines[i].trim();
    if (!t) continue;
    const words = t.split(/\s+/).length;
    const looksLikeHeading = words <= 12 && !/[.!?]$/.test(t) && !SENTENCE_WORDS.test(t);
    if (looksLikeHeading) { lines.splice(i, 1); return lines.join('\n'); }
    break;
  }
  return lines.join('\n');
}

export function splitSentences(text) {
  return String(stripTitle(text) || '')
    .split(/\n{2,}|(?<=[.!?])\s+(?=[A-Z0-9"“(])/)
    .map((s) => s.replace(/\s+/g, ' ').trim())
    .filter((s) => {
      if (s.length < 40) return false;
      if (!/[a-zA-Z]{3,}/.test(s)) return false;
      // A real sentence has at least 7 words and a function word in it.
      return s.split(/\s+/).length >= 7 && SENTENCE_WORDS.test(s);
    })
    .map((s) => (s.endsWith('.') || /[.!?]$/.test(s) ? s : `${s}.`));
}

/** Generic words that are not useful study terms on their own. */
/** Words that can never be part of a noun phrase used as a study term. */
const VERB_TOKENS = new Set(`is are was were has have had stores store maps map contains contain holds hold use uses used returns return takes take gives give provides provide allows allow represents represent includes include means mean refers refer occurs occur called call using does do did can will may must should would could also only both then than when where which that this these those its their there they from into about over under with without within between through before after during while because however although separate separates occurs appear appears produce produces result results depends depend require requires become becomes make makes give hold move moves grow grows show shows cause causes define defines defined describes describe explains explain affects affect increase increases decrease decreases convert converts absorb absorbs reflect reflects consume consumes release releases fix fixes break breaks align aligns reform reforms waste wastes reduce reduces control controls regulate regulates consist consists`
  .split(/\s+/));

const GENERIC_TERMS = new Set(`list lists node nodes data next head item items element elements index operation operations example examples value values memory array arrays string strings type types case cases point points form forms way ways thing things part parts time times number numbers method methods function functions process processes result results problem problems code line lines set sets order level levels state states size sizes total specific different following given used using make makes made called call calls store stores stored also often usually generally simply really much many more most less least first second third last new old same other others such only even well just like because however although while during within without between through before after above below both each few some most any all`
  .split(/\s+/));

const escapeRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export function tokenize(text) {
  return String(text || '').toLowerCase().match(/[a-z][a-z'-]{2,}/g) || [];
}

export function termFrequency(text) {
  const freq = new Map();
  for (const w of tokenize(text)) {
    if (STOPWORDS.has(w)) continue;
    freq.set(w, (freq.get(w) || 0) + 1);
  }
  return freq;
}

/** Score sentences by summed normalised term frequency (extractive ranking). */
export function rankSentences(text, { boost = [] } = {}) {
  const sentences = splitSentences(text);
  const freq = termFrequency(text);
  const max = Math.max(1, ...freq.values());
  const maxLen = Math.max(60, ...sentences.map((s) => s.length));
  const boostSet = new Set(boost.map((b) => String(b).toLowerCase()));
  return sentences
    .map((s, index) => {
      const words = tokenize(s).filter((w) => !STOPWORDS.has(w));
      const score = words.reduce((acc, w) => acc + (freq.get(w) || 0) / max, 0) / Math.sqrt(words.length || 1);
      const positionBonus = 1 + Math.max(0, 0.4 - (index / Math.max(1, sentences.length)) * 0.4);
      const boostBonus = words.some((w) => boostSet.has(w)) ? 1.35 : 1;
      const lengthPenalty = s.length > maxLen * 1.8 ? 0.7 : 1;
      return { sentence: s, index, score: score * positionBonus * boostBonus * lengthPenalty };
    })
    .sort((a, b) => b.score - a.score);
}

/**
 * Extract study-worthy terms.
 *
 * Priority order (strongest signal first):
 *   1. words a sentence explicitly defines   ("A linked list is ...")
 *   2. words the text names                  ("called a node")
 *   3. repeated multi-word phrases           ("linked list", "hash table")
 *   4. capitalised multi-word proper phrases
 *   5. capitalised words used mid-sentence
 *   6. frequent long domain words
 * Sub-terms of an already-selected phrase are dropped, so "list" never
 * competes with "linked list".
 */
export function keyTerms(text, limit = 18) {
  const body = stripTitle(text);
  const sentences = splitSentences(body);
  const freq = termFrequency(body);
  const scored = new Map();
  let m;

  const consider = (rawTerm, score) => {
    const term = String(rawTerm)
      .trim()
      .replace(/^(?:the|a|an)\s+/i, '')
      .replace(/[^a-zA-Z0-9\s-]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    if (!term) return;
    const key = term.toLowerCase();
    const words = key.split(' ');
    if (words.length === 1) {
      if (GENERIC_TERMS.has(key) || STOPWORDS.has(key) || VERB_TOKENS.has(key) || key.length < 5) return;
    } else {
      // A multi-word term must actually appear verbatim in the material
      // (this also rejects n-grams broken by dropped short stopwords).
      if (!body.toLowerCase().includes(key)) return;
      if (words.some((w) => STOPWORDS.has(w) && w !== 'of')) return;
    }
    const prev = scored.get(key);
    if (!prev || score > prev.score) scored.set(key, { term, score });
  };

  // 1. Definition patterns — "A hash table maps ...", "A stack is ..."
  const VERBS = 'is|are|was|were|refers to|means|denotes|consists of|represents|stores|maps|contains|holds|uses|returns|takes|gives|provides|allows|has';
  const defRe = new RegExp(`(?:^|[.;:]\\s+|\\n)(?:a|an|the)?\\s*([a-z][a-z0-9-]*(?:\\s+[a-z0-9-]+){0,3})\\s+(?:${VERBS})\\b`, 'gi');
  while ((m = defRe.exec(body))) consider(m[1], 10);

  // 2. Named entities — "called a node", "known as the head node"
  const callRe = /\b(?:called|known as|termed)\s+(?:a|an|the)?\s*([a-z][a-z0-9-]*(?:\s+[a-z0-9-]+){0,2})/gi;
  while ((m = callRe.exec(body))) consider(m[1], 8);

  // 3. Repeated multi-word phrases
  const tokens = tokenize(body);
  const grams = new Map();
  for (let n = 2; n <= 3; n++) {
    for (let i = 0; i + n <= tokens.length; i++) {
      const g = tokens.slice(i, i + n);
      if (STOPWORDS.has(g[0]) || STOPWORDS.has(g[g.length - 1])) continue;
      if (g.some((w) => VERB_TOKENS.has(w))) continue; // never a noun phrase
      const key = g.join(' ');
      grams.set(key, (grams.get(key) || 0) + 1);
    }
  }
  for (const [g, c] of grams) {
    if (c < 2) continue;
    consider(g, 4 + c);
  }

  // 4. Capitalised multi-word proper phrases
  const phraseRe = /\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,}){1,3})\b/g;
  while ((m = phraseRe.exec(body))) consider(m[1], 6);

  // 5. Capitalised words used mid-sentence (not just sentence openers)
  for (const s of sentences) {
    const re = /\b([A-Z][a-z]{2,})\b/g;
    while ((m = re.exec(s))) {
      if (m.index > 0) consider(m[1], 5);
    }
  }

  // 6. Frequent, long domain words (shorter texts need fewer repeats)
  const minCount = tokens.length > 400 ? 3 : 2;
  for (const [w, c] of freq) {
    if (c < minCount || w.length < 6) continue;
    consider(w, 1.5 + c * 0.6);
  }

  const ranked = [...scored.values()].sort((a, b) => b.score - a.score || b.term.length - a.term.length);
  const out = [];
  for (const { term } of ranked) {
    const key = term.toLowerCase();
    if (out.some((t) => t.toLowerCase().includes(key) || key.includes(t.toLowerCase()))) continue;
    out.push(term);
    if (out.length >= limit) break;
  }
  return out;
}

/**
 * Pick the sentence that best defines a term.
 * Prefers definitions that open with the term ("A linked list is …") over
 * incidental mentions.
 */
export function definitionFor(term, sentences) {
  const t = term.toLowerCase();
  const word = escapeRe(t);
  const isDef = `\\s+(?:is|are|was|were|refers to|means|describes|denotes|consists of|stores|represents)\\b`;
  const patterns = [
    { re: new RegExp(`^(?:a|an|the)?\\s*${word}${isDef}`, 'i'), score: 6 },
    { re: new RegExp(`\\b${word}${isDef}`, 'i'), score: 4 },
    { re: new RegExp(`^(?:a|an|the)?\\s*${word}\\b`, 'i'), score: 2 },
    { re: new RegExp(`\\b${word}\\b`, 'i'), score: 1 },
  ];
  let best = null;
  let bestScore = 0;
  for (const s of sentences) {
    for (const { re, score } of patterns) {
      if (re.test(s) && score > bestScore) {
        best = s;
        bestScore = score;
        break;
      }
    }
  }
  return best || '';
}

const titleCase = (s) => String(s).replace(/\b[a-z]/g, (c) => c.toUpperCase());

/** Chunk long text into ~1200-char passages for retrieval. */
export function chunkText(text, size = 1200) {
  const paras = String(text || '').split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);
  const chunks = [];
  let buf = '';
  for (const p of paras) {
    if ((buf + '\n\n' + p).length > size && buf) {
      chunks.push(buf);
      buf = p;
    } else {
      buf = buf ? `${buf}\n\n${p}` : p;
    }
  }
  if (buf) chunks.push(buf);
  return chunks.length ? chunks : [String(text || '').slice(0, size)];
}

/** Keyword-overlap retrieval (used by "ask about my material"). */
export function retrieve(question, text, topK = 4) {
  const qWords = new Set(tokenize(question).filter((w) => !STOPWORDS.has(w)));
  const chunks = chunkText(text);
  const scored = chunks.map((c, i) => {
    const words = tokenize(c).filter((w) => !STOPWORDS.has(w));
    const overlap = words.filter((w) => qWords.has(w)).length;
    const density = overlap / Math.sqrt(words.length || 1);
    return { chunk: c, index: i, score: overlap * 1.5 + density * 3 };
  });
  const sorted = scored.sort((a, b) => b.score - a.score);
  const best = sorted.filter((s) => s.score > 0).slice(0, topK);
  return best.length ? best : sorted.slice(0, 2);
}

function pickSentences(text, n) {
  return rankSentences(text).slice(0, n).map((r) => r.sentence);
}

/** Deterministic-ish shuffle */
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ───────────────────────── offline engines ───────────────────────── */

function offlineSummarize(text, title) {
  const tops = rankSentences(text);
  const bullets = tops.slice(0, 6).map((r) => r.sentence);
  const terms = keyTerms(text, 10);
  const summary = pickSentences(text, 4).join(' ');
  return {
    summary: summary || `This material ("${title}") does not contain enough readable text to summarise.`,
    bullets: bullets.length ? bullets : [summary],
    keyTerms: terms,
    stats: { sentences: splitSentences(text).length, words: tokenize(text).length },
  };
}

function offlineReviewer(text, title) {
  const sents = splitSentences(text);
  const terms = keyTerms(text, 14);
  const keyTermCards = terms.slice(0, 12).map((t) => ({
    term: titleCase(t),
    definition: definitionFor(t, sents) || `Key concept appearing in "${title}".`,
  }));
  const points = pickSentences(text, 10);
  const overview = pickSentences(text, 3).join(' ');
  return {
    overview: overview || `Reviewer generated from "${title}".`,
    keyTerms: keyTermCards,
    keyPoints: points,
    tips: [
      'Read the key terms aloud, then cover the definitions and recall each one.',
      'Convert every key point into a "why does this matter?" question.',
      'Take the generated quiz twice — spaced repetition beats re-reading.',
      'Group similar terms into a table so contrasts become obvious.',
    ],
  };
}

function offlineQuiz(text, count, title) {
  const sents = splitSentences(text);
  const terms = keyTerms(text, Math.max(count * 3, 24));
  const questions = [];
  const usedTerms = new Set();
  const usedSentences = new Set();
  for (const term of terms) {
    if (questions.length >= count) break;
    const key = term.toLowerCase();
    if (usedTerms.has(key)) continue;
    const sentence = sents.find((s) =>
      !usedSentences.has(s) && s.length > 50 && new RegExp(`\\b${escapeRe(key)}\\b`, 'i').test(s));
    if (!sentence) continue;
    usedSentences.add(sentence);
    const re = new RegExp(`\\b${escapeRe(term)}\\b`, 'i');
    const blanked = sentence.replace(re, '________');
    if (blanked === sentence) continue;
    const distractors = shuffle(terms.filter((t) => t.toLowerCase() !== key && t.length > 3)).slice(0, 3)
      .map((t) => (term[0] === term[0].toUpperCase() ? titleCase(t) : t.toLowerCase()));
    if (distractors.length < 3) continue;
    const options = shuffle([term, ...distractors]);
    usedTerms.add(key);
    questions.push({
      question: `Which term correctly completes this statement?\n\n"${blanked}"`,
      options,
      answerIndex: options.findIndex((o) => o.toLowerCase() === key),
      explanation: sentence,
    });
  }
  return {
    title: `Multiple Choice — ${title}`,
    questions,
    note: questions.length ? '' : 'Not enough distinct terms in this material to build a quiz. Add a longer document or paste more notes.',
  };
}

function offlineTrueFalse(text, count) {
  const sents = splitSentences(text);
  const terms = keyTerms(text, 30);
  const items = [];
  for (let i = 0; i < sents.length && items.length < count; i++) {
    const sentence = sents[i];
    if (sentence.length < 55) continue;
    const term = terms.find((t) => new RegExp(`\\b${escapeRe(t)}\\b`, 'i').test(sentence));
    if (!term) continue;
    if (items.length % 2 === 0) {
      items.push({ statement: sentence, answer: true, explanation: 'Stated directly in the material.' });
    } else {
      const wrong = terms.find((t) => {
        if (t.toLowerCase() === term.toLowerCase()) return false;
        const altered = sentence.replace(new RegExp(`\\b${escapeRe(term)}\\b`, 'i'), t);
        // reject awkward substitutions such as "Linked Lists list"
        return altered !== sentence && !new RegExp(`\\b${escapeRe(t)}\\\\s+${escapeRe(t.toLowerCase())}\\b`).test(altered);
      });
      if (!wrong) continue;
      const altered = sentence.replace(new RegExp(`\\b${escapeRe(term)}\\b`, 'i'), wrong);
      if (altered === sentence) continue;
      items.push({
        statement: altered,
        answer: false,
        explanation: `Incorrect — the material says "${sentence}"`,
      });
    }
  }
  return {
    title: 'True or False',
    questions: items.map((it, idx) => ({ id: idx + 1, ...it })),
    note: items.length ? '' : 'Not enough text to generate true/false items.',
  };
}

function offlineFlashcards(text, count) {
  const sents = splitSentences(text);
  const terms = keyTerms(text, Math.max(count, 20));
  const cards = [];
  const used = new Set();
  for (const term of terms) {
    if (cards.length >= count) break;
    const key = term.toLowerCase();
    if (used.has(key)) continue;
    const def = definitionFor(term, sents);
    if (!def || def.toLowerCase() === key) continue;
    used.add(key);
    cards.push({ front: titleCase(term), back: def, hint: def.split(/\s+/).slice(0, 6).join(' ') + '…' });
  }
  return { title: 'Flashcards', cards, note: cards.length ? '' : 'Not enough definable terms found.' };
}

function offlineExplain(text, topic) {
  const sents = splitSentences(text);
  const relevant = topic
    ? retrieve(topic, text, 3).flatMap((r) => splitSentences(r.chunk)).slice(0, 6)
    : pickSentences(text, 5);
  const terms = keyTerms(relevant.join(' ') || text, 6);
  const plain = relevant.map((s) =>
    s.replace(/\b(?:utilise|utilize)\b/gi, 'use')
      .replace(/\b(?:in order to)\b/gi, 'to')
      .replace(/\b(?:subsequently)\b/gi, 'then')
      .replace(/\b(?:approximately)\b/gi, 'about')
  );
  return {
    topic: topic || 'the whole material',
    explanation: [
      `In simple terms, ${topic ? `"${topic}" is` : 'this material is'} best understood by breaking it into small pieces.`,
      ...plain.slice(0, 3),
    ].join(' '),
    keyPoints: plain.length ? plain : ['Add more text to the material for a deeper explanation.'],
    simpleTerms: terms.map((t) => {
      const def = definitionFor(t, sents);
      return { term: titleCase(t), simple: def ? def.replace(/\bwhich is\b/gi, 'that is') : 'A recurring concept in this material.' };
    }),
  };
}

function offlineAnswer(question, text) {
  const hits = retrieve(question, text, 4);
  const excerpts = hits.flatMap((h) => splitSentences(h.chunk)).slice(0, 5);
  const sentences = splitSentences(text);
  const qTerms = [...new Set(tokenize(question).filter((w) => !STOPWORDS.has(w)))].slice(0, 6);
  const relevant = excerpts.filter((s) => qTerms.some((t) => s.toLowerCase().includes(t)));
  const chosen = relevant.length ? relevant : excerpts;
  const answer = chosen.length
    ? `Based on your material${qTerms.length ? ` (keywords: ${qTerms.join(', ')})` : ''}:\n\n${chosen.map((s) => `• ${s}`).join('\n')}\n\nThe strongest passage is: "${chosen[0]}" Check the highlighted sections in your document to confirm the wording in context.`
    : 'I could not find anything about that in this material. Try rephrasing, or upload the chapter that covers this topic.';
  return {
    answer,
    sources: hits.map((h) => ({
      title: `Passage ${h.index + 1}`,
      snippet: h.chunk.slice(0, 320) + (h.chunk.length > 320 ? '…' : ''),
    })),
    confidence: relevant.length >= 2 ? 'high' : relevant.length === 1 ? 'medium' : 'low',
    sentences: sentences.length,
  };
}

/* ───────────────────────── public task API ───────────────────────── */

const SYSTEM = `You are AXTUDY, a study assistant for college students in the Philippines.
You only use the material the student gives you. Be accurate, concise, and never invent facts that are not in the source text.
Always reply with valid JSON matching the requested shape, and no extra prose.`;

const SHAPES = {
  summarize: `{"summary":"2-4 sentence summary","bullets":["key point", "..."],"keyTerms":["term - short meaning"]}`,
  reviewer: `{"overview":"paragraph","keyTerms":[{"term":"","definition":""}],"keyPoints":["..."],"tips":["..."]}`,
  quiz: `{"title":"","questions":[{"question":"","options":["A","B","C","D"],"answerIndex":0,"explanation":""}]}`,
  truefalse: `{"title":"","questions":[{"id":1,"statement":"","answer":true,"explanation":""}]}`,
  flashcards: `{"title":"","cards":[{"front":"","back":"","hint":""}]}`,
  explain: `{"topic":"","explanation":"","keyPoints":["..."],"simpleTerms":[{"term":"","simple":""}]}`,
  ask: `{"answer":"","sources":[{"title":"","snippet":""}],"confidence":"high|medium|low"}`,
};

function buildUserPrompt(task, { text, title, topic, question, count, difficulty }) {
  const clip = String(text || '').slice(0, 24000);
  const base = `MATERIAL TITLE: ${title || 'Untitled'}\n\nMATERIAL TEXT:\n"""\n${clip}\n"""\n\n`;
  switch (task) {
    case 'summarize':
      return `${base}Task: Summarise this material for a college student. Return JSON: ${SHAPES.summarize}`;
    case 'reviewer':
      return `${base}Task: Build a compact revision reviewer (overview, key terms with definitions, key points, study tips). Return JSON: ${SHAPES.reviewer}`;
    case 'quiz':
      return `${base}Task: Create exactly ${count} multiple-choice questions (4 options each, exactly one correct) with explanations. Return JSON: ${SHAPES.quiz}`;
    case 'truefalse':
      return `${base}Task: Create exactly ${count} true/false statements, mixing genuinely true and plausibly false ones, each with an explanation. Return JSON: ${SHAPES.truefalse}`;
    case 'flashcards':
      return `${base}Task: Create exactly ${count} flashcards (front = term or question, back = answer, hint = short nudge). Return JSON: ${SHAPES.flashcards}`;
    case 'explain':
      return `${base}Task: Explain "${topic || title}" in simple language a first-year student can follow. Avoid jargon; define any term you must use. Return JSON: ${SHAPES.explain}`;
    case 'ask':
      return `${base}STUDENT QUESTION: ${question}\n\nTask: Answer strictly from the material above. Quote the supporting sentences in "sources". If the material does not cover it, say so plainly and set confidence to "low". Return JSON: ${SHAPES.ask}`;
    default:
      return base;
  }
}

async function runOnline(task, args) {
  const system = task === 'ask'
    ? `${SYSTEM}\nBe honest when the answer is not in the material.`
    : SYSTEM;
  const raw = await callModel(system, buildUserPrompt(task, args), { temperature: task === 'quiz' ? 0.4 : 0.3 });
  const parsed = parseJsonLoose(raw);
  return parsed;
}

/**
 * Run a study task. Falls back to the offline engine on any provider error
 * so the student always gets a usable result.
 */
export async function runStudyTask(task, args) {
  const engine = activeEngine();
  const text = String(args.text || '');
  const count = Math.max(1, Math.min(60, Number(args.count) || defaultCount(task)));
  const title = args.title || 'Study material';
  const safeArgs = { ...args, text, count, title };

  if (engine !== 'offline' && text.trim().length > 30) {
    try {
      const result = await runOnline(task, safeArgs);
      return { engine, result, fallback: false };
    } catch (err) {
      const offline = runOffline(task, safeArgs);
      return {
        engine: 'offline',
        result: offline,
        fallback: true,
        fallbackReason: `${engine} call failed (${err.message}) — used the local engine instead.`,
      };
    }
  }
  return { engine: 'offline', result: runOffline(task, safeArgs), fallback: false };
}

function defaultCount(task) {
  if (task === 'quiz' || task === 'truefalse') return 8;
  if (task === 'flashcards') return 12;
  return 0;
}

export function runOffline(task, args) {
  const { text, title, topic, question, count } = args;
  switch (task) {
    case 'summarize': return offlineSummarize(text, title);
    case 'reviewer': return offlineReviewer(text, title);
    case 'quiz': return offlineQuiz(text, count, title);
    case 'truefalse': return offlineTrueFalse(text, count);
    case 'flashcards': return offlineFlashcards(text, count);
    case 'explain': return offlineExplain(text, topic);
    case 'ask': return offlineAnswer(question, text);
    default: throw new Error(`Unknown task: ${task}`);
  }
}

export const TASKS = ['summarize', 'reviewer', 'quiz', 'truefalse', 'flashcards', 'explain', 'ask'];
