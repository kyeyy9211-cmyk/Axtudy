/**
 * AXTUDY — HTTP API.
 * Every data route is scoped to the signed-in user (`WHERE user_id = ?`),
 * which is what keeps each student's records private and separate.
 */
import fs from 'node:fs';
import path from 'node:path';
import { config, LIMITS, DEMO_EMAIL } from './config.js';
import {
  one, all, run, newId, getUsage, bumpUsage, seedDemoData,
} from './db.js';
import {
  createUser, authenticate, publicUser, createSession, setSessionCookie,
  clearSessionCookie, destroySession, tokenFromRequest, requireUser, currentUser,
  createPasswordReset, consumePasswordReset, markResetUsed, updatePassword,
  verifyPassword,
} from './auth.js';
import {
  ok, created, bad, notFound, forbidden, HttpError, json,
  str, validEmail, isValidDate, nowIso, readJson, parseMultipart, readBuffer, uid,
} from './util.js';
import { extractText, kindFor, describeImageWithGemini, extractionCapabilities } from './extract.js';
import { runStudyTask, engineInfo, TASKS } from './ai.js';
import {
  subscriptionState, usageSummary, enforceQuota, capCount, startTrial,
  activatePaidPeriod, cancelSubscription, resumeSubscription, resetSubscription,
  createCheckout, verifyPaymongoSignature, findUserByProviderRef,
} from './billing.js';

const routes = [];
const route = (method, pattern, handler, opts = {}) =>
  routes.push({ method, pattern, handler, auth: opts.auth !== false, public: opts.public === true });

/* ───────────────────────────── helpers ───────────────────────────── */

const clampInt = (v, def, min, max) => {
  const n = Number.parseInt(v, 10);
  if (Number.isNaN(n)) return def;
  return Math.max(min, Math.min(max, n));
};

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}
const localDayBounds = (offset = 0) => {
  const s = startOfToday();
  s.setDate(s.getDate() + offset);
  const e = new Date(s);
  e.setDate(e.getDate() + 1);
  return { start: s.toISOString(), end: e.toISOString(), index: s.getDay(), name: DAY_NAMES[s.getDay()] };
};

function publicClass(r) {
  return {
    id: r.id,
    subjectName: r.subject_name,
    subjectCode: r.subject_code,
    instructor: r.instructor,
    room: r.room,
    dayOfWeek: r.day_of_week,
    dayName: DAY_NAMES[r.day_of_week] || '',
    startTime: r.start_time,
    endTime: r.end_time,
    color: r.color,
    createdAt: r.created_at,
  };
}

function publicAssignment(r) {
  const now = Date.now();
  const due = new Date(r.due_at).getTime();
  const isDone = r.status === 'completed';
  return {
    id: r.id,
    classId: r.class_id,
    title: r.title,
    subject: r.subject,
    description: r.description,
    type: r.type,
    dueAt: r.due_at,
    priority: r.priority,
    status: r.status,
    reminderAt: r.reminder_at,
    completedAt: r.completed_at,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    isOverdue: !isDone && due < now,
    isDueToday: !isDone && due >= Date.parse(localDayBounds(0).start) && due < Date.parse(localDayBounds(0).end),
    daysUntilDue: Math.ceil((due - now) / 86400000),
  };
}

function publicMaterial(r) {
  return {
    id: r.id,
    classId: r.class_id,
    title: r.title,
    filename: r.filename,
    mime: r.mime,
    sizeBytes: r.size_bytes,
    kind: r.kind,
    textSource: r.text_source,
    charCount: r.char_count,
    hasText: r.char_count > 0,
    createdAt: r.created_at,
    excerpt: r.text_content ? r.text_content.slice(0, 220) : '',
  };
}

function publicOutput(r) {
  let payload = {};
  try { payload = JSON.parse(r.payload); } catch { /* ignore */ }
  return {
    id: r.id,
    materialId: r.material_id,
    kind: r.kind,
    title: r.title,
    engine: r.engine,
    createdAt: r.created_at,
    payload,
  };
}

const ownMaterial = (userId, id) => {
  const m = one('SELECT * FROM materials WHERE id = ? AND user_id = ?', id, userId);
  if (!m) throw notFound('Study material not found.');
  return m;
};

/* ───────────────────────────── auth ───────────────────────────── */

route('POST', '/api/auth/signup', async (ctx) => {
  const b = await readJson(ctx.req);
  const user = createUser({
    email: b.email,
    password: b.password,
    name: b.name,
    school: b.school,
    course: b.course,
    yearLevel: b.yearLevel,
  });
  const token = createSession(user.id);
  setSessionCookie(ctx.res, token);
  return created(ctx.res, { user, token, subscription: subscriptionState(user.id) });
}, { auth: false });

route('POST', '/api/auth/login', async (ctx) => {
  const b = await readJson(ctx.req);
  const row = authenticate(b.email, b.password);
  const token = createSession(row.id);
  setSessionCookie(ctx.res, token);
  return ok(ctx.res, {
    user: publicUser(row),
    token,
    subscription: subscriptionState(row.id),
  });
}, { auth: false });

route('POST', '/api/auth/logout', async (ctx) => {
  destroySession(tokenFromRequest(ctx.req));
  clearSessionCookie(ctx.res);
  return ok(ctx.res, { message: 'Signed out.' });
});

route('GET', '/api/auth/me', async (ctx) => {
  const user = ctx.user ? publicUser(ctx.user) : null;
  return ok(ctx.res, {
    user,
    subscription: ctx.user ? subscriptionState(ctx.user.id) : null,
    usage: ctx.user ? usageSummary(ctx.user.id) : null,
  });
}, { auth: false });

route('PATCH', '/api/auth/profile', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson(ctx.req);
  const name = b.name !== undefined ? str(b.name, { max: 80, min: 2, field: 'Name' }) : user.name;
  run(
    `UPDATE users SET name = ?, school = ?, course = ?, year_level = ?, avatar_color = ? WHERE id = ?`,
    name,
    b.school !== undefined ? str(b.school, { max: 120 }) : user.school,
    b.course !== undefined ? str(b.course, { max: 120 }) : user.course,
    b.yearLevel !== undefined ? str(b.yearLevel, { max: 60 }) : user.year_level,
    b.avatarColor !== undefined ? str(b.avatarColor, { max: 20 }) : user.avatar_color,
    user.id
  );
  if (b.email !== undefined) {
    const email = validEmail(b.email);
    const clash = one('SELECT id FROM users WHERE email = ? AND id <> ?', email, user.id);
    if (clash) throw new HttpError(409, 'That email is already in use.');
    run('UPDATE users SET email = ? WHERE id = ?', email, user.id);
  }
  const fresh = one('SELECT * FROM users WHERE id = ?', user.id);
  return ok(ctx.res, { user: publicUser(fresh), message: 'Profile updated.' });
});

route('POST', '/api/auth/change-password', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson(ctx.req);
  const [salt, hash] = String(user.password_hash).split(':');
  if (!verifyPassword(String(b.currentPassword || ''), salt, hash)) {
    throw bad('Your current password is incorrect.');
  }
  updatePassword(user.id, b.newPassword);
  // keep the current device signed in
  const token = createSession(user.id);
  setSessionCookie(ctx.res, token);
  return ok(ctx.res, { token, message: 'Password updated.' });
});

route('POST', '/api/auth/forgot-password', async (ctx) => {
  const b = await readJson(ctx.req);
  const email = validEmail(b.email);
  const user = one('SELECT * FROM users WHERE email = ?', email);

  // Always respond 200 so the endpoint can't be used to enumerate accounts.
  const response = {
    message: 'If that email is registered, a reset link has been sent.',
  };
  if (!user) return ok(ctx.res, response);

  const token = createPasswordReset(user.id);
  const origin = `http://${ctx.req.headers.host || 'localhost'}`;
  const link = `${origin}/?reset=${token}`;

  // ── Email delivery ────────────────────────────────────────────────
  // Add RESEND_API_KEY to .env to send this automatically. Until then the
  // link is returned in the API response (dev mode) so the flow is testable.
  let emailed = false;
  if (config.mail.resendKey) {
    try {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${config.mail.resendKey}`,
        },
        body: JSON.stringify({
          from: config.mail.from,
          to: [email],
          subject: 'Reset your AXTUDY password',
          html: `<p>Hi ${user.name || 'there'},</p><p>Tap the link below to set a new AXTUDY password. It expires in 24 hours.</p><p><a href="${link}">Reset my password</a></p><p>If you did not request this, you can ignore this email.</p>`,
        }),
      });
      emailed = res.ok;
    } catch { emailed = false; }
  }
  return ok(ctx.res, {
    ...response,
    emailed,
    ...(config.DEV_SHOW_RESET_LINK && !emailed ? { devResetLink: link, devResetToken: token } : {}),
  });
}, { auth: false });

route('POST', '/api/auth/reset-password', async (ctx) => {
  const b = await readJson(ctx.req);
  const row = consumePasswordReset(b.token);
  updatePassword(row.user_id, b.password);
  markResetUsed(b.token);
  return ok(ctx.res, { message: 'Password reset. You can now sign in with your new password.' });
}, { auth: false });

/* ───────────────────────────── dashboard ───────────────────────────── */

route('GET', '/api/dashboard', async (ctx) => {
  const user = requireUser(ctx);
  const today = localDayBounds(0);
  const weekEnd = localDayBounds(7).end;

  const todayClasses = all(
    'SELECT * FROM classes WHERE user_id = ? AND day_of_week = ? ORDER BY start_time',
    user.id, today.index
  ).map(publicClass);

  const allClasses = all('SELECT * FROM classes WHERE user_id = ?', user.id);
  const tomorrow = localDayBounds(1);
  const tomorrowClasses = all(
    'SELECT * FROM classes WHERE user_id = ? AND day_of_week = ? ORDER BY start_time',
    user.id, tomorrow.index
  ).map(publicClass);

  const pending = all(
    `SELECT * FROM assignments WHERE user_id = ? AND status = 'pending' ORDER BY due_at`,
    user.id
  ).map(publicAssignment);

  const upcomingAssignments = pending
    .filter((a) => a.dueAt >= today.start && a.dueAt <= weekEnd)
    .slice(0, 8);
  const dueToday = pending.filter((a) => a.dueAt >= today.start && a.dueAt < today.end);
  const overdue = pending.filter((a) => a.dueAt < today.start);
  const upcomingExams = pending
    .filter((a) => a.type === 'exam')
    .slice(0, 5);
  const completedCount = one(
    `SELECT COUNT(*) AS c FROM assignments WHERE user_id = ? AND status = 'completed'`,
    user.id
  )?.c || 0;

  const materialsCount = one('SELECT COUNT(*) AS c FROM materials WHERE user_id = ?', user.id)?.c || 0;
  const outputsCount = one('SELECT COUNT(*) AS c FROM ai_outputs WHERE user_id = ?', user.id)?.c || 0;

  return ok(ctx.res, {
    user: publicUser(user),
    greeting: `${today.name}`,
    today: { dayName: today.name, date: new Date().toISOString() },
    todayClasses,
    tomorrowClasses,
    upcomingAssignments,
    upcomingExams,
    dueToday,
    overdue,
    stats: {
      classes: allClasses.length,
      pendingAssignments: pending.length,
      dueToday: dueToday.length,
      overdue: overdue.length,
      completed: completedCount,
      materials: materialsCount,
      aiOutputs: outputsCount,
    },
    subscription: subscriptionState(user.id),
    usage: usageSummary(user.id),
    aiEngine: engineInfo(),
  });
});

/* ───────────────────────────── classes ───────────────────────────── */

route('GET', '/api/classes', async (ctx) => {
  const user = requireUser(ctx);
  const rows = all(
    'SELECT * FROM classes WHERE user_id = ? ORDER BY day_of_week, start_time',
    user.id
  ).map(publicClass);
  const grouped = DAY_NAMES.map((name, i) => ({
    dayOfWeek: i,
    dayName: name,
    classes: rows.filter((r) => r.dayOfWeek === i),
  }));
  return ok(ctx.res, { classes: rows, byDay: grouped, dayNames: DAY_NAMES });
});

const classPayload = (b, partial = false) => {
  const p = {};
  if (!partial || b.subjectName !== undefined) p.subject_name = str(b.subjectName, { max: 120, min: 1, field: 'Subject name' });
  if (!partial || b.subjectCode !== undefined) p.subject_code = str(b.subjectCode ?? '', { max: 40 });
  if (!partial || b.instructor !== undefined) p.instructor = str(b.instructor ?? '', { max: 120 });
  if (!partial || b.room !== undefined) p.room = str(b.room ?? '', { max: 80 });
  if (!partial || b.dayOfWeek !== undefined) p.day_of_week = clampInt(b.dayOfWeek, 1, 0, 6);
  if (!partial || b.startTime !== undefined) p.start_time = str(b.startTime || '08:00', { max: 5 });
  if (!partial || b.endTime !== undefined) p.end_time = str(b.endTime || '09:30', { max: 5 });
  if (!partial || b.color !== undefined) p.color = str(b.color || '#4F46E5', { max: 20 });
  return p;
};

route('POST', '/api/classes', async (ctx) => {
  const user = requireUser(ctx);
  const p = classPayload(await readJson(ctx.req));
  const id = newId('cls');
  run(
    `INSERT INTO classes (id, user_id, subject_name, subject_code, instructor, room, day_of_week, start_time, end_time, color, created_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    id, user.id, p.subject_name, p.subject_code, p.instructor, p.room,
    p.day_of_week, p.start_time, p.end_time, p.color, nowIso()
  );
  return created(ctx.res, { class: publicClass(one('SELECT * FROM classes WHERE id = ?', id)) });
});

route('PATCH', '/api/classes/:id', async (ctx) => {
  const user = requireUser(ctx);
  const existing = one('SELECT * FROM classes WHERE id = ? AND user_id = ?', ctx.params.id, user.id);
  if (!existing) throw notFound('Class not found.');
  const p = classPayload(await readJson(ctx.req), true);
  const keys = Object.keys(p);
  if (!keys.length) throw bad('Nothing to update.');
  run(
    `UPDATE classes SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ? AND user_id = ?`,
    ...keys.map((k) => p[k]), ctx.params.id, user.id
  );
  return ok(ctx.res, { class: publicClass(one('SELECT * FROM classes WHERE id = ?', ctx.params.id)) });
});

route('DELETE', '/api/classes/:id', async (ctx) => {
  const user = requireUser(ctx);
  const existing = one('SELECT * FROM classes WHERE id = ? AND user_id = ?', ctx.params.id, user.id);
  if (!existing) throw notFound('Class not found.');
  run('DELETE FROM classes WHERE id = ? AND user_id = ?', ctx.params.id, user.id);
  return ok(ctx.res, { message: 'Class deleted.', id: ctx.params.id });
});

/* ───────────────────────────── assignments ───────────────────────────── */

route('GET', '/api/assignments', async (ctx) => {
  const user = requireUser(ctx);
  const view = ctx.query.get('view') || 'upcoming';
  const today = localDayBounds(0);
  const allRows = all('SELECT * FROM assignments WHERE user_id = ? ORDER BY due_at', user.id)
    .map(publicAssignment);

  const pending = allRows.filter((a) => a.status !== 'completed');
  const buckets = {
    today: pending.filter((a) => a.dueAt >= today.start && a.dueAt < today.end),
    upcoming: pending.filter((a) => a.dueAt >= today.end),
    overdue: pending.filter((a) => a.dueAt < today.start),
    completed: allRows.filter((a) => a.status === 'completed').reverse(),
    exams: pending.filter((a) => a.type === 'exam'),
    all: allRows,
  };
  const list = buckets[view] ?? buckets.upcoming;
  const counts = Object.fromEntries(Object.entries(buckets).map(([k, v]) => [k, v.length]));
  return ok(ctx.res, { view, assignments: list, counts, today: today.name });
});

const assignmentPayload = (b, partial = false) => {
  const p = {};
  if (!partial || b.title !== undefined) p.title = str(b.title, { max: 160, min: 1, field: 'Title' });
  if (!partial || b.subject !== undefined) p.subject = str(b.subject ?? '', { max: 120 });
  if (!partial || b.description !== undefined) p.description = str(b.description ?? '', { max: 4000 });
  if (!partial || b.classId !== undefined) p.class_id = b.classId ? String(b.classId) : null;
  if (!partial || b.type !== undefined) {
    const t = String(b.type || 'assignment');
    p.type = ['assignment', 'exam', 'quiz', 'project', 'activity'].includes(t) ? t : 'assignment';
  }
  if (!partial || b.dueAt !== undefined) {
    if (!isValidDate(b.dueAt)) throw bad('Please choose a valid due date and time.');
    p.due_at = new Date(b.dueAt).toISOString();
  }
  if (!partial || b.priority !== undefined) {
    const pr = String(b.priority || 'medium');
    p.priority = ['low', 'medium', 'high'].includes(pr) ? pr : 'medium';
  }
  if (!partial || b.status !== undefined) {
    const s = String(b.status || 'pending');
    p.status = ['pending', 'completed'].includes(s) ? s : 'pending';
  }
  if (!partial || b.reminderAt !== undefined) {
    p.reminder_at = isValidDate(b.reminderAt) ? new Date(b.reminderAt).toISOString() : null;
  }
  return p;
};

route('POST', '/api/assignments', async (ctx) => {
  const user = requireUser(ctx);
  const p = assignmentPayload(await readJson(ctx.req));
  const id = newId('asg');
  run(
    `INSERT INTO assignments (id, user_id, class_id, title, subject, description, type, due_at, priority, status, reminder_at, completed_at, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    id, user.id, p.class_id, p.title, p.subject, p.description, p.type, p.due_at,
    p.priority, p.status, p.reminder_at || null,
    p.status === 'completed' ? nowIso() : null, nowIso(), nowIso()
  );
  return created(ctx.res, { assignment: publicAssignment(one('SELECT * FROM assignments WHERE id = ?', id)) });
});

route('PATCH', '/api/assignments/:id', async (ctx) => {
  const user = requireUser(ctx);
  const existing = one('SELECT * FROM assignments WHERE id = ? AND user_id = ?', ctx.params.id, user.id);
  if (!existing) throw notFound('Assignment not found.');
  const p = assignmentPayload(await readJson(ctx.req), true);
  p.updated_at = nowIso();
  if (p.status === 'completed') p.completed_at = nowIso();
  if (p.status === 'pending') p.completed_at = null;
  const keys = Object.keys(p);
  run(
    `UPDATE assignments SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ? AND user_id = ?`,
    ...keys.map((k) => p[k]), ctx.params.id, user.id
  );
  return ok(ctx.res, { assignment: publicAssignment(one('SELECT * FROM assignments WHERE id = ?', ctx.params.id)) });
});

route('POST', '/api/assignments/:id/toggle', async (ctx) => {
  const user = requireUser(ctx);
  const existing = one('SELECT * FROM assignments WHERE id = ? AND user_id = ?', ctx.params.id, user.id);
  if (!existing) throw notFound('Assignment not found.');
  const done = existing.status === 'completed';
  run(
    'UPDATE assignments SET status = ?, completed_at = ?, updated_at = ? WHERE id = ? AND user_id = ?',
    done ? 'pending' : 'completed', done ? null : nowIso(), nowIso(), ctx.params.id, user.id
  );
  return ok(ctx.res, { assignment: publicAssignment(one('SELECT * FROM assignments WHERE id = ?', ctx.params.id)) });
});

route('DELETE', '/api/assignments/:id', async (ctx) => {
  const user = requireUser(ctx);
  const existing = one('SELECT * FROM assignments WHERE id = ? AND user_id = ?', ctx.params.id, user.id);
  if (!existing) throw notFound('Assignment not found.');
  run('DELETE FROM assignments WHERE id = ? AND user_id = ?', ctx.params.id, user.id);
  return ok(ctx.res, { message: 'Assignment deleted.', id: ctx.params.id });
});

/* ───────────────────────────── materials ───────────────────────────── */

route('GET', '/api/materials', async (ctx) => {
  const user = requireUser(ctx);
  const rows = all('SELECT * FROM materials WHERE user_id = ? ORDER BY created_at DESC', user.id);
  return ok(ctx.res, {
    materials: rows.map(publicMaterial),
    capabilities: extractionCapabilities(),
    limits: LIMITS,
  });
});

route('POST', '/api/materials', async (ctx) => {
  const user = requireUser(ctx);
  const ctype = ctx.req.headers['content-type'] || '';

  // ── Pasted notes (JSON) ───────────────────────────────────────────
  if (ctype.includes('application/json')) {
    const b = await readJson(ctx.req, 5 * 1024 * 1024);
    const title = str(b.title, { max: 160, min: 1, field: 'Title' });
    const text = str(b.text, { max: 400000, min: 20, field: 'Notes' });
    enforceQuota(user.id, 'upload');
    const id = newId('mat');
    run(
      `INSERT INTO materials (id, user_id, class_id, title, filename, mime, size_bytes, stored_path, kind, text_content, text_source, char_count, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      id, user.id, b.classId || null, title, 'pasted-notes.txt', 'text/plain',
      Buffer.byteLength(text), '', 'notes', text, 'pasted', text.length, nowIso()
    );
    bumpUsage(user.id, 'uploads');
    return created(ctx.res, {
      material: publicMaterial(one('SELECT * FROM materials WHERE id = ?', id)),
      message: 'Notes saved and ready for the Study Assistant.',
      usage: usageSummary(user.id),
    });
  }

  // ── File upload (multipart) ───────────────────────────────────────
  const { limits } = enforceQuota(user.id, 'upload');
  const buffer = await readBuffer(ctx.req, config.MAX_UPLOAD_BYTES);
  const { fields, files } = parseMultipart(buffer, ctype);
  const file = files[0];
  if (!file || !file.buffer.length) throw bad('Attach a file to upload, or paste your notes as text.');

  const mb = file.buffer.length / 1048576;
  if (mb > limits.maxFileMb) {
    throw new HttpError(413, `File is ${mb.toFixed(1)} MB. Your plan allows up to ${limits.maxFileMb} MB per file.`, {
      code: 'FILE_TOO_LARGE', upgrade: !limits.materialsStored, limit: limits.maxFileMb,
    });
  }

  const title = str(fields.title || file.filename, { max: 160, min: 1, field: 'Title' });
  const kind = kindFor(file.filename, file.mime);
  const extracted = extractText({ buffer: file.buffer, filename: file.filename, mime: file.mime, kind });

  const safeName = `${uid()}-${path.basename(file.filename).replace(/[^a-zA-Z0-9._-]/g, '_')}`;
  const storedPath = path.join(config.UPLOAD_DIR, safeName);
  fs.writeFileSync(storedPath, file.buffer);

  const id = newId('mat');
  run(
    `INSERT INTO materials (id, user_id, class_id, title, filename, mime, size_bytes, stored_path, kind, text_content, text_source, char_count, created_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    id, user.id, fields.classId || null, title, file.filename, file.mime, file.buffer.length,
    storedPath, kind, extracted.text, extracted.source, extracted.text.length, nowIso()
  );
  bumpUsage(user.id, 'uploads');

  return created(ctx.res, {
    material: publicMaterial(one('SELECT * FROM materials WHERE id = ?', id)),
    extraction: { source: extracted.source, note: extracted.note || '', chars: extracted.text.length },
    message: extracted.text
      ? `Uploaded "${file.filename}" and read ${extracted.text.length.toLocaleString()} characters.`
      : `Uploaded "${file.filename}", but no text could be read.`,
    usage: usageSummary(user.id),
  });
});

route('GET', '/api/materials/:id', async (ctx) => {
  const user = requireUser(ctx);
  const m = ownMaterial(user.id, ctx.params.id);
  const outputs = all(
    'SELECT * FROM ai_outputs WHERE user_id = ? AND material_id = ? ORDER BY created_at DESC',
    user.id, m.id
  ).map(publicOutput);
  const chat = all(
    'SELECT * FROM chat_messages WHERE user_id = ? AND material_id = ? ORDER BY created_at',
    user.id, m.id
  );
  return ok(ctx.res, {
    material: { ...publicMaterial(m), textContent: m.text_content },
    outputs,
    chat: chat.map((c) => ({ id: c.id, role: c.role, content: c.content, createdAt: c.created_at })),
  });
});

route('DELETE', '/api/materials/:id', async (ctx) => {
  const user = requireUser(ctx);
  const m = ownMaterial(user.id, ctx.params.id);
  if (m.stored_path) {
    try { fs.unlinkSync(m.stored_path); } catch { /* file may already be gone */ }
  }
  run('DELETE FROM materials WHERE id = ? AND user_id = ?', m.id, user.id);
  return ok(ctx.res, { message: 'Material deleted.', id: m.id });
});

route('POST', '/api/materials/:id/vision', async (ctx) => {
  const user = requireUser(ctx);
  const m = ownMaterial(user.id, ctx.params.id);
  if (m.kind !== 'image') throw bad('This material is not an image.');
  if (!m.stored_path || !fs.existsSync(m.stored_path)) throw bad('The original image file is no longer available.');
  enforceQuota(user.id, 'ai');
  const buf = fs.readFileSync(m.stored_path);
  const { text, note } = await describeImageWithGemini({ buffer: buf, mime: m.mime });
  if (text) {
    run('UPDATE materials SET text_content = ?, text_source = ?, char_count = ? WHERE id = ? AND user_id = ?',
      text, 'gemini-vision', text.length, m.id, user.id);
    bumpUsage(user.id, 'ai_outputs');
  }
  return ok(ctx.res, {
    material: publicMaterial(one('SELECT * FROM materials WHERE id = ?', m.id)),
    note: note || '',
    message: text ? `Read ${text.length.toLocaleString()} characters from the image.` : 'No text found in the image.',
  }, text ? 200 : 200);
});

/* ───────────────────────────── AI study assistant ───────────────────────────── */

route('GET', '/api/ai/engine', async (ctx) => {
  const user = requireUser(ctx);
  return ok(ctx.res, { engine: engineInfo(), capabilities: extractionCapabilities(), limits: LIMITS });
});

route('POST', '/api/ai/:task', async (ctx) => {
  const user = requireUser(ctx);
  const task = ctx.params.task;
  if (!TASKS.includes(task)) throw notFound(`Unknown study task "${task}".`);
  const b = await readJson(ctx.req);

  const isQuestion = task === 'ask';
  enforceQuota(user.id, isQuestion ? 'question' : 'ai');

  let text = '';
  let title = 'Your notes';
  let material = null;

  if (b.materialId) {
    material = ownMaterial(user.id, b.materialId);
    text = material.text_content;
    title = material.title;
    if (!text || text.trim().length < 30) {
      throw bad(
        material.kind === 'image'
          ? 'This image has no readable text yet. Use "Read with AI" on the material first.'
          : 'This material does not contain enough readable text. Paste your notes instead, or upload a text-based PDF.',
        { code: 'NO_TEXT' }
      );
    }
  } else {
    text = str(b.text || '', { max: 400000 });
    title = str(b.title || 'Pasted notes', { max: 160 });
    if (text.trim().length < 30) throw bad('Paste at least a few sentences so the assistant has something to work with.');
  }

  let count = 0;
  let capNote = '';
  if (task === 'quiz' || task === 'truefalse') {
    const capped = capCount(user.id, b.count, 'quizQuestions');
    count = capped.value;
    if (capped.capped) capNote = `Free plan is capped at ${capped.max} questions. AXTUDY PRO allows up to 25.`;
  }
  if (task === 'flashcards') {
    const capped = capCount(user.id, b.count, 'flashcards');
    count = capped.value;
    if (capped.capped) capNote = `Free plan is capped at ${capped.max} flashcards. AXTUDY PRO allows up to 60.`;
  }

  const { engine, result, fallback, fallbackReason } = await runStudyTask(task, {
    text,
    title,
    topic: b.topic || '',
    question: b.question || '',
    count,
  });

  const outputId = newId('out');
  run(
    `INSERT INTO ai_outputs (id, user_id, material_id, kind, title, payload, engine, created_at)
     VALUES (?,?,?,?,?,?,?,?)`,
    outputId, user.id, material ? material.id : null, task,
    result.title || title, JSON.stringify(result), engine, nowIso()
  );
  if (isQuestion) {
    run(
      'INSERT INTO chat_messages (id, user_id, material_id, role, content, created_at) VALUES (?,?,?,?,?,?)',
      newId('msg'), user.id, material ? material.id : null, 'user', String(b.question || ''), nowIso()
    );
    run(
      'INSERT INTO chat_messages (id, user_id, material_id, role, content, created_at) VALUES (?,?,?,?,?,?)',
      newId('msg2'), user.id, material ? material.id : null, 'assistant', result.answer || '', nowIso()
    );
  }

  if (isQuestion) bumpUsage(user.id, 'questions');
  else bumpUsage(user.id, 'ai_outputs');

  const payload = {
    output: publicOutput(one('SELECT * FROM ai_outputs WHERE id = ?', outputId)),
    engine,
    fallback,
    fallbackReason: fallbackReason || '',
    note: capNote,
    usage: usageSummary(user.id),
  };
  if (isQuestion) {
    payload.chat = all(
      'SELECT * FROM chat_messages WHERE user_id = ? AND material_id IS ? ORDER BY created_at',
      user.id, material ? material.id : null
    ).map((c) => ({ id: c.id, role: c.role, content: c.content, createdAt: c.created_at }));
  }
  return created(ctx.res, payload);
});

route('GET', '/api/ai/outputs', async (ctx) => {
  const user = requireUser(ctx);
  const kind = ctx.query.get('kind');
  const materialId = ctx.query.get('materialId');
  const clauses = ['user_id = ?'];
  const args = [user.id];
  if (kind) { clauses.push('kind = ?'); args.push(kind); }
  if (materialId) { clauses.push('material_id = ?'); args.push(materialId); }
  const rows = all(
    `SELECT * FROM ai_outputs WHERE ${clauses.join(' AND ')} ORDER BY created_at DESC LIMIT 200`,
    ...args
  );
  return ok(ctx.res, { outputs: rows.map(publicOutput), engine: engineInfo() });
});

route('DELETE', '/api/ai/outputs/:id', async (ctx) => {
  const user = requireUser(ctx);
  const row = one('SELECT * FROM ai_outputs WHERE id = ? AND user_id = ?', ctx.params.id, user.id);
  if (!row) throw notFound('Result not found.');
  run('DELETE FROM ai_outputs WHERE id = ? AND user_id = ?', row.id, user.id);
  return ok(ctx.res, { message: 'Deleted.', id: row.id });
});

/* ───────────────────────────── billing ───────────────────────────── */

route('GET', '/api/billing/status', async (ctx) => {
  const user = requireUser(ctx);
  return ok(ctx.res, {
    subscription: subscriptionState(user.id),
    usage: usageSummary(user.id),
    plans: {
      free: { label: 'Free', limits: LIMITS.free },
      pro: { label: 'AXTUDY PRO', pricePhp: config.billing.pricePhp, trialDays: config.billing.trialDays, interval: 'month', limits: LIMITS.pro },
    },
  });
});

route('POST', '/api/billing/trial', async (ctx) => {
  const user = requireUser(ctx);
  const subscription = startTrial(user.id);
  return ok(ctx.res, {
    subscription,
    message: `Your ${config.billing.trialDays}-day AXTUDY PRO trial is active. No charge until ${new Date(subscription.trialEndsAt).toLocaleDateString()}.`,
  });
});

route('POST', '/api/billing/checkout', async (ctx) => {
  const user = requireUser(ctx);
  const origin = `http://${ctx.req.headers.host || `localhost:${config.PORT}`}`;
  const checkout = await createCheckout(user.id, {
    email: user.email, name: user.name, origin,
  });
  if (checkout.mode === 'simulated') {
    // Complete the simulated checkout immediately so the flow is testable.
    const subscription = activatePaidPeriod(user.id, { provider: 'simulated', providerRef: checkout.reference });
    return created(ctx.res, {
      checkout, subscription,
      message: `Simulated payment approved — AXTUDY PRO active at ₱${config.billing.pricePhp}/month. Add PayMongo keys in .env to take real payments.`,
    });
  }
  return created(ctx.res, { checkout, message: 'Redirecting to the PayMongo checkout.' });
});

/** Called by the client after PayMongo redirects back (success_url). */
route('POST', '/api/billing/confirm', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson(ctx.req);
  if (!config.billing.paymongoSecret) {
    const subscription = activatePaidPeriod(user.id, { provider: 'simulated', providerRef: b.reference || null });
    return ok(ctx.res, { subscription, message: 'Subscription active.' });
  }
  // With PayMongo configured, the webhook is authoritative. We optimistically
  // activate so the student is not blocked while the webhook arrives.
  const subscription = activatePaidPeriod(user.id, { provider: 'paymongo', providerRef: b.reference || null });
  return ok(ctx.res, { subscription, message: 'Payment received — AXTUDY PRO is active.' });
});

route('POST', '/api/billing/cancel', async (ctx) => {
  const user = requireUser(ctx);
  const subscription = cancelSubscription(user.id);
  return ok(ctx.res, {
    subscription,
    message: subscription.isPro
      ? `Subscription canceled. You keep PRO access until ${new Date(subscription.currentPeriodEnd).toLocaleDateString()}.`
      : 'Subscription canceled.',
  });
});

route('POST', '/api/billing/resume', async (ctx) => {
  const user = requireUser(ctx);
  return ok(ctx.res, { subscription: resumeSubscription(user.id), message: 'Subscription resumed.' });
});

/** Dev-only helper so you can re-test the trial/subscribe flow. */
route('POST', '/api/billing/reset', async (ctx) => {
  const user = requireUser(ctx);
  if (process.env.NODE_ENV === 'production' && !config.DEV_SHOW_RESET_LINK) {
    throw forbidden('Subscription reset is disabled in production.');
  }
  return ok(ctx.res, { subscription: resetSubscription(user.id), message: 'Returned to the Free plan (dev helper).' });
});

/* ── PayMongo webhook (public, signature-verified) ── */
route('POST', '/api/webhooks/paymongo', async (ctx) => {
  const raw = await readBuffer(ctx.req, 1024 * 1024);
  const rawText = raw.toString('utf8');
  const sig = ctx.req.headers['paymongo-signature'];
  if (!verifyPaymongoSignature(rawText, sig)) {
    throw unauthorized('Invalid webhook signature.');
  }
  let event = {};
  try { event = JSON.parse(rawText); } catch { throw bad('Invalid webhook payload.'); }
  const type = String(event?.data?.attributes?.type || '');
  const payload = event?.data?.attributes?.data || {};
  const ref = payload?.attributes?.reference_number
    || payload?.attributes?.metadata?.reference_number
    || payload?.id;
  const userId = findUserByProviderRef(ref) || findUserByProviderRef(payload?.id);

  if (!userId) return ok(ctx.res, { received: true, ignored: 'no matching subscription', reference: ref });

  if (/checkout_session\.payment\.paid|payment\.paid|subscription\.invoice\.paid/i.test(type)) {
    activatePaidPeriod(userId, { provider: 'paymongo', providerRef: ref });
  } else if (/payment\.failed|subscription\.invoice\.payment_failed/i.test(type)) {
    run("UPDATE subscriptions SET status = 'past_due', updated_at = ? WHERE user_id = ?", nowIso(), userId);
  } else if (/subscription\.cancelled|subscription\.canceled/i.test(type)) {
    run("UPDATE subscriptions SET status = 'canceled', canceled_at = ?, updated_at = ? WHERE user_id = ?", nowIso(), nowIso(), userId);
  }
  return ok(ctx.res, { received: true, type, reference: ref });
}, { auth: false });

/* ───────────────────────────── demo helpers ───────────────────────────── */

route('POST', '/api/demo/reseed', async (ctx) => {
  const user = requireUser(ctx);
  const result = seedDemoData(user.id, { reset: true });
  return ok(ctx.res, { message: 'Demo data reloaded.', ...result });
});

route('GET', '/api/health', async (ctx) =>
  ok(ctx.res, {
    service: 'AXTUDY',
    version: '1.0.0',
    time: nowIso(),
    ai: engineInfo(),
    extraction: extractionCapabilities(),
    billing: { provider: config.billing.paymongoSecret ? 'paymongo' : 'simulated', pricePhp: config.billing.pricePhp, trialDays: config.billing.trialDays },
    demoAccount: DEMO_EMAIL,
  }), { auth: false });

/* ───────────────────────────── router ───────────────────────────── */

function match(pattern, pathname) {
  const p = pattern.split('/').filter(Boolean);
  const s = pathname.split('/').filter(Boolean);
  if (p.length !== s.length) return null;
  const params = {};
  for (let i = 0; i < p.length; i++) {
    if (p[i].startsWith(':')) params[p[i].slice(1)] = decodeURIComponent(s[i]);
    else if (p[i] !== s[i]) return null;
  }
  return params;
}

export async function handleApi(req, res, url) {
  const method = req.method.toUpperCase();
  for (const r of routes) {
    if (r.method !== method) continue;
    const params = match(r.pattern, url.pathname);
    if (!params) continue;

    const ctx = { req, res, url, params, query: url.searchParams, user: null };
    try {
      ctx.user = currentUser(req);
      if (r.auth && !ctx.user) {
        return json(res, 401, { ok: false, error: 'Please sign in to continue.', code: 'UNAUTHENTICATED' });
      }
      return await r.handler(ctx);
    } catch (err) {
      if (err instanceof HttpError) {
        return json(res, err.status, { ok: false, error: err.message, ...err.extra });
      }
      console.error(`[AXTUDY] ${method} ${url.pathname} failed:`, err);
      return json(res, 500, {
        ok: false,
        error: 'Something went wrong on our side. Please try again.',
        detail: process.env.NODE_ENV === 'production' ? undefined : String(err?.message || err),
      });
    }
  }
  return json(res, 404, { ok: false, error: `No API route for ${method} ${url.pathname}` });
}

export { routes };
