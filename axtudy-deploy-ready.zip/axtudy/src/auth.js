/**
 * AXTUDY — authentication.
 * Passwords: scrypt with a per-user random salt.
 * Sessions: opaque random tokens stored in SQLite, delivered as an
 * httpOnly cookie (and also usable as `Authorization: Bearer <token>`).
 */
import crypto from 'node:crypto';
import { config } from './config.js';
import { one, run, newId, ensureSubscription } from './db.js';
import {
  uid, nowIso, addDays, parseCookies, setCookie, str, validEmail,
  unauthorized, bad, HttpError,
} from './util.js';

const SESSION_COOKIE = 'axtudy_session';

export function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash };
}

export function verifyPassword(password, salt, expected) {
  const { hash } = hashPassword(password, salt);
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(expected, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function validatePassword(password) {
  const p = String(password || '');
  if (p.length < 8) throw bad('Password must be at least 8 characters.');
  if (p.length > 200) throw bad('Password is too long.');
  return p;
}

export function createUser({ email, password, name, school = '', course = '', yearLevel = '' }) {
  const cleanEmail = validEmail(email);
  validatePassword(password);
  const cleanName = str(name, { max: 80, min: 2, field: 'Name' });
  const exists = one('SELECT id FROM users WHERE email = ?', cleanEmail);
  if (exists) throw new HttpError(409, 'An account with that email already exists.');

  const { salt, hash } = hashPassword(password);
  const id = newId('usr');
  const colors = ['#4F46E5', '#0EA5E9', '#10B981', '#F59E0B', '#EC4899', '#8B5CF6'];
  run(
    `INSERT INTO users (id, email, password_hash, name, school, course, year_level, avatar_color, created_at)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    id, cleanEmail, `${salt}:${hash}`, cleanName,
    str(school, { max: 120 }), str(course, { max: 120 }), str(yearLevel, { max: 60 }),
    colors[Math.floor(Math.random() * colors.length)], nowIso()
  );
  ensureSubscription(id);
  return publicUser(one('SELECT * FROM users WHERE id = ?', id));
}

export function publicUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    school: row.school,
    course: row.course,
    yearLevel: row.year_level,
    avatarColor: row.avatar_color,
    isDemo: !!row.is_demo,
    createdAt: row.created_at,
  };
}

export function authenticate(email, password) {
  const cleanEmail = validEmail(email);
  const row = one('SELECT * FROM users WHERE email = ?', cleanEmail);
  if (!row) throw unauthorized('Incorrect email or password.');
  const [salt, hash] = String(row.password_hash).split(':');
  if (!verifyPassword(String(password || ''), salt, hash)) {
    throw unauthorized('Incorrect email or password.');
  }
  return row;
}

export function createSession(userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  const expires = addDays(new Date(), config.SESSION_DAYS);
  run('INSERT INTO sessions (token, user_id, created_at, expires_at) VALUES (?,?,?,?)',
    token, userId, nowIso(), expires.toISOString());
  // opportunistic cleanup
  run('DELETE FROM sessions WHERE expires_at < ?', nowIso());
  return token;
}

export function setSessionCookie(res, token) {
  setCookie(res, SESSION_COOKIE, token, {
    maxAge: config.SESSION_DAYS * 86400,
    httpOnly: true,
    sameSite: 'Lax',
    secure: process.env.NODE_ENV === 'production',
  });
}

export function clearSessionCookie(res) {
  setCookie(res, SESSION_COOKIE, '', { maxAge: 0, httpOnly: true });
}

export function destroySession(token) {
  if (token) run('DELETE FROM sessions WHERE token = ?', token);
}

export function tokenFromRequest(req) {
  const auth = req.headers.authorization || '';
  if (auth.startsWith('Bearer ')) return auth.slice(7).trim();
  return parseCookies(req)[SESSION_COOKIE] || '';
}

/** Resolve req.user (or null). */
export function currentUser(req) {
  const token = tokenFromRequest(req);
  if (!token) return null;
  const session = one('SELECT * FROM sessions WHERE token = ?', token);
  if (!session) return null;
  if (new Date(session.expires_at).getTime() < Date.now()) {
    run('DELETE FROM sessions WHERE token = ?', token);
    return null;
  }
  return one('SELECT * FROM users WHERE id = ?', session.user_id);
}

export function requireUser(ctx) {
  if (!ctx.user) throw unauthorized();
  return ctx.user;
}

/* ───────────────── password reset flow ───────────────── */

export function createPasswordReset(userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  run('INSERT INTO password_resets (token, user_id, created_at, expires_at) VALUES (?,?,?,?)',
    token, userId, nowIso(), addDays(new Date(), 1).toISOString());
  return token;
}

export function consumePasswordReset(token) {
  const row = one('SELECT * FROM password_resets WHERE token = ?', String(token || ''));
  if (!row || row.used) throw bad('This reset link is invalid or has already been used.');
  if (new Date(row.expires_at).getTime() < Date.now()) throw bad('This reset link has expired. Request a new one.');
  return row;
}

export function markResetUsed(token) {
  run('UPDATE password_resets SET used = 1 WHERE token = ?', token);
}

export function updatePassword(userId, newPassword) {
  validatePassword(newPassword);
  const { salt, hash } = hashPassword(newPassword);
  run('UPDATE users SET password_hash = ? WHERE id = ?', `${salt}:${hash}`, userId);
  run('DELETE FROM sessions WHERE user_id = ?', userId); // log out everywhere
}

export { SESSION_COOKIE };
