/**
 * AXTUDY — subscription architecture (AXTUDY PRO · ₱49/month · 3-day free trial).
 *
 * States: none → trialing → active → canceled/expired
 * Quotas are enforced server-side on every AI/upload action.
 *
 * Payment provider: PayMongo (Philippines, PHP). If no keys are configured the
 * app switches to a SIMULATED checkout so the full flow stays testable.
 */
import crypto from 'node:crypto';
import { config, LIMITS } from './config.js';
import { one, run, ensureSubscription, touchSubscription, getUsage } from './db.js';
import { nowIso, addDays, HttpError, bad } from './util.js';

const PLAN = () => ({
  pricePhp: config.billing.pricePhp,
  trialDays: config.billing.trialDays,
  currency: 'PHP',
  interval: 'month',
});

const proProviders = () => ({
  paymongo: Boolean(config.billing.paymongoSecret),
  simulated: !config.billing.paymongoSecret,
});

/** Resolve the live subscription state, lazily expiring stale ones. */
export function subscriptionState(userId) {
  const sub = ensureSubscription(userId);
  const now = Date.now();
  const trialEnds = sub.trial_ends_at ? new Date(sub.trial_ends_at).getTime() : 0;
  const periodEnds = sub.current_period_end ? new Date(sub.current_period_end).getTime() : 0;

  let status = sub.status;
  let isPro = false;

  if (status === 'trialing') {
    if (trialEnds > now) isPro = true;
    else status = 'expired';
  } else if (status === 'active' || status === 'past_due') {
    if (periodEnds > now) isPro = true;
    else status = 'expired';
  } else if (status === 'canceled') {
    // Access continues to the end of the current period — or, if the student
    // cancels during the free trial, to the end of that trial.
    const accessEnds = Math.max(periodEnds, trialEnds);
    isPro = accessEnds > now;
    if (!isPro) status = 'expired';
  }

  if (status !== sub.status) {
    touchSubscription(userId, { status, plan: isPro ? 'pro' : 'free' });
  }

  const accessEndsAt = status === 'trialing' ? trialEnds : Math.max(periodEnds, trialEnds);
  const daysLeft = isPro
    ? Math.max(0, Math.ceil((accessEndsAt - now) / 86400000))
    : 0;

  return {
    plan: isPro ? 'pro' : 'free',
    status,
    isPro,
    isTrialing: status === 'trialing',
    isCanceled: status === 'canceled',
    trialEligible: !sub.trial_started_at,
    trialStartedAt: sub.trial_started_at,
    trialEndsAt: sub.trial_ends_at,
    currentPeriodEnd: sub.current_period_end,
    daysLeft,
    provider: sub.provider,
    providerRef: sub.provider_ref,
    renewedAt: sub.updated_at,
    ...PLAN(),
    providers: proProviders(),
  };
}

export function limitsFor(userId) {
  const state = subscriptionState(userId);
  return { state, limits: state.isPro ? LIMITS.pro : LIMITS.free };
}

export function usageSummary(userId) {
  const { state, limits } = limitsFor(userId);
  const usage = getUsage(userId);
  const stored = one('SELECT COUNT(*) AS c FROM materials WHERE user_id = ?', userId)?.c || 0;
  const pct = (used, cap) => (cap === null ? null : Math.min(100, Math.round((used / cap) * 100)));
  return {
    plan: state.plan,
    status: state.status,
    limits: {
      uploadsPerMonth: limits.uploadsPerMonth,
      aiGenerationsPerMonth: limits.aiGenerationsPerMonth,
      questionsPerMonth: limits.questionsPerMonth,
      quizQuestions: limits.quizQuestions,
      flashcards: limits.flashcards,
      maxFileMb: limits.maxFileMb,
      materialsStored: limits.materialsStored,
    },
    used: {
      uploads: usage.uploads,
      aiGenerations: usage.ai_outputs,
      questions: usage.questions,
      materialsStored: stored,
    },
    percent: {
      uploads: pct(usage.uploads, limits.uploadsPerMonth),
      aiGenerations: pct(usage.ai_outputs, limits.aiGenerationsPerMonth),
      questions: pct(usage.questions, limits.questionsPerMonth),
      materialsStored: pct(stored, limits.materialsStored),
    },
  };
}

/* ───────────────────────── quota enforcement ───────────────────────── */

const QUOTA_LABELS = {
  upload: 'file upload',
  ai: 'AI generation',
  question: 'question about your material',
};

/**
 * Throws a 402 with upgrade metadata when the student has hit a cap.
 * Returns { limits, state, used } on success.
 */
export function enforceQuota(userId, kind, amount = 1) {
  const { state, limits } = limitsFor(userId);
  if (state.isPro) return { state, limits };

  const usage = getUsage(userId);
  const caps = {
    upload: [usage.uploads, limits.uploadsPerMonth],
    ai: [usage.ai_outputs, limits.aiGenerationsPerMonth],
    question: [usage.questions, limits.questionsPerMonth],
  };
  const [used, cap] = caps[kind] || [0, null];
  if (cap !== null && used + amount > cap) {
    throw new HttpError(402, `You have reached the Free limit of ${cap} ${QUOTA_LABELS[kind] || kind}s this month. Upgrade to AXTUDY PRO for unlimited access.`, {
      code: 'LIMIT_REACHED',
      quota: kind,
      used,
      limit: cap,
      upgrade: true,
      price: PLAN(),
    });
  }
  return { state, limits, used };
}

/** Cap a requested AI output size to the plan's maximum. */
export function capCount(userId, requested, maxKey) {
  const { limits } = limitsFor(userId);
  const max = limits[maxKey];
  const want = Number(requested) || max;
  return { value: Math.max(1, Math.min(want, max)), capped: want > max, max };
}

/* ───────────────────────── trial / subscribe / cancel ───────────────────────── */

export function startTrial(userId) {
  const sub = ensureSubscription(userId);
  if (sub.trial_started_at) {
    throw bad('You have already used your free trial.');
  }
  const now = new Date();
  const end = addDays(now, config.billing.trialDays);
  touchSubscription(userId, {
    plan: 'pro',
    status: 'trialing',
    trial_started_at: now.toISOString(),
    trial_ends_at: end.toISOString(),
    provider: proProviders().paymongo ? 'paymongo' : 'simulated',
  });
  return subscriptionState(userId);
}

/** Start a paid subscription period (called by checkout completion/webhook). */
export function activatePaidPeriod(userId, { provider, providerRef, days = 30 } = {}) {
  const anchor = subscriptionState(userId);
  const base = anchor.isPro && anchor.currentPeriodEnd && new Date(anchor.currentPeriodEnd) > new Date()
    ? new Date(anchor.currentPeriodEnd)
    : new Date();
  const end = addDays(base, days);
  touchSubscription(userId, {
    plan: 'pro',
    status: 'active',
    current_period_end: end.toISOString(),
    canceled_at: null,
    provider: provider || 'simulated',
    provider_ref: providerRef || null,
  });
  return subscriptionState(userId);
}

export function cancelSubscription(userId) {
  const state = subscriptionState(userId);
  if (!state.isPro) throw bad('You do not have an active PRO subscription.');
  touchSubscription(userId, { status: 'canceled', canceled_at: nowIso() });
  return subscriptionState(userId);
}

/** Undo a cancellation — returns the student to their previous state. */
export function resumeSubscription(userId) {
  const sub = ensureSubscription(userId);
  if (sub.status !== 'canceled') throw bad('There is no canceled subscription to resume.');
  const now = Date.now();
  const trialStillRunning = sub.trial_ends_at && new Date(sub.trial_ends_at).getTime() > now;
  touchSubscription(userId, {
    status: trialStillRunning ? 'trialing' : 'active',
    canceled_at: null,
  });
  return subscriptionState(userId);
}

/** Test helper / admin: drop back to Free. */
export function resetSubscription(userId) {
  touchSubscription(userId, {
    plan: 'free', status: 'none', trial_started_at: null, trial_ends_at: null,
    current_period_end: null, canceled_at: null, provider: 'none', provider_ref: null,
  });
  return subscriptionState(userId);
}

/* ───────────────────────── checkout (PayMongo) ───────────────────────── */

export async function createCheckout(userId, { email, name, origin }) {
  const amount = Math.round(config.billing.pricePhp * 100); // centavos
  const reference = `axtudy_${userId.slice(-8)}_${Date.now()}`;

  if (!config.billing.paymongoSecret) {
    // Simulated checkout — keeps the flow fully testable without credentials.
    return {
      mode: 'simulated',
      reference,
      amount,
      currency: 'PHP',
      checkoutUrl: null,
      message: 'No PayMongo keys configured — the app will use the built-in simulated checkout.',
    };
  }

  const body = {
    data: {
      attributes: {
        billing: { name: name || 'AXTUDY Student', email },
        line_items: [{
          currency: 'PHP',
          amount,
          name: `AXTUDY PRO — Monthly (${config.billing.trialDays}-day free trial)`,
          quantity: 1,
          description: `Unlimited AI study tools. Renews every month at ₱${config.billing.pricePhp}.`,
        }],
        payment_method_types: ['card', 'gcash', 'paymaya', 'grab_pay'],
        success_url: config.billing.successUrl || `${origin}/?billing=success&ref=${reference}`,
        cancel_url: config.billing.cancelUrl || `${origin}/?billing=cancel&ref=${reference}`,
        description: 'AXTUDY PRO monthly subscription',
        reference_number: reference,
        send_email_receipt: true,
        show_description: true,
        show_line_items: true,
      },
    },
  };

  const res = await fetch('https://api.paymongo.com/v1/checkout_sessions', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json',
      authorization: `Basic ${Buffer.from(`${config.billing.paymongoSecret}:`).toString('base64')}`,
    },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.errors?.[0]?.detail || `PayMongo error ${res.status}`;
    throw new HttpError(502, `Could not start checkout: ${msg}`);
  }
  const session = data?.data;
  touchSubscription(userId, { provider: 'paymongo', provider_ref: session?.id || reference });
  return {
    mode: 'paymongo',
    reference: session?.attributes?.reference_number || reference,
    checkoutUrl: session?.attributes?.checkout_url,
    checkoutSessionId: session?.id,
    amount,
    currency: 'PHP',
  };
}

/** Verify a PayMongo webhook signature (header: paymongo-signature). */
export function verifyPaymongoSignature(rawBody, signatureHeader) {
  const secret = config.billing.paymongoWebhookSecret;
  if (!secret) return true; // no secret configured → accept (dev mode)
  if (!signatureHeader) return false;
  const parts = Object.fromEntries(
    String(signatureHeader).split(',').map((p) => p.split('=').map((s) => s.trim()))
  );
  const t = parts.t;
  if (!t) return false;
  const expected = crypto.createHmac('sha256', secret).update(`${t}.${rawBody}`).digest('hex');
  return ['te', 'li'].some((k) => {
    const got = parts[k];
    return got && got.length === expected.length &&
      crypto.timingSafeEqual(Buffer.from(got), Buffer.from(expected));
  });
}

export function findUserByProviderRef(ref) {
  if (!ref) return null;
  const sub = one('SELECT * FROM subscriptions WHERE provider_ref = ?', ref);
  return sub ? sub.user_id : null;
}
