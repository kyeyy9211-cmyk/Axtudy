/**
 * AXTUDY — configuration
 * Loads .env (if present) with a tiny built-in parser, then exposes
 * typed config + the plan limits that drive the Free / Pro gating.
 */
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(new URL('..', import.meta.url).pathname);

/** Minimal .env loader — no dependency needed. */
function loadEnvFile(file) {
  if (!fs.existsSync(file)) return;
  const raw = fs.readFileSync(file, 'utf8');
  for (const line of raw.split('\n')) {
    const t = line.trim();
    if (!t || t.startsWith('#')) continue;
    const eq = t.indexOf('=');
    if (eq === -1) continue;
    const key = t.slice(0, eq).trim();
    let val = t.slice(eq + 1).trim();
    if (
      (val.startsWith('"') && val.endsWith('"')) ||
      (val.startsWith("'") && val.endsWith("'"))
    ) {
      val = val.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = val;
  }
}
loadEnvFile(path.join(ROOT, '.env'));

const bool = (v, d = false) =>
  v === undefined ? d : ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase());
const num = (v, d) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? d : Number(v));

const DATA_DIR = path.isAbsolute(process.env.DATA_DIR || '')
  ? process.env.DATA_DIR
  : path.join(ROOT, process.env.DATA_DIR || 'data');

export const config = {
  ROOT,
  DATA_DIR,
  UPLOAD_DIR: path.join(DATA_DIR, 'uploads'),
  DB_FILE: path.join(DATA_DIR, 'axtudy.db'),
  PUBLIC_DIR: path.join(ROOT, 'public'),
  PORT: num(process.env.PORT, 3000),
  HOST: process.env.HOST || '0.0.0.0',
  APP_SECRET: process.env.APP_SECRET || 'change-me-axtudy-dev-secret',
  DEV_SHOW_RESET_LINK: bool(process.env.DEV_SHOW_RESET_LINK, true),
  CORS_ORIGINS: (process.env.CORS_ORIGINS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
  MAX_UPLOAD_BYTES: num(process.env.MAX_UPLOAD_BYTES, 25 * 1024 * 1024),
  SESSION_DAYS: num(process.env.SESSION_DAYS, 30),

  ai: {
    provider: (process.env.AI_PROVIDER || 'auto').toLowerCase(),
    openaiKey: process.env.OPENAI_API_KEY || '',
    openaiBase: (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, ''),
    openaiModel: process.env.OPENAI_MODEL || 'gpt-4o-mini',
    geminiKey: process.env.GEMINI_API_KEY || '',
    geminiModel: process.env.GEMINI_MODEL || 'gemini-2.0-flash',
  },

  billing: {
    pricePhp: num(process.env.PRO_PRICE_PHP, 49),
    trialDays: num(process.env.PRO_TRIAL_DAYS, 3),
    paymongoSecret: process.env.PAYMONGO_SECRET_KEY || '',
    paymongoPublic: process.env.PAYMONGO_PUBLIC_KEY || '',
    paymongoWebhookSecret: process.env.PAYMONGO_WEBHOOK_SECRET || '',
    successUrl: process.env.PAYMONGO_SUCCESS_URL || '',
    cancelUrl: process.env.PAYMONGO_CANCEL_URL || '',
  },

  mail: {
    resendKey: process.env.RESEND_API_KEY || '',
    from: process.env.MAIL_FROM || 'AXTUDY <no-reply@axtudy.app>',
  },
};

/**
 * Free vs Pro quotas. `null` means unlimited.
 * Usage is counted per calendar month.
 */
export const LIMITS = {
  free: {
    label: 'Free',
    uploadsPerMonth: 3,
    aiGenerationsPerMonth: 10,
    questionsPerMonth: 5,
    quizQuestions: 5,
    flashcards: 12,
    maxFileMb: 8,
    materialsStored: 10,
  },
  pro: {
    label: 'AXTUDY PRO',
    uploadsPerMonth: null,
    aiGenerationsPerMonth: null,
    questionsPerMonth: null,
    quizQuestions: 25,
    flashcards: 60,
    maxFileMb: 25,
    materialsStored: null,
  },
};

export const DEMO_EMAIL = 'demo@axtudy.app';
export const DEMO_PASSWORD = 'axtudy123';
