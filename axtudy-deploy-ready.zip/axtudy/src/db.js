/**
 * AXTUDY — database layer.
 * Uses Node's built-in SQLite (node:sqlite) so the app has ZERO npm
 * dependencies. Every table is scoped by user_id, which is what keeps
 * each student's data private and separate.
 */
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { config } from './config.js';
import { uid, nowIso } from './util.js';

fs.mkdirSync(config.DATA_DIR, { recursive: true });
fs.mkdirSync(config.UPLOAD_DIR, { recursive: true });

export const db = new DatabaseSync(config.DB_FILE);

db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  name          TEXT NOT NULL DEFAULT '',
  school        TEXT NOT NULL DEFAULT '',
  course        TEXT NOT NULL DEFAULT '',
  year_level    TEXT NOT NULL DEFAULT '',
  avatar_color  TEXT NOT NULL DEFAULT '#4F46E5',
  is_demo       INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS password_resets (
  token      TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used       INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS classes (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_name TEXT NOT NULL,
  subject_code TEXT NOT NULL DEFAULT '',
  instructor   TEXT NOT NULL DEFAULT '',
  room         TEXT NOT NULL DEFAULT '',
  day_of_week  INTEGER NOT NULL DEFAULT 1,
  start_time   TEXT NOT NULL DEFAULT '08:00',
  end_time     TEXT NOT NULL DEFAULT '09:30',
  color        TEXT NOT NULL DEFAULT '#4F46E5',
  created_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS assignments (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id     TEXT REFERENCES classes(id) ON DELETE SET NULL,
  title        TEXT NOT NULL,
  subject      TEXT NOT NULL DEFAULT '',
  description  TEXT NOT NULL DEFAULT '',
  type         TEXT NOT NULL DEFAULT 'assignment',
  due_at       TEXT NOT NULL,
  priority     TEXT NOT NULL DEFAULT 'medium',
  status       TEXT NOT NULL DEFAULT 'pending',
  reminder_at  TEXT,
  completed_at TEXT,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS materials (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id     TEXT REFERENCES classes(id) ON DELETE SET NULL,
  title        TEXT NOT NULL,
  filename     TEXT NOT NULL DEFAULT '',
  mime         TEXT NOT NULL DEFAULT '',
  size_bytes   INTEGER NOT NULL DEFAULT 0,
  stored_path  TEXT NOT NULL DEFAULT '',
  kind         TEXT NOT NULL DEFAULT 'file',
  text_content TEXT NOT NULL DEFAULT '',
  text_source  TEXT NOT NULL DEFAULT '',
  char_count   INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ai_outputs (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  material_id TEXT REFERENCES materials(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL,
  title       TEXT NOT NULL DEFAULT '',
  payload     TEXT NOT NULL,
  engine      TEXT NOT NULL DEFAULT '',
  created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  material_id TEXT REFERENCES materials(id) ON DELETE CASCADE,
  role        TEXT NOT NULL,
  content     TEXT NOT NULL,
  created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS usage (
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  month_key    TEXT NOT NULL,
  uploads      INTEGER NOT NULL DEFAULT 0,
  ai_outputs   INTEGER NOT NULL DEFAULT 0,
  questions    INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, month_key)
);

CREATE TABLE IF NOT EXISTS subscriptions (
  user_id            TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  plan               TEXT NOT NULL DEFAULT 'free',
  status             TEXT NOT NULL DEFAULT 'none',
  trial_started_at   TEXT,
  trial_ends_at      TEXT,
  current_period_end TEXT,
  canceled_at        TEXT,
  provider           TEXT NOT NULL DEFAULT 'none',
  provider_ref       TEXT,
  created_at         TEXT NOT NULL,
  updated_at         TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_assignments_user_due ON assignments(user_id, due_at);
CREATE INDEX IF NOT EXISTS idx_classes_user_day ON classes(user_id, day_of_week);
CREATE INDEX IF NOT EXISTS idx_materials_user ON materials(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_outputs_user ON ai_outputs(user_id, created_at);
`);

export const one = (sql, ...args) => db.prepare(sql).get(...args) || null;
export const all = (sql, ...args) => db.prepare(sql).all(...args);
export const run = (sql, ...args) => db.prepare(sql).run(...args);

export function newId(prefix) {
  return uid(prefix ? `${prefix}_` : '');
}

export function getUsage(userId, mk = null) {
  const key = mk || new Date().toISOString().slice(0, 7);
  let row = one('SELECT * FROM usage WHERE user_id = ? AND month_key = ?', userId, key);
  if (!row) {
    run('INSERT INTO usage (user_id, month_key) VALUES (?, ?)', userId, key);
    row = { user_id: userId, month_key: key, uploads: 0, ai_outputs: 0, questions: 0 };
  }
  return row;
}

export function bumpUsage(userId, field, by = 1) {
  const key = new Date().toISOString().slice(0, 7);
  getUsage(userId, key);
  run(`UPDATE usage SET ${field} = ${field} + ? WHERE user_id = ? AND month_key = ?`, by, userId, key);
}

export function ensureSubscription(userId) {
  let sub = one('SELECT * FROM subscriptions WHERE user_id = ?', userId);
  if (!sub) {
    const t = nowIso();
    run(
      'INSERT INTO subscriptions (user_id, plan, status, provider, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      userId, 'free', 'none', 'none', t, t
    );
    sub = one('SELECT * FROM subscriptions WHERE user_id = ?', userId);
  }
  return sub;
}

export function touchSubscription(userId, patch) {
  ensureSubscription(userId);
  const keys = Object.keys(patch);
  if (!keys.length) return;
  const sets = keys.map((k) => `${k} = ?`).join(', ');
  run(`UPDATE subscriptions SET ${sets}, updated_at = ? WHERE user_id = ?`,
    ...keys.map((k) => patch[k]), nowIso(), userId);
}

/* ─────────────────────────── demo data ─────────────────────────── */

export function seedDemoData(userId, { reset = false } = {}) {
  if (reset) {
    for (const t of ['classes', 'assignments', 'materials', 'ai_outputs', 'chat_messages']) {
      run(`DELETE FROM ${t} WHERE user_id = ?`, userId);
    }
  } else {
    const existing = one('SELECT COUNT(*) AS c FROM classes WHERE user_id = ?', userId);
    if (existing && existing.c > 0) return { seeded: false };
  }

  const iso = (d) => d.toISOString();
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const at = (daysFromToday, hh, mm = 0) => {
    const d = new Date(startOfToday);
    d.setDate(d.getDate() + daysFromToday);
    d.setHours(hh, mm, 0, 0);
    return iso(d);
  };

  const subjects = [
    { subject_name: 'Data Structures & Algorithms', subject_code: 'CS 201', instructor: 'Prof. R. Dela Cruz', room: 'Lab 3B', day_of_week: 1, start_time: '08:00', end_time: '09:30', color: '#4F46E5' },
    { subject_name: 'Discrete Mathematics', subject_code: 'MATH 210', instructor: 'Prof. L. Santos', room: 'Rm 204', day_of_week: 1, start_time: '10:00', end_time: '11:30', color: '#0EA5E9' },
    { subject_name: 'Web Systems & Technologies', subject_code: 'IT 314', instructor: 'Prof. M. Reyes', room: 'Comp Lab 1', day_of_week: 2, start_time: '13:00', end_time: '15:00', color: '#10B981' },
    { subject_name: 'Object-Oriented Programming', subject_code: 'CS 202', instructor: 'Prof. J. Bautista', room: 'Lab 2A', day_of_week: 3, start_time: '09:00', end_time: '10:30', color: '#F59E0B' },
    { subject_name: 'Purposive Communication', subject_code: 'GE 105', instructor: 'Prof. A. Villanueva', room: 'Rm 108', day_of_week: 4, start_time: '07:30', end_time: '09:00', color: '#EC4899' },
    { subject_name: 'Philippine History', subject_code: 'GE 102', instructor: 'Prof. C. Mendoza', room: 'Rm 301', day_of_week: 5, start_time: '11:00', end_time: '12:30', color: '#8B5CF6' },
  ];

  const ids = {};
  for (const s of subjects) {
    const id = newId('cls');
    ids[s.subject_code] = id;
    run(
      `INSERT INTO classes (id, user_id, subject_name, subject_code, instructor, room, day_of_week, start_time, end_time, color, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      id, userId, s.subject_name, s.subject_code, s.instructor, s.room, s.day_of_week,
      s.start_time, s.end_time, s.color, nowIso()
    );
  }

  const assignments = [
    { title: 'Linked List Implementation', subject: 'CS 201', class_id: ids['CS 201'], type: 'assignment', due_at: at(0, 23, 59), priority: 'high', description: 'Implement singly + doubly linked lists in Java with unit tests.', reminder_at: at(0, 18, 0) },
    { title: 'Problem Set 4 — Graph Theory', subject: 'MATH 210', class_id: ids['MATH 210'], type: 'assignment', due_at: at(1, 23, 59), priority: 'medium', description: 'Solve items 1–12 on Euler circuits and spanning trees.', reminder_at: at(1, 8, 0) },
    { title: 'Responsive Portfolio Page', subject: 'IT 314', class_id: ids['IT 314'], type: 'project', due_at: at(3, 17, 0), priority: 'high', description: 'Build a mobile-first personal portfolio using semantic HTML + CSS grid.' },
    { title: 'Midterm Exam — OOP', subject: 'CS 202', class_id: ids['CS 202'], type: 'exam', due_at: at(5, 9, 0), priority: 'high', description: 'Covers inheritance, polymorphism, interfaces, and exception handling.' },
    { title: 'Reflection Essay: Rizal', subject: 'GE 102', class_id: ids['GE 102'], type: 'assignment', due_at: at(6, 23, 59), priority: 'low', description: '800-word reflection on Noli Me Tangere and its relevance today.' },
    { title: 'Group Presentation Script', subject: 'GE 105', class_id: ids['GE 105'], type: 'assignment', due_at: at(8, 13, 0), priority: 'medium', description: '10-minute script on intercultural communication.' },
    { title: 'Quiz 2 — Big-O Analysis', subject: 'CS 201', class_id: ids['CS 201'], type: 'quiz', due_at: at(-1, 10, 0), priority: 'high', description: 'Time complexity of sorting + searching algorithms.' },
    { title: 'Set up GitHub repo', subject: 'IT 314', class_id: ids['IT 314'], type: 'assignment', due_at: at(-3, 23, 59), priority: 'low', status: 'completed', description: 'Initialise repo, add README and .gitignore.' },
  ];

  for (const a of assignments) {
    const completed = a.status === 'completed';
    const id = newId('asg');
    run(
      `INSERT INTO assignments (id, user_id, class_id, title, subject, description, type, due_at, priority, status, reminder_at, completed_at, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      id, userId, a.class_id || null, a.title, a.subject, a.description || '', a.type,
      a.due_at, a.priority, a.status || 'pending', a.reminder_at || null,
      completed ? nowIso() : null, nowIso(), nowIso()
    );
  }

  // A sample study material so the AI features are testable immediately.
  const notesText = [
    'Data Structures — Linked Lists (CS 201 reviewer)',
    '',
    'A linked list is a linear data structure where each element, called a node, stores data and a reference to the next node in the sequence. Unlike an array, a linked list does not store its elements in contiguous memory, so it can grow and shrink at runtime without reallocating a whole block.',
    '',
    'A singly linked list stores only a next pointer. Traversal is one-directional: you start at the head node and follow next pointers until you reach null. Insertion at the head is O(1) because you only rewrite two pointers. Insertion at the tail is O(n) unless you also keep a tail pointer.',
    '',
    'A doubly linked list stores both next and previous pointers. The extra pointer costs memory but allows backward traversal and O(1) deletion of a node you already hold a reference to, because you can reach its predecessor directly.',
    '',
    'A circular linked list connects the last node back to the head node. Circular lists are useful for round-robin scheduling and for buffered streaming, where you loop forever over a fixed set of slots.',
    '',
    'Common operations and their time complexity: access by index is O(n) because you must walk from the head; search is O(n); insertion at a known node is O(1); deletion at a known node is O(1) for doubly linked lists and O(n) for singly linked lists.',
    '',
    'The main tradeoff between arrays and linked lists is memory layout. Arrays give cache-friendly O(1) random access but require contiguous space and expensive resizing. Linked lists give cheap structural changes but poor locality of reference, so iteration is usually slower in practice even when the asymptotic cost is the same.',
    '',
    'A hash table maps keys to values using a hash function and an array of buckets. When two keys hash to the same bucket a collision occurs; collisions are resolved by separate chaining with linked lists or by open addressing with linear probing. With a good hash function, average lookup is O(1).',
    '',
    'A stack is a last-in first-out structure with push and pop operations. A queue is first-in first-out with enqueue and dequeue. Both can be implemented on top of a linked list, which is why linked lists are considered a foundational building block of data structures.',
  ].join('\n');

  const matId = newId('mat');
  run(
    `INSERT INTO materials (id, user_id, class_id, title, filename, mime, size_bytes, stored_path, kind, text_content, text_source, char_count, created_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    matId, userId, ids['CS 201'], 'Linked Lists — CS 201 notes', 'linked-lists-notes.txt',
    'text/plain', Buffer.byteLength(notesText), '', 'notes', notesText, 'pasted', notesText.length, nowIso()
  );

  return { seeded: true, materialId: matId };
}

export function closeDb() {
  try { db.close(); } catch { /* ignore */ }
}
