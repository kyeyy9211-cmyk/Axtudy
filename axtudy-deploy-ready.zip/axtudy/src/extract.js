/**
 * AXTUDY — text extraction from uploaded study materials.
 * PDF  -> pdftotext (poppler), fallback to a naive stream decoder
 * PPTX -> unzip + XML strip        DOCX -> unzip + XML strip
 * XLSX -> unzip + sharedStrings.xml
 * TEXT -> utf8
 * IMAGE -> best-effort OCR/description via Gemini vision when a key exists
 */
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { config } from './config.js';

const DOCX_EXT = new Set(['.docx']);
const PPTX_EXT = new Set(['.pptx']);
const XLSX_EXT = new Set(['.xlsx']);
const TEXT_EXT = new Set(['.txt', '.md', '.markdown', '.csv', '.json', '.html', '.htm', '.xml', '.rtf', '.srt', '.vtt', '.log']);
const IMAGE_EXT = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp']);

export const kindFor = (filename, mime = '') => {
  const ext = path.extname(filename || '').toLowerCase();
  if (ext === '.pdf' || mime === 'application/pdf') return 'pdf';
  if (PPTX_EXT.has(ext)) return 'pptx';
  if (DOCX_EXT.has(ext)) return 'docx';
  if (XLSX_EXT.has(ext)) return 'xlsx';
  if (IMAGE_EXT.has(ext) || mime.startsWith('image/')) return 'image';
  if (TEXT_EXT.has(ext) || mime.startsWith('text/')) return 'text';
  return 'other';
};

const clean = (s) =>
  String(s || '')
    .replace(/\r\n?/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();

const has = (bin) => {
  const r = spawnSync('which', [bin], { encoding: 'utf8' });
  return r.status === 0 && r.stdout.trim().length > 0;
};

const HAS_PDFTOTEXT = has('pdftotext');
const HAS_UNZIP = has('unzip');
export const extractionCapabilities = () => ({
  pdf: HAS_PDFTOTEXT ? 'pdftotext' : 'none',
  office: HAS_UNZIP ? 'unzip' : 'none',
  images: config.ai.geminiKey ? 'gemini-vision' : 'none',
});

function xmlToText(xml) {
  return xml
    .replace(/<\/w:p>/g, '\n')
    .replace(/<\/a:p>/g, '\n')
    .replace(/<w:tab\s*\/>/g, '\t')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'");
}

function writeTemp(buffer, filename) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'axtudy-'));
  const p = path.join(dir, path.basename(filename || 'upload'));
  fs.writeFileSync(p, buffer);
  return p;
}

function unzipEntryNames(zipPath) {
  const r = spawnSync('unzip', ['-Z1', zipPath], { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
  if (r.status !== 0) return [];
  return r.stdout.split('\n').map((s) => s.trim()).filter(Boolean);
}

function unzipEntry(zipPath, entry) {
  const r = spawnSync('unzip', ['-p', zipPath, entry], {
    encoding: 'buffer', maxBuffer: 64 * 1024 * 1024,
  });
  if (r.status !== 0 || !r.stdout) return '';
  return r.stdout.toString('utf8');
}

function naivePdfText(buffer) {
  const raw = buffer.toString('latin1');
  const out = [];
  const streamRe = /stream\r?\n([\s\S]*?)\r?\nendstream/g;
  let m;
  while ((m = streamRe.exec(raw))) {
    const chunk = m[1];
    const textRe = /\((?:\\.|[^\\()])*\)/g;
    const hits = chunk.match(textRe);
    if (hits && hits.length > 2) {
      const line = hits
        .map((h) => h.slice(1, -1).replace(/\\([()\\])/g, '$1'))
        .join(' ');
      if (/[A-Za-z]{3,}/.test(line)) out.push(line);
    }
  }
  return out.join('\n');
}

/**
 * Extract plain text from an uploaded buffer.
 * Never throws for unsupported formats — returns { text, source, note }.
 */
export function extractText({ buffer, filename, mime = '', kind }) {
  const k = kind || kindFor(filename, mime);
  const ext = path.extname(filename || '').toLowerCase();

  try {
    if (k === 'text') {
      return { text: clean(buffer.toString('utf8')), source: 'plain-text' };
    }

    if (k === 'pdf') {
      if (HAS_PDFTOTEXT) {
        const tmp = writeTemp(buffer, filename.endsWith('.pdf') ? filename : 'upload.pdf');
        const r = spawnSync('pdftotext', ['-layout', '-enc', 'UTF-8', tmp, '-'], {
          encoding: 'utf8', maxBuffer: 64 * 1024 * 1024,
        });
        fs.rmSync(path.dirname(tmp), { recursive: true, force: true });
        if (r.status === 0 && r.stdout && r.stdout.trim().length > 30) {
          return { text: clean(r.stdout), source: 'pdftotext' };
        }
      }
      const naive = clean(naivePdfText(buffer));
      if (naive.length > 40) return { text: naive, source: 'pdf-naive', note: 'Basic PDF text recovery used.' };
      return {
        text: '', source: 'none',
        note: 'This PDF looks like a scanned image. Add a GEMINI_API_KEY to enable image/OCR reading, or paste the text instead.',
      };
    }

    if (k === 'docx' || k === 'pptx' || k === 'xlsx') {
      if (!HAS_UNZIP) {
        return { text: '', source: 'none', note: 'The `unzip` command is unavailable, so Office files cannot be read.' };
      }
      const tmp = writeTemp(buffer, filename);
      const names = unzipEntryNames(tmp);
      let text = '';
      if (k === 'docx') {
        text = xmlToText(unzipEntry(tmp, 'word/document.xml'));
      } else if (k === 'pptx') {
        const slides = names.filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n))
          .sort((a, b) => Number(a.match(/(\d+)/)[1]) - Number(b.match(/(\d+)/)[1]));
        text = slides.map((s, i) => `--- Slide ${i + 1} ---\n${xmlToText(unzipEntry(tmp, s))}`).join('\n\n');
      } else {
        const shared = unzipEntry(tmp, 'xl/sharedStrings.xml');
        text = shared ? xmlToText(shared) : '';
      }
      fs.rmSync(path.dirname(tmp), { recursive: true, force: true });
      const out = clean(text);
      if (out.length > 20) return { text: out, source: `unzip:${k}` };
      return { text: '', source: 'none', note: `No readable text found inside the ${k.toUpperCase()} file.` };
    }

    if (k === 'image') {
      if (config.ai.geminiKey) {
        return { text: '', source: 'image-pending-vision', note: 'Image stored. Use "Read with AI" to analyse it with the vision model.' };
      }
      return {
        text: '', source: 'none',
        note: 'Images need a vision-capable AI key (GEMINI_API_KEY) for OCR. No key is configured, so the image was stored without text.',
      };
    }

    // Fallback: try utf8 if it looks like text, else give up gracefully.
    const guess = buffer.toString('utf8');
    if (/^[\x09\x0a\x0d\x20-\x7e\u00a0-\uffff]*$/.test(guess.slice(0, 4000)) && guess.trim().length > 40) {
      return { text: clean(guess), source: 'utf8-guess' };
    }
    return { text: '', source: 'none', note: `Unsupported file type (${ext || mime || 'unknown'}). Supported: PDF, PPTX, DOCX, XLSX, images, TXT/MD/CSV.` };
  } catch (err) {
    return { text: '', source: 'error', note: `Could not read the file: ${err.message}` };
  }
}

/** Vision OCR/description through Gemini (only when a key exists). */
export async function describeImageWithGemini({ buffer, mime }) {
  if (!config.ai.geminiKey) return { text: '', note: 'GEMINI_API_KEY is not configured.' };
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${config.ai.geminiModel}:generateContent?key=${config.ai.geminiKey}`;
  const body = {
    contents: [{
      parts: [
        { text: 'Transcribe ALL readable text from this study material image exactly. After the transcript, add a short section "VISUAL CONTEXT:" describing diagrams, tables, or figures in one or two sentences.' },
        { inline_data: { mime_type: mime || 'image/png', data: buffer.toString('base64') } },
      ],
    }],
  };
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { text: '', note: data?.error?.message || `Gemini error ${res.status}` };
  const text = (data?.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('\n').trim();
  return { text, note: text ? '' : 'No text detected in the image.' };
}

export { clean as cleanText };
