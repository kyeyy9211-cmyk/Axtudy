/**
 * AXTUDY — small shared utilities (HTTP, ids, dates, validation).
 */
import crypto from 'node:crypto';

export const uid = (prefix = '') =>
  prefix + crypto.randomBytes(12).toString('hex');

export const nowIso = () => new Date().toISOString();

export const monthKey = (d = new Date()) =>
  `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;

export const addDays = (date, days) => new Date(date.getTime() + days * 86400000);

export function json(res, status, body, headers = {}) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(payload),
    'cache-control': 'no-store',
    ...headers,
  });
  res.end(payload);
}

export const ok = (res, body = {}) => json(res, 200, { ok: true, ...body });
export const created = (res, body = {}) => json(res, 201, { ok: true, ...body });
export const fail = (res, status, message, extra = {}) =>
  json(res, status, { ok: false, error: message, ...extra });

export class HttpError extends Error {
  constructor(status, message, extra = {}) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}

export const bad = (msg, extra) => {
  throw new HttpError(400, msg, extra);
};
export const unauthorized = (msg = 'Please sign in to continue.') => {
  throw new HttpError(401, msg);
};
export const forbidden = (msg, extra) => {
  throw new HttpError(403, msg, extra);
};
export const notFound = (msg = 'Not found.') => {
  throw new HttpError(404, msg);
};

/** Read a JSON request body (with a sane size cap). */
export function readJson(req, limit = 2 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new HttpError(413, 'Request body too large.'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new HttpError(400, 'Invalid JSON body.'));
      }
    });
    req.on('error', reject);
  });
}

/** Read a raw binary request body. */
export function readBuffer(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new HttpError(413, `File too large. Maximum size is ${Math.round(limit / 1048576)} MB.`));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

/**
 * Parse a multipart/form-data body into { fields, files }.
 * files: [{ field, filename, mime, buffer }]
 */
export function parseMultipart(buffer, contentType) {
  const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || '');
  if (!m) throw new HttpError(400, 'Missing multipart boundary.');
  const boundary = Buffer.from(`--${(m[1] || m[2]).trim()}`);
  const fields = {};
  const files = [];
  const parts = [];
  let start = buffer.indexOf(boundary);
  if (start === -1) throw new HttpError(400, 'Malformed upload body.');
  start += boundary.length;
  while (true) {
    // skip CRLF after boundary
    if (buffer[start] === 13 && buffer[start + 1] === 10) start += 2;
    if (buffer[start] === 45 && buffer[start + 1] === 45) break; // closing --
    const next = buffer.indexOf(boundary, start);
    if (next === -1) break;
    parts.push(buffer.subarray(start, next - 2)); // strip trailing CRLF
    start = next + boundary.length;
  }
  for (const part of parts) {
    const headerEnd = part.indexOf('\r\n\r\n');
    if (headerEnd === -1) continue;
    const rawHeaders = part.subarray(0, headerEnd).toString('utf8');
    const body = part.subarray(headerEnd + 4);
    const nameMatch = /name="([^"]*)"/i.exec(rawHeaders);
    const fileMatch = /filename="([^"]*)"/i.exec(rawHeaders);
    const typeMatch = /content-type:\s*([^\s;]+)/i.exec(rawHeaders);
    const name = nameMatch ? nameMatch[1] : 'field';
    if (fileMatch) {
      files.push({
        field: name,
        filename: fileMatch[1] || 'upload',
        mime: typeMatch ? typeMatch[1] : 'application/octet-stream',
        buffer: body,
      });
    } else {
      fields[name] = body.toString('utf8');
    }
  }
  return { fields, files };
}

/** Cookie helpers */
export function parseCookies(req) {
  const out = {};
  const raw = req.headers.cookie;
  if (!raw) return out;
  for (const pair of raw.split(';')) {
    const i = pair.indexOf('=');
    if (i === -1) continue;
    out[pair.slice(0, i).trim()] = decodeURIComponent(pair.slice(i + 1).trim());
  }
  return out;
}

export function setCookie(res, name, value, opts = {}) {
  const bits = [`${name}=${encodeURIComponent(value)}`];
  bits.push(`Path=${opts.path || '/'}`);
  if (opts.maxAge !== undefined) bits.push(`Max-Age=${opts.maxAge}`);
  if (opts.httpOnly !== false) bits.push('HttpOnly');
  bits.push(`SameSite=${opts.sameSite || 'Lax'}`);
  if (opts.secure) bits.push('Secure');
  const prev = res.getHeader('set-cookie');
  const list = prev ? (Array.isArray(prev) ? prev : [prev]) : [];
  res.setHeader('set-cookie', [...list, bits.join('; ')]);
}

/** Field validation helpers */
export const str = (v, { max = 500, min = 0, field = 'field', trim = true } = {}) => {
  let s = v === undefined || v === null ? '' : String(v);
  if (trim) s = s.trim();
  if (s.length < min) throw new HttpError(400, `${field} must be at least ${min} characters.`);
  if (s.length > max) throw new HttpError(400, `${field} must be under ${max} characters.`);
  return s;
};

export const validEmail = (v) => {
  const s = str(v, { max: 200, field: 'Email' }).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s)) throw new HttpError(400, 'Enter a valid email address.');
  return s;
};

export const isValidDate = (v) => {
  if (!v) return false;
  const d = new Date(v);
  return !Number.isNaN(d.getTime());
};

/** Escape for safe embedding in HTML (used by the landing snippet). */
export const escapeHtml = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
